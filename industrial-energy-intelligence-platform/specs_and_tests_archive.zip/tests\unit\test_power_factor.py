"""
IEIP Tests — Power Factor & Compensation Sizing Tests
"""

from app.analytics.power_factor import PowerFactorDetector
from app.models.anomaly import AnomalyType


def test_nominal_power_factor_ok(nominal_telemetry, sample_motor_specs):
    detector = PowerFactorDetector(target_pf=0.95, penalty_threshold=0.85)
    candidates = detector.evaluate(nominal_telemetry, sample_motor_specs)
    assert len(candidates) == 0


def test_low_power_factor_sizing(nominal_telemetry, sample_motor_specs):
    detector = PowerFactorDetector(target_pf=0.95, penalty_threshold=0.85)
    low_pf_data = dict(nominal_telemetry)
    low_pf_data["power_factor"] = 0.65
    low_pf_data["active_power_kw"] = 50.0

    candidates = detector.evaluate(low_pf_data, sample_motor_specs)
    assert len(candidates) == 1
    cand = candidates[0]
    assert cand.anomaly_type == AnomalyType.LOW_POWER_FACTOR
    assert "recommended_compensation_kvar" in cand.context
    # Check that computed kVAR is positive and realistic
    assert cand.context["recommended_compensation_kvar"] > 20.0
