# ADR-005: Arquitectura Monolito Modular vs. Microservicios

## Estado
Aceptado.

## Contexto
El sistema requiere múltiples responsabilidades lógicas: ingesta de telemetría, pipeline de analítica de datos, gestión de alarmas, autenticación y despacho de eventos en tiempo real. Se evaluó si convenía distribuir estas funciones en microservicios independientes o consolidarlas en un monolito modular.

## Decisión
Construir un **Monolito Modular** utilizando FastAPI y Python 3.12 con módulos fuertemente cohesionados y desacoplados:
- `acquisition/`: Abstracciones de fuentes de datos.
- `analytics/`: Algoritmos de cálculo y pipelines.
- `alerts/`: Máquina de estados ISA 18.2 y deduplicador.
- `telemetry/`: Validación de calidad e ingesta.
- `simulation/`: Modelos matemáticos de activos y gemelo digital.

## Consecuencias
- **Positivas**:
  - Despliegue simple y determinístico con un único archivo `docker-compose.yml`.
  - Cero latencia de serialización de red interna entre analítica y almacenamiento.
  - Facilidad para depuración y pruebas unitarias/integración de extremo a extremo.
  - Si en el futuro un componente requiere escala elástica independiente (por ejemplo, el pipeline analítico), la separación de paquetes permite extraerlo como servicio autónomo sin reescribir la lógica de dominio.
- **Negativas / Compensaciones**:
  - Todo el backend comparte el mismo ciclo de vida de despliegue.
