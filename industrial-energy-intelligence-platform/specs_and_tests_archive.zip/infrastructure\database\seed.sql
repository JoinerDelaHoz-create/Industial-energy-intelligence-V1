-- ============================================================
-- IEIP — Planta Demo Caribe Seed Data
-- ============================================================

-- 1. Users (Passwords: admin12345, operator12345, engineer12345)
-- bcrypt hash for 'admin12345'
INSERT INTO users (id, email, hashed_password, full_name, role, is_active, is_superuser)
VALUES 
    ('a0000000-0000-0000-0000-000000000001', 'admin@ieip.local', '$2b$12$36KqKek6l1k9L8OaA0v1r.sXU1.tW/m8h4yWvNf9r78gOcmmI7m.e', 'Administrador Planta Caribe', 'ADMIN', TRUE, TRUE),
    ('a0000000-0000-0000-0000-000000000002', 'operator@ieip.local', '$2b$12$36KqKek6l1k9L8OaA0v1r.sXU1.tW/m8h4yWvNf9r78gOcmmI7m.e', 'Operador Sala de Control', 'OPERATOR', TRUE, FALSE),
    ('a0000000-0000-0000-0000-000000000003', 'engineer@ieip.local', '$2b$12$36KqKek6l1k9L8OaA0v1r.sXU1.tW/m8h4yWvNf9r78gOcmmI7m.e', 'Ingeniero de Mantenimiento', 'ENGINEER', TRUE, FALSE)
ON CONFLICT (email) DO NOTHING;

-- 2. Industrial Equipment Fleet (Planta Demo Caribe)
INSERT INTO equipment (
    id, asset_code, name, description, equipment_type, manufacturer, model, serial_number,
    location, site_id, rated_power_kw, rated_voltage, rated_current, phases, frequency_hz,
    nominal_power_factor, operating_status, is_monitored, installation_date
) VALUES
(
    'e0000000-0000-0000-0000-000000000305', 'MTR-305', 'Motor Principal Molino de Crudo',
    'Motor de inducción jaula de ardilla acoplado a reductor de molino tubular',
    'MOTOR', 'WEG', 'W22 Premium IE3', 'WG-2023-88391',
    'Área de Molienda — Nave 3', 'planta-caribe',
    75.0, 460.0, 115.0, 3, 60.0, 0.88, 'OPERATIONAL', TRUE, '2023-04-15'
),
(
    'e0000000-0000-0000-0000-000000000101', 'PMP-101', 'Bomba Centrífuga de Alimentación',
    'Bomba multietapa de agua de reposición para caldera de vapor',
    'PUMP', 'Sulzer', 'MSX 100-250', 'SZ-2022-44102',
    'Casa de Bombas — Nivel 0', 'planta-caribe',
    45.0, 460.0, 72.0, 3, 60.0, 0.86, 'OPERATIONAL', TRUE, '2022-09-10'
),
(
    'e0000000-0000-0000-0000-000000000201', 'CMP-201', 'Compresor de Tornillo Aire de Instrumentación',
    'Compresor rotativo lubricado con secador frigorífico integrado',
    'COMPRESSOR', 'Atlas Copco', 'GA 90 VSD', 'AC-2021-99214',
    'Sala de Compresores — Subestación 1', 'planta-caribe',
    90.0, 460.0, 140.0, 3, 60.0, 0.90, 'WARNING', TRUE, '2021-11-20'
),
(
    'e0000000-0000-0000-0000-000000000102', 'FAN-102', 'Ventilador de Tiro Inducido Horno',
    'Ventilador centrífugo de extracción de gases calientes de chimenea',
    'FAN', 'FläktGroup', 'HeavyDuty ID-Fan', 'FG-2020-11234',
    'Torre de Enfriamiento / Horno', 'planta-caribe',
    30.0, 460.0, 48.0, 3, 60.0, 0.85, 'OPERATIONAL', TRUE, '2020-08-05'
),
(
    'e0000000-0000-0000-0000-000000000401', 'CNV-401', 'Cinta Transportadora Principal Clinker',
    'Banda transportadora de transferencia con tambor motriz vulcanizado',
    'CONVEYOR', 'Continental', 'ConveyorTech 1200', 'CT-2019-33821',
    'Silo de Clinker — Galería Superior', 'planta-caribe',
    15.0, 460.0, 26.0, 3, 60.0, 0.82, 'OPERATIONAL', TRUE, '2019-03-12'
),
(
    'e0000000-0000-0000-0000-000000000001', 'GEN-101', 'Generador Diésel de Emergencia',
    'Grupo electrógeno diésel para respaldo de cargas críticas de planta',
    'GENERATOR', 'Cummins', 'C150 D6', 'CU-2022-77192',
    'Patio de Emergencia — Exterior', 'planta-caribe',
    110.0, 460.0, 165.0, 3, 60.0, 0.85, 'OFFLINE', TRUE, '2022-01-18'
)
ON CONFLICT (asset_code) DO NOTHING;

-- 3. Measurement Points
INSERT INTO measurement_points (
    id, equipment_id, point_code, name, category, protocol, mqtt_topic, sampling_interval_sec
) VALUES
('m0000000-0000-0000-0000-000000000305', 'e0000000-0000-0000-0000-000000000305', 'MP-MTR-305-MAIN', 'Medidor de Energía y Calidad MTR-305', 'ELECTRICAL', 'SIMULATED', 'ieip/planta-caribe/MTR-305/telemetry', 1.0),
('m0000000-0000-0000-0000-000000000101', 'e0000000-0000-0000-0000-000000000101', 'MP-PMP-101-MAIN', 'Medidor de Energía PMP-101', 'ELECTRICAL', 'SIMULATED', 'ieip/planta-caribe/PMP-101/telemetry', 1.0),
('m0000000-0000-0000-0000-000000000201', 'e0000000-0000-0000-0000-000000000201', 'MP-CMP-201-MAIN', 'Analizador de Redes CMP-201', 'ELECTRICAL', 'SIMULATED', 'ieip/planta-caribe/CMP-201/telemetry', 1.0),
('m0000000-0000-0000-0000-000000000102', 'e0000000-0000-0000-0000-000000000102', 'MP-FAN-102-MAIN', 'Sensor de Potencia y THD FAN-102', 'ELECTRICAL', 'SIMULATED', 'ieip/planta-caribe/FAN-102/telemetry', 1.0),
('m0000000-0000-0000-0000-000000000401', 'e0000000-0000-0000-0000-000000000401', 'MP-CNV-401-MAIN', 'Transductor de Potencia CNV-401', 'ELECTRICAL', 'SIMULATED', 'ieip/planta-caribe/CNV-401/telemetry', 1.0),
('m0000000-0000-0000-0000-000000000001', 'e0000000-0000-0000-0000-000000000001', 'MP-GEN-101-MAIN', 'Analizador de Salida Alternador GEN-101', 'ELECTRICAL', 'SIMULATED', 'ieip/planta-caribe/GEN-101/telemetry', 1.0)
ON CONFLICT (point_code) DO NOTHING;

-- 4. Seed Historical Telemetry for MTR-305 (Past 24 hours, hourly baseline points)
INSERT INTO telemetry_readings (
    time, measurement_point_id, equipment_id,
    voltage_l1, voltage_l2, voltage_l3, voltage_avg,
    current_l1, current_l2, current_l3, current_avg,
    active_power_kw, reactive_power_kvar, apparent_power_kva,
    power_factor, frequency_hz, energy_kwh,
    current_unbalance_pct, voltage_unbalance_pct, thd_current_pct, thd_voltage_pct,
    temperature_c, vibration_rms_mms, operating_state, load_pct, is_simulated, quality_code
)
SELECT 
    NOW() - (i || ' hours')::INTERVAL,
    'm0000000-0000-0000-0000-000000000305',
    'e0000000-0000-0000-0000-000000000305',
    460.5 + sin(i)*1.2, 459.8 + cos(i)*1.1, 461.0 + sin(i*0.5)*0.9, 460.4,
    92.4 + sin(i)*3.5, 91.8 + cos(i)*3.2, 92.9 + sin(i*0.8)*2.9, 92.3,
    62.5 + sin(i)*3.0, 31.8 + cos(i)*2.0, 70.1,
    0.87 + sin(i)*0.01, 60.01, 12000.0 + (24 - i)*62.5,
    1.2, 0.3, 3.1, 1.8,
    68.5 + (24 - i)*0.2, 1.45 + sin(i)*0.1, 'RUNNING', 83.0, TRUE, 192
FROM generate_series(0, 24) AS i
ON CONFLICT (time, measurement_point_id) DO NOTHING;

-- 5. Seed Initial Demo Anomaly and Alert on CMP-201 (Demonstrating active state)
INSERT INTO anomalies (
    id, equipment_id, measurement_point_id, detected_at, anomaly_type, severity, status,
    algorithm_used, metric_name, observed_value, expected_value, threshold_value, deviation_pct,
    confidence_score, description, context_snapshot
) VALUES (
    'b0000000-0000-0000-0000-000000000201',
    'e0000000-0000-0000-0000-000000000201',
    'm0000000-0000-0000-0000-000000000201',
    NOW() - INTERVAL '45 minutes',
    'PHASE_IMBALANCE', 'HIGH', 'DETECTED',
    'NEMA_MG1_CURRENT_UNBALANCE', 'current_unbalance_pct', 11.4, 2.0, 10.0, 11.4,
    0.96, 'Desbalance severo de corrientes NEMA (11.4%). Factor de desclasificación estimado: 0.77.',
    '{"current_l1": 158.2, "current_l2": 139.1, "current_l3": 124.5, "derating_factor": 0.77}'::jsonb
) ON CONFLICT (id) DO NOTHING;

INSERT INTO alerts (
    id, equipment_id, anomaly_id, dedup_key, title, message, severity, status,
    occurrence_count, first_triggered_at, last_triggered_at
) VALUES (
    'c0000000-0000-0000-0000-000000000201',
    'e0000000-0000-0000-0000-000000000201',
    'b0000000-0000-0000-0000-000000000201',
    'e0000000-0000-0000-0000-000000000201:PHASE_IMBALANCE',
    'PHASE_IMBALANCE: CMP-201',
    'Desbalance severo de corrientes NEMA (11.4%). Factor de desclasificación estimado: 0.77.',
    'HIGH', 'OPEN', 4,
    NOW() - INTERVAL '45 minutes', NOW() - INTERVAL '2 minutes'
) ON CONFLICT (id) DO NOTHING;

INSERT INTO maintenance_recommendations (
    id, equipment_id, anomaly_id, title, technical_rationale, suggested_actions,
    priority, status, estimated_monthly_kwh_waste, estimated_monthly_cost_usd
) VALUES (
    'd0000000-0000-0000-0000-000000000201',
    'e0000000-0000-0000-0000-000000000201',
    'b0000000-0000-0000-0000-000000000201',
    'Inspección de Devanados y Conexiones en Bornes — CMP-201',
    'El desbalance de fases detectado (11.4%) incrementa las pérdidas por efecto Joule y corrientes de secuencia negativa.',
    '1. Medir resistencia de aislamiento (Megger) en cada bobinado.\n2. Verificar par de apriete en bornes del compresor.\n3. Inspeccionar contactor y relé térmico en el CCM.',
    'HIGH', 'PENDING', 2592.0, 362.88
) ON CONFLICT (id) DO NOTHING;
