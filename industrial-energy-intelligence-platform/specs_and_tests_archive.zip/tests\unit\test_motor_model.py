"""
IEIP Tests — Induction Motor Model Unit Tests
"""

from app.simulation.motor_model import InductionMotorTwin, MotorSpecifications


def test_motor_steady_state_step():
    specs = MotorSpecifications(rated_power_kw=75.0, rated_current_a=115.0)
    twin = InductionMotorTwin(specs)
    twin.load_factor = 0.85

    frame = twin.step(delta_time_sec=1.0)

    assert frame["operating_state"] == "RUNNING"
    assert frame["is_simulated"] is True
    # At 85% of 75 kW with ~94% efficiency, active power should be ~67.8 kW
    assert 60.0 <= frame["active_power_kw"] <= 75.0
    # Power factor should be healthy ~0.85-0.90
    assert 0.80 <= frame["power_factor"] <= 0.95
    # Voltages should be close to 460 V
    assert 440.0 <= frame["voltage_avg"] <= 480.0
    # Current should be in expected FLA range
    assert 80.0 <= frame["current_avg"] <= 120.0


def test_motor_stopped_step():
    twin = InductionMotorTwin()
    twin.is_running = False

    frame = twin.step(delta_time_sec=1.0)

    assert frame["operating_state"] == "STOPPED"
    assert frame["active_power_kw"] == 0.0
    assert frame["current_avg"] == 0.0
    assert frame["voltage_avg"] == 0.0
