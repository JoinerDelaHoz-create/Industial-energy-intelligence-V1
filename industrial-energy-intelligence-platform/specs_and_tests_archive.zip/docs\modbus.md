# IEIP — Especificación de Integración Modbus TCP/RTU

## 1. Arquitectura de Conexión en Campo
En instalaciones industriales existentes, la mayoría de los analizadores de redes de cabecera y centros de control de motores (CCM) comunican a través de **Modbus RTU (RS-485)** o **Modbus TCP (Ethernet Industrial)**.

```
[Analizador de Redes PM5350 / Socomec Diris] 
                   │ (RS-485 / Modbus RTU)
                   ▼
      [Gateway IoT / Moxa NPort / Advantech]
                   │ (Modbus TCP / JSON)
                   ▼
         [IEIP ModbusDataSource]
```

---

## 2. Mapa de Registros Típico (Holding Registers 4xxxx / Input Registers 3xxxx)
A continuación se detalla el mapa de registros estándar implementado para transductores tipo Schneider Electric PM5000 / PM8000 o Siemens PAC3200:

| Dirección de Registro | Variable | Tipo de Dato | Unidades | Factor de Escala |
|---|---|---|---|---|
| `3001` - `3002` | Tensión $V_{L1-N}$ | Float32 (Big-Endian) | Voltios (V) | 1.0 |
| `3003` - `3004` | Tensión $V_{L2-N}$ | Float32 (Big-Endian) | Voltios (V) | 1.0 |
| `3005` - `3006` | Tensión $V_{L3-N}$ | Float32 (Big-Endian) | Voltios (V) | 1.0 |
| `3007` - `3008` | Tensión Media $V_{avg}$ | Float32 (Big-Endian) | Voltios (V) | 1.0 |
| `3009` - `3010` | Corriente Fase L1 ($I_{L1}$) | Float32 (Big-Endian) | Amperios (A) | 1.0 |
| `3011` - `3012` | Corriente Fase L2 ($I_{L2}$) | Float32 (Big-Endian) | Amperios (A) | 1.0 |
| `3013` - `3014` | Corriente Fase L3 ($I_{L3}$) | Float32 (Big-Endian) | Amperios (A) | 1.0 |
| `3015` - `3016` | Corriente Media $I_{avg}$ | Float32 (Big-Endian) | Amperios (A) | 1.0 |
| `3017` - `3018` | Potencia Activa Total $P$ | Float32 (Big-Endian) | Kilovatios (kW) | 1.0 |
| `3019` - `3020` | Potencia Reactiva Total $Q$ | Float32 (Big-Endian) | kVAR | 1.0 |
| `3021` - `3022` | Factor de Potencia Total $PF$ | Float32 (Big-Endian) | Adimensional (0.0-1.0) | 1.0 |
| `3023` - `3024` | Frecuencia de Línea $f$ | Float32 (Big-Endian) | Hertz (Hz) | 1.0 |
| `3025` - `3026` | Desbalance de Corriente | Float32 (Big-Endian) | Porcentaje (%) | 1.0 |
| `3027` - `3028` | Energía Activa Acumulada | Int64 (Big-Endian) | Kilovatios-hora (kWh) | 1.0 |

---

## 3. Estrategia de Polling y Bloques Continuos
Para optimizar el ancho de banda del bus RS-485 o red Ethernet:
1. Se realizan lecturas en bloque continuo (ej. función Modbus `0x03` o `0x04` leyendo 28 registros en una sola solicitud en lugar de 14 transacciones individuales).
2. Intervalo de refresco configurable por punto de medición (típicamente 1.0 segundo para variables dinámicas, 15 segundos para acumuladores de energía).
3. Manejo de time-outs y reintentos (3 intentos con retroceso exponencial de 500ms) para tolerar ruidos electromagnéticos provocados por conmutación de variadores de frecuencia (VFD).
