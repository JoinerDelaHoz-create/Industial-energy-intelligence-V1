# ADR-004: Estrategia Híbrida de Detección de Anomalías Explicables (NEMA MG-1, IEEE 519, Z-Score)

## Estado
Aceptado.

## Contexto
En entornos industriales de manufactura, las advertencias y paradas preventivas deben estar respaldadas por explicaciones técnicas comprensibles por los ingenieros de planta. Los algoritmos de caja negra no supervisados (*black-box machine learning*) suelen generar falsos positivos durante arranques y cambios normales de proceso sin explicar la causa raíz física.

## Decisión
Implementar un pipeline de detección analítica multinivel compuesto por:
1. **Nivel 1 (Umbrales Operativos)**: Límites de placa (corriente nominal FLA, tensión de línea, factor de potencia mínimo regulatorio, temperatura admisible).
2. **Nivel 2 (Estadística Dinámica Z-Score)**: Ventana móvil de 100 muestras ($|Z| > 3.0\sigma$ para advertencia, $|Z| > 4.5\sigma$ para crítico).
3. **Nivel 3 (Física y Desbalance de Fases)**:
   - Desbalance de corriente según NEMA MG-1: $I_{\text{imbalance}} = \frac{\max(|I_k - I_{\text{avg}}|)}{I_{\text{avg}}} \times 100\%$.
   - Factor de potencia y penalización reactiva ($k\text{VAR}$ necesarios para compensar hasta 0.95 inductivo).
   - Consumo fuera de horario de producción (*off-hours leakage*).

## Consecuencias
- **Positivas**: 100% de explicabilidad técnica. Cada registro de anomalía incluye el valor medido, valor esperado, desviación porcentual, severidad y recomendación de acción correctiva.
- **Negativas / Compensaciones**: Requiere parametrización correcta de las características nominales del equipo en el catálogo maestro.
