# ADR-002: Arquitectura y Topología de Tópicos MQTT

## Estado
Aceptado.

## Contexto
En entornos de manufactura industrial y edge computing, los dispositivos de campo y gateways IoT publican lecturas de telemetría y cambios de estado con anchos de banda variables e intermitencias de red. Se necesita un estándar uniforme de transporte de mensajes desacoplado y resiliente.

## Decisión
Implementar un broker central **Eclipse Mosquitto (MQTT v3.1.1 / v5.0)** con:
- Jerarquía semántica de tópicos: `ieip/{site_id}/{equipment_id}/telemetry` y `ieip/{site_id}/{equipment_id}/status`.
- QoS 1 para telemetría regular (garantía de entrega al menos una vez).
- Mensajes retain para el estado operativo de los equipos.
- Mensajes de última voluntad (LWT - *Last Will and Testament*) para detección automática de desconexión imprevista de gateways de campo.

## Consecuencias
- **Positivas**: Desacoplamiento total entre productores de hardware y el backend analítico. Estandarización de cargas JSON conformes a especificación industrial.
- **Negativas / Compensaciones**: Requiere un broker MQTT en el stack de infraestructura y validación de esquemas en la capa de ingesta para filtrar paquetes corruptos.
