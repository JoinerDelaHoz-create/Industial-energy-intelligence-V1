"""
IEIP Tests — NEMA Phase Imbalance Unit Tests
"""

from app.analytics.imbalance import PhaseImbalanceDetector
from app.models.anomaly import AnomalySeverity, AnomalyType


def test_balanced_currents_no_imbalance(nominal_telemetry, sample_motor_specs):
    detector = PhaseImbalanceDetector()
    candidates = detector.evaluate(nominal_telemetry, sample_motor_specs)
    assert len(candidates) == 0


def test_nema_severe_imbalance_detected(nominal_telemetry, sample_motor_specs):
    detector = PhaseImbalanceDetector()
    # Average = (120 + 80 + 80)/3 = 93.3 A. Max dev = 26.7 A => 28.6% unbalance!
    unbalanced_data = dict(nominal_telemetry)
    unbalanced_data["current_l1"] = 120.0
    unbalanced_data["current_l2"] = 80.0
    unbalanced_data["current_l3"] = 80.0

    candidates = detector.evaluate(unbalanced_data, sample_motor_specs)
    assert len(candidates) == 1
    cand = candidates[0]
    assert cand.anomaly_type == AnomalyType.PHASE_IMBALANCE
    assert cand.severity == AnomalySeverity.CRITICAL
    assert "derating_factor" in cand.context


def test_single_phasing_critical_detected(nominal_telemetry, sample_motor_specs):
    detector = PhaseImbalanceDetector()
    # Loss of phase L3
    blown_fuse_data = dict(nominal_telemetry)
    blown_fuse_data["current_l1"] = 110.0
    blown_fuse_data["current_l2"] = 112.0
    blown_fuse_data["current_l3"] = 0.0

    candidates = detector.evaluate(blown_fuse_data, sample_motor_specs)
    assert len(candidates) == 1
    assert candidates[0].algorithm == "NEMA_SINGLE_PHASING"
    assert candidates[0].severity == AnomalySeverity.CRITICAL
