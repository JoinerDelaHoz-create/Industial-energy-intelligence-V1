"""
IEIP Tests — Pytest Configuration & Fixtures
"""

import sys
from pathlib import Path
import pytest

# Add backend directory to sys.path so app modules import cleanly
backend_dir = Path(__file__).resolve().parent.parent
if str(backend_dir) not in sys.path:
    sys.path.insert(0, str(backend_dir))


@pytest.fixture
def sample_motor_specs():
    return {
        "asset_code": "MTR-TEST",
        "rated_power_kw": 75.0,
        "rated_voltage": 460.0,
        "rated_current": 115.0,
        "nominal_power_factor": 0.88,
    }


@pytest.fixture
def nominal_telemetry():
    return {
        "voltage_l1": 460.0,
        "voltage_l2": 459.8,
        "voltage_l3": 460.2,
        "voltage_avg": 460.0,
        "current_l1": 92.0,
        "current_l2": 91.8,
        "current_l3": 92.2,
        "current_avg": 92.0,
        "active_power_kw": 62.0,
        "reactive_power_kvar": 31.0,
        "apparent_power_kva": 69.3,
        "power_factor": 0.88,
        "frequency_hz": 60.0,
        "temperature_c": 68.0,
        "vibration_rms_mms": 1.4,
        "thd_current_pct": 3.0,
        "thd_voltage_pct": 1.5,
        "operating_state": "RUNNING",
    }
