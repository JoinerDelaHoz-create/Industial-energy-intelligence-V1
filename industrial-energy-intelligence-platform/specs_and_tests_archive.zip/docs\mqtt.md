# IEIP — Especificación de Integración MQTT

## 1. Topología y Estructura Jerárquica de Tópicos
La plataforma IEIP utiliza el estándar de mensajería **MQTT 5.0 / 3.1.1** para la ingestión escalable y asíncrona de datos desde pasarelas industriales (Edge Gateways como Advantech, Moxa, Siemens IOT2050, Raspberry Pi Industrial).

### Estructura de Tópicos (Hierarchy):
```
{prefix}/{site_id}/{equipment_code}/telemetry
{prefix}/{site_id}/{equipment_code}/status
{prefix}/{site_id}/{equipment_code}/command
```

**Ejemplo Concreto (Planta Demo Caribe):**
- Tópico de telemetría: `ieip/planta-caribe/MTR-305/telemetry`
- Tópico de estado: `ieip/planta-caribe/MTR-305/status`
- Tópico de consigna/control: `ieip/planta-caribe/MTR-305/command`

---

## 2. Formato del Payload JSON (Telemetry Frame)
Los analizadores o pasarelas publican tramas normalizadas en formato JSON UTF-8:

```json
{
  "timestamp": "2026-09-24T12:00:00.000Z",
  "point_code": "MP-MTR-305-MAIN",
  "asset_code": "MTR-305",
  "voltage_l1": 460.2,
  "voltage_l2": 459.8,
  "voltage_l3": 460.5,
  "voltage_avg": 460.2,
  "current_l1": 92.4,
  "current_l2": 91.8,
  "current_l3": 92.9,
  "current_avg": 92.4,
  "active_power_kw": 64.2,
  "reactive_power_kvar": 31.8,
  "apparent_power_kva": 71.6,
  "power_factor": 0.88,
  "frequency_hz": 60.01,
  "energy_kwh": 12450.85,
  "current_unbalance_pct": 1.2,
  "voltage_unbalance_pct": 0.3,
  "thd_current_pct": 3.1,
  "thd_voltage_pct": 1.8,
  "temperature_c": 68.5,
  "vibration_rms_mms": 1.45,
  "operating_state": "RUNNING",
  "load_pct": 82.0,
  "quality_code": 192
}
```

---

## 3. Calidad de Servicio (QoS) y Retención
- **QoS 1 (At least once)**: Recomendado para telemetría periódica de alta confiabilidad.
- **QoS 0**: Admitido para variables dinámicas de alta frecuencia (ej. vibración RMS a 10 Hz) donde la pérdida ocasional de un paquete no compromete la tendencia.
- **Retain Flag**: Activado (`retained = true`) exclusivamente en tópicos de estado del activo (`.../status`) con payloads de `LWT` (Last Will and Testament) para detección inmediata de desconexión del gateway de campo.

---

## 4. Configuración del Broker Mosquitto
El contenedor de broker `eclipse-mosquitto` está configurado con:
- Puerto estándar: `1883`
- Persistencia habilitada en volumen montado `/mosquitto/data`
- Registro de auditoría y conexiones de clientes activado
