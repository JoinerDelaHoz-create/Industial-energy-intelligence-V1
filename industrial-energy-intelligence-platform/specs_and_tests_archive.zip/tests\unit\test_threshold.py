"""
IEIP Tests — Threshold Detector Unit Tests
"""

import pytest
from app.analytics.threshold import ThresholdRuleDetector
from app.models.anomaly import AnomalySeverity, AnomalyType


def test_normal_operation_no_anomalies(nominal_telemetry, sample_motor_specs):
    detector = ThresholdRuleDetector()
    candidates = detector.evaluate(nominal_telemetry, sample_motor_specs)
    assert len(candidates) == 0


def test_overcurrent_detected(nominal_telemetry, sample_motor_specs):
    detector = ThresholdRuleDetector()
    # Rated current is 115 A. 140 A is > 110% FLA
    overcurrent_data = dict(nominal_telemetry)
    overcurrent_data["current_avg"] = 140.0

    candidates = detector.evaluate(overcurrent_data, sample_motor_specs)
    assert any(c.anomaly_type == AnomalyType.OVERCURRENT for c in candidates)
    overcurrent = next(c for c in candidates if c.anomaly_type == AnomalyType.OVERCURRENT)
    assert overcurrent.severity in [AnomalySeverity.HIGH, AnomalySeverity.CRITICAL]
    assert overcurrent.observed_value == 140.0


def test_thermal_overload_detected(nominal_telemetry, sample_motor_specs):
    detector = ThresholdRuleDetector()
    hot_data = dict(nominal_telemetry)
    hot_data["temperature_c"] = 108.0

    candidates = detector.evaluate(hot_data, sample_motor_specs)
    assert any(c.anomaly_type == AnomalyType.THERMAL_OVERLOAD for c in candidates)
    thermal = next(c for c in candidates if c.anomaly_type == AnomalyType.THERMAL_OVERLOAD)
    assert thermal.severity == AnomalySeverity.CRITICAL


def test_vibration_iso10816_detected(nominal_telemetry, sample_motor_specs):
    detector = ThresholdRuleDetector()
    vib_data = dict(nominal_telemetry)
    vib_data["vibration_rms_mms"] = 5.2

    candidates = detector.evaluate(vib_data, sample_motor_specs)
    assert any(c.anomaly_type == AnomalyType.EXCESSIVE_VIBRATION for c in candidates)
