"""
IEIP Tests — Alert Deduplication & Cooldown Tests
"""

import time
import uuid
from app.alerts.deduplicator import AlertDeduplicator


def test_alert_suppression_and_occurrence_counter():
    dedup = AlertDeduplicator(cooldown_seconds=10.0)
    equip_id = uuid.uuid4()
    key = dedup.get_dedup_key(equip_id, "OVERCURRENT")

    # 1. First occurrence: not suppressed
    suppress, record = dedup.should_suppress(key)
    assert suppress is False
    assert record is None

    # Register initial alert
    alert_id = uuid.uuid4()
    dedup.register_alert(key, alert_id)

    # 2. Subsequent occurrence immediately after: should be suppressed
    suppress, record = dedup.should_suppress(key)
    assert suppress is True
    assert record is not None
    assert record.alert_id == alert_id
    assert record.occurrence_count == 2

    # 3. Third occurrence: increment count
    suppress, record = dedup.should_suppress(key)
    assert suppress is True
    assert record.occurrence_count == 3


def test_alert_dedup_clear():
    dedup = AlertDeduplicator(cooldown_seconds=10.0)
    equip_id = uuid.uuid4()
    key = dedup.get_dedup_key(equip_id, "PHASE_IMBALANCE")

    alert_id = uuid.uuid4()
    dedup.register_alert(key, alert_id)

    # Operator resolves alert -> clear key
    dedup.clear_key(key)

    # Should no longer be suppressed
    suppress, record = dedup.should_suppress(key)
    assert suppress is False
