-- ============================================================
-- IEIP — Industrial Energy & Intelligence Platform
-- Database Schema Initialization & TimescaleDB Hypertables
-- ============================================================

-- 1. Enable Required Extensions
CREATE EXTENSION IF NOT EXISTS "uuid-ossp";
CREATE EXTENSION IF NOT EXISTS "timescaledb" CASCADE;

-- 2. Enumeration Types
DO $$ BEGIN
    CREATE TYPE user_role_enum AS ENUM ('ADMIN', 'OPERATOR', 'ENGINEER', 'VIEWER');
EXCEPTION
    WHEN duplicate_object THEN NULL;
END $$;

DO $$ BEGIN
    CREATE TYPE equipment_type_enum AS ENUM ('MOTOR', 'PUMP', 'COMPRESSOR', 'FAN', 'CONVEYOR', 'GENERATOR', 'OTHER');
EXCEPTION
    WHEN duplicate_object THEN NULL;
END $$;

DO $$ BEGIN
    CREATE TYPE operating_status_enum AS ENUM ('OPERATIONAL', 'WARNING', 'CRITICAL', 'OFFLINE', 'MAINTENANCE');
EXCEPTION
    WHEN duplicate_object THEN NULL;
END $$;

DO $$ BEGIN
    CREATE TYPE measurement_category_enum AS ENUM ('ELECTRICAL', 'TEMPERATURE', 'VIBRATION', 'PRESSURE', 'FLOW', 'OPERATIONAL');
EXCEPTION
    WHEN duplicate_object THEN NULL;
END $$;

DO $$ BEGIN
    CREATE TYPE protocol_type_enum AS ENUM ('SIMULATED', 'MQTT', 'MODBUS_TCP', 'MODBUS_RTU', 'OPC_UA');
EXCEPTION
    WHEN duplicate_object THEN NULL;
END $$;

DO $$ BEGIN
    CREATE TYPE anomaly_type_enum AS ENUM (
        'OVERCURRENT', 'UNDERVOLTAGE', 'OVERVOLTAGE', 'PHASE_IMBALANCE',
        'LOW_POWER_FACTOR', 'THERMAL_OVERLOAD', 'EXCESSIVE_VIBRATION',
        'OFF_HOURS_CONSUMPTION', 'UNEXPECTED_STOP', 'HARMONIC_DISTORTION', 'SENSOR_DRIFT'
    );
EXCEPTION
    WHEN duplicate_object THEN NULL;
END $$;

DO $$ BEGIN
    CREATE TYPE anomaly_severity_enum AS ENUM ('INFO', 'LOW', 'MEDIUM', 'HIGH', 'CRITICAL');
EXCEPTION
    WHEN duplicate_object THEN NULL;
END $$;

DO $$ BEGIN
    CREATE TYPE anomaly_status_enum AS ENUM ('DETECTED', 'CONFIRMED', 'FALSE_POSITIVE', 'RESOLVED');
EXCEPTION
    WHEN duplicate_object THEN NULL;
END $$;

DO $$ BEGIN
    CREATE TYPE alert_status_enum AS ENUM ('OPEN', 'ACKNOWLEDGED', 'RESOLVED', 'SUPPRESSED');
EXCEPTION
    WHEN duplicate_object THEN NULL;
END $$;

DO $$ BEGIN
    CREATE TYPE event_category_enum AS ENUM ('EQUIPMENT_STATE', 'FAULT_TRIP', 'OPERATOR_ACTION', 'SIMULATION_INJECTION', 'MAINTENANCE', 'SYSTEM');
EXCEPTION
    WHEN duplicate_object THEN NULL;
END $$;

DO $$ BEGIN
    CREATE TYPE rec_priority_enum AS ENUM ('LOW', 'MEDIUM', 'HIGH', 'IMMEDIATE');
EXCEPTION
    WHEN duplicate_object THEN NULL;
END $$;

DO $$ BEGIN
    CREATE TYPE rec_status_enum AS ENUM ('PENDING', 'IN_PROGRESS', 'IMPLEMENTED', 'DISMISSED');
EXCEPTION
    WHEN duplicate_object THEN NULL;
END $$;

-- 3. Core Relational Tables

-- Users
CREATE TABLE IF NOT EXISTS users (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    email VARCHAR(255) UNIQUE NOT NULL,
    hashed_password VARCHAR(255) NOT NULL,
    full_name VARCHAR(200) NOT NULL,
    role user_role_enum NOT NULL DEFAULT 'VIEWER',
    is_active BOOLEAN NOT NULL DEFAULT TRUE,
    is_superuser BOOLEAN NOT NULL DEFAULT FALSE,
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

-- Equipment Master
CREATE TABLE IF NOT EXISTS equipment (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    asset_code VARCHAR(50) UNIQUE NOT NULL,
    name VARCHAR(200) NOT NULL,
    description TEXT,
    equipment_type equipment_type_enum NOT NULL DEFAULT 'MOTOR',
    manufacturer VARCHAR(100),
    model VARCHAR(100),
    serial_number VARCHAR(100),
    location VARCHAR(200) NOT NULL,
    site_id VARCHAR(100) NOT NULL,
    rated_power_kw DOUBLE PRECISION,
    rated_voltage DOUBLE PRECISION,
    rated_current DOUBLE PRECISION,
    phases INTEGER DEFAULT 3,
    frequency_hz DOUBLE PRECISION DEFAULT 60.0,
    nominal_power_factor DOUBLE PRECISION DEFAULT 0.88,
    operating_status operating_status_enum NOT NULL DEFAULT 'OPERATIONAL',
    is_monitored BOOLEAN NOT NULL DEFAULT TRUE,
    installation_date DATE,
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);
CREATE INDEX IF NOT EXISTS idx_equipment_site ON equipment(site_id);
CREATE INDEX IF NOT EXISTS idx_equipment_status ON equipment(operating_status);

-- Measurement Points
CREATE TABLE IF NOT EXISTS measurement_points (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    equipment_id UUID NOT NULL REFERENCES equipment(id) ON DELETE CASCADE,
    point_code VARCHAR(50) UNIQUE NOT NULL,
    name VARCHAR(200) NOT NULL,
    category measurement_category_enum NOT NULL DEFAULT 'ELECTRICAL',
    protocol protocol_type_enum NOT NULL DEFAULT 'SIMULATED',
    mqtt_topic VARCHAR(255),
    modbus_slave_id INTEGER,
    modbus_register_address INTEGER,
    sampling_interval_sec DOUBLE PRECISION NOT NULL DEFAULT 1.0,
    is_active BOOLEAN NOT NULL DEFAULT TRUE,
    description TEXT,
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);
CREATE INDEX IF NOT EXISTS idx_mp_equipment ON measurement_points(equipment_id);

-- 4. TimescaleDB Telemetry Readings Hypertable
CREATE TABLE IF NOT EXISTS telemetry_readings (
    time TIMESTAMPTZ NOT NULL,
    measurement_point_id UUID NOT NULL REFERENCES measurement_points(id) ON DELETE CASCADE,
    equipment_id UUID NOT NULL REFERENCES equipment(id) ON DELETE CASCADE,
    voltage_l1 DOUBLE PRECISION,
    voltage_l2 DOUBLE PRECISION,
    voltage_l3 DOUBLE PRECISION,
    voltage_avg DOUBLE PRECISION,
    current_l1 DOUBLE PRECISION,
    current_l2 DOUBLE PRECISION,
    current_l3 DOUBLE PRECISION,
    current_avg DOUBLE PRECISION,
    active_power_kw DOUBLE PRECISION,
    reactive_power_kvar DOUBLE PRECISION,
    apparent_power_kva DOUBLE PRECISION,
    power_factor DOUBLE PRECISION,
    frequency_hz DOUBLE PRECISION,
    energy_kwh DOUBLE PRECISION,
    current_unbalance_pct DOUBLE PRECISION,
    voltage_unbalance_pct DOUBLE PRECISION,
    thd_current_pct DOUBLE PRECISION,
    thd_voltage_pct DOUBLE PRECISION,
    temperature_c DOUBLE PRECISION,
    vibration_rms_mms DOUBLE PRECISION,
    operating_state VARCHAR(30) DEFAULT 'RUNNING',
    load_pct DOUBLE PRECISION,
    is_simulated BOOLEAN NOT NULL DEFAULT TRUE,
    quality_code INTEGER NOT NULL DEFAULT 192,
    PRIMARY KEY (time, measurement_point_id)
);

-- Convert to Hypertable with 1-day chunk interval
SELECT create_hypertable('telemetry_readings', 'time', if_not_exists => TRUE, chunk_time_interval => INTERVAL '1 day');

CREATE INDEX IF NOT EXISTS idx_telemetry_equip_time ON telemetry_readings(equipment_id, time DESC);

-- 5. Anomaly Detection Records
CREATE TABLE IF NOT EXISTS anomalies (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    equipment_id UUID NOT NULL REFERENCES equipment(id) ON DELETE CASCADE,
    measurement_point_id UUID REFERENCES measurement_points(id) ON DELETE SET NULL,
    detected_at TIMESTAMPTZ NOT NULL,
    anomaly_type anomaly_type_enum NOT NULL,
    severity anomaly_severity_enum NOT NULL,
    status anomaly_status_enum NOT NULL DEFAULT 'DETECTED',
    algorithm_used VARCHAR(100) NOT NULL,
    metric_name VARCHAR(100) NOT NULL,
    observed_value DOUBLE PRECISION NOT NULL,
    expected_value DOUBLE PRECISION,
    threshold_value DOUBLE PRECISION,
    deviation_pct DOUBLE PRECISION,
    confidence_score DOUBLE PRECISION NOT NULL DEFAULT 1.0,
    description TEXT NOT NULL,
    context_snapshot JSONB,
    resolved_at TIMESTAMPTZ,
    resolution_notes TEXT,
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);
CREATE INDEX IF NOT EXISTS idx_anomalies_equip_detected ON anomalies(equipment_id, detected_at DESC);
CREATE INDEX IF NOT EXISTS idx_anomalies_status ON anomalies(status);

-- 6. Alerts
CREATE TABLE IF NOT EXISTS alerts (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    equipment_id UUID NOT NULL REFERENCES equipment(id) ON DELETE CASCADE,
    anomaly_id UUID REFERENCES anomalies(id) ON DELETE SET NULL,
    dedup_key VARCHAR(255) NOT NULL,
    title VARCHAR(200) NOT NULL,
    message TEXT NOT NULL,
    severity anomaly_severity_enum NOT NULL,
    status alert_status_enum NOT NULL DEFAULT 'OPEN',
    occurrence_count INTEGER NOT NULL DEFAULT 1,
    first_triggered_at TIMESTAMPTZ NOT NULL,
    last_triggered_at TIMESTAMPTZ NOT NULL,
    acknowledged_at TIMESTAMPTZ,
    acknowledged_by_id UUID REFERENCES users(id) ON DELETE SET NULL,
    resolved_at TIMESTAMPTZ,
    resolved_by_id UUID REFERENCES users(id) ON DELETE SET NULL,
    resolution_comment TEXT,
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);
CREATE INDEX IF NOT EXISTS idx_alerts_status_sev ON alerts(status, severity);
CREATE INDEX IF NOT EXISTS idx_alerts_equip ON alerts(equipment_id);

-- 7. Operational Events (Historian)
CREATE TABLE IF NOT EXISTS operational_events (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    equipment_id UUID REFERENCES equipment(id) ON DELETE CASCADE,
    user_id UUID REFERENCES users(id) ON DELETE SET NULL,
    event_time TIMESTAMPTZ NOT NULL,
    category event_category_enum NOT NULL,
    event_name VARCHAR(150) NOT NULL,
    description TEXT NOT NULL,
    source VARCHAR(100) NOT NULL DEFAULT 'SYSTEM',
    payload JSONB,
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);
CREATE INDEX IF NOT EXISTS idx_events_time_cat ON operational_events(event_time DESC, category);

-- 8. Condition-Based Maintenance Recommendations
CREATE TABLE IF NOT EXISTS maintenance_recommendations (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    equipment_id UUID NOT NULL REFERENCES equipment(id) ON DELETE CASCADE,
    anomaly_id UUID REFERENCES anomalies(id) ON DELETE SET NULL,
    title VARCHAR(200) NOT NULL,
    technical_rationale TEXT NOT NULL,
    suggested_actions TEXT NOT NULL,
    priority rec_priority_enum NOT NULL DEFAULT 'MEDIUM',
    status rec_status_enum NOT NULL DEFAULT 'PENDING',
    estimated_monthly_kwh_waste DOUBLE PRECISION,
    estimated_monthly_cost_usd DOUBLE PRECISION,
    implemented_at TIMESTAMPTZ,
    implemented_by_id UUID REFERENCES users(id) ON DELETE SET NULL,
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);
CREATE INDEX IF NOT EXISTS idx_maint_equip_status ON maintenance_recommendations(equipment_id, status);
