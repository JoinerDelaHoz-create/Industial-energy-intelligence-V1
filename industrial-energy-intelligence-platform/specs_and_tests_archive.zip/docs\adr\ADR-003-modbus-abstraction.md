# ADR-003: Capa de Abstracción Modbus TCP / RTU sin Dependencia de Hardware

## Estado
Aceptado.

## Contexto
Los analizadores de redes eléctricas industriales (Schneider PM5350, Siemens PAC3200, etc.) utilizan Modbus como protocolo principal. Sin embargo, los mapas de registros (Holding Registers vs Input Registers) difieren por modelo y no se puede asumir hardware físico durante demostraciones o desarrollo local.

## Decisión
Diseñar la clase abstracta `ModbusDataSource` utilizando `pymodbus` (versión >=3.15.0), con mapas de registros desacoplados definidos mediante diccionarios y tipos de datos normalizados (`uint16`, `int32`, `float32`). Se provee un mapa de registros de demostración claramente etiquetado para simulación y pruebas.

## Consecuencias
- **Positivas**: El código de la aplicación no depende de ningún hardware específico; se puede conectar a analizadores reales o a simuladores Modbus (ej. ModRSsim2 o slave virtual) simplemente suministrando un archivo de mapeo.
- **Negativas / Compensaciones**: La configuración inicial para un nuevo modelo de medidor en campo requiere cargar y validar su mapa de registros particular.
