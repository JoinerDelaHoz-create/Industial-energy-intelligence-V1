# IEIP — Limitaciones Actuales y Hoja de Ruta (Roadmap)

## 1. Limitaciones Técnicas del Prototipo Actual
Como prototipo técnico orientado a portafolio profesional y demostración de capacidades, IEIP declara con total transparencia las siguientes delimitaciones funcionales:

1. **Adquisición Frecuencial / Formas de Onda Brutas**:
   - La plataforma procesa valores eficaces (RMS), potencias medias, ángulos y THD global agregada calculada por la instrumentación en campo. No almacena oscilogramas a 50 kHz ni transitorios de conmutación sub-milisegundo (oscilografía de relés de protección microprocesados).
2. **Estimación de Degradación de Aislamiento**:
   - El índice de salud térmica se calcula a partir de elevación de temperatura continua y desbalance sostenido. No sustituye pruebas destructivas o de descarga parcial (PD / Tan Delta) ejecutadas fuera de servicio.
3. **Persistencia del Cooldown de Alarmas**:
   - El deduplicador ISA 18.2 almacena las marcas de tiempo de enfriamiento en la memoria de la instancia backend. En despliegues multi-nodo distribuidos se requeriría una capa de caché compartida (ej. Redis) para sincronizar el estado entre réplicas.

---

## 2. Hoja de Ruta (Future Roadmap)

- [ ] **Soporte Nativo OPC UA (IEC 62541)** con exploración de espacios de direcciones (`Browse Tree`).
- [ ] **Módulo de MCSA (Motor Current Signature Analysis)**: Análisis espectral FFT sobre corrientes de estator para detección de barras rotas de rotor y excentricidad dinámica.
- [ ] **Cálculo de Huella de Carbono Automática**: Conversión dinámica de kWh a $kg\text{ CO}_2e$ según factor de emisión del Sistema Interconectado Nacional.
- [ ] **Exportación Automática a CMMS Existentes**: Webhooks a SAP PM e IBM Maximo mediante API REST.
