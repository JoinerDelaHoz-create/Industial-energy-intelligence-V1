# IEIP — Guía de Integración en Planta Industrial Real

## 1. Arquitectura de Red y Modelo Purdue (ISA-95)
Para garantizar la ciberseguridad industrial y el aislamiento de las redes de control de procesos (OT) respecto a las redes corporativas (IT), IEIP se integra siguiendo los niveles del Modelo Purdue:

```
[ Nivel 4 / 5: Red Corporativa / Cloud ] ◄── Dashboard Web IEIP, Reportes de Gerencia
                      ▲
                      │ Firewall IT/OT (Zona Desmilitarizada Industrial - IDMZ)
                      ▼
[ Nivel 3: Operaciones de Planta / OT  ] ◄── Servidor Central IEIP (TimescaleDB + Backend)
                      ▲
                      │ Red de Supervisión Ethernet Industrial
                      ▼
[ Nivel 2: Control / SCADA / HMI      ] ◄── Servidores OPC UA / Pasarelas MQTT / Historiador
                      ▲
                      │ Buses de Campo (Modbus TCP, Profinet, Ethernet/IP)
                      ▼
[ Nivel 1: Control Básico (PLCs, VFDs)] ◄── PLCs Siemens S7-1500 / Allen-Bradley ControlLogix
                      ▲
                      │ Cableado de Señales / Transformadores de Corriente (TCs)
                      ▼
[ Nivel 0: Proceso Físico             ] ◄── Motores, Bombas, Medidores PM5000, Sensores RTD Pt100
```

---

## 2. Recomendaciones de Instrumentación Eléctrica en Campo

1. **Transformadores de Corriente (TCs / CTs)**:
   - Utilizar TCs de núcleo partido clase 0.5 o 0.2S (ej. 150/5A o 200/5A) para garantizar precisión metrológica sin necesidad de desconectar barras de fuerza.
   - Polaridad ($P_1/H_1$ hacia la fuente, $P_2/H_2$ hacia la carga): una inversión accidental provocará cálculo de factor de potencia negativo o potencia activa inversa errónea.
2. **Medición de Tensión**:
   - Conexión directa para sistemas trifásicos hasta 480 V CA con fusibles de protección tipo gG (2 A a 4 A) inmediatamente aguas abajo del embarrado.
3. **Sensores de Temperatura y Vibración**:
   - RTDs Pt100 de 3 hilos o 4 hilos montados en la carcasa del motor o embebidos en el devanado estatórico.
   - Acelerómetros piezoeléctricos industriales (4-20 mA o IEPE con salida RMS) fijados magnéticamente o roscados en los alojamientos de rodamientos lado accionamiento (DE) y lado opuesto (NDE).
