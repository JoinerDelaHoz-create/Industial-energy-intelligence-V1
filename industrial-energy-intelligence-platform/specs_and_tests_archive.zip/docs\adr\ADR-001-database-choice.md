# ADR-001: Elección del Motor de Base de Datos de Series Temporales (TimescaleDB)

## Estado
Aceptado.

## Contexto
IEIP gestiona telemetría eléctrica trifásica, variables térmicas y de vibración a frecuencias de 1 a 5 Hz por activo industrial. El sistema requiere:
1. Alta tasa de ingestión y compresión eficiente de series temporales.
2. Integridad referencial con entidades relacionales (equipos, puntos de medición, órdenes de inspección, usuarios).
3. Consultas SQL complejas que crucen telemetría agregada (`time_bucket`) con parámetros nominales de placa.

## Decisión
Adoptar **TimescaleDB** como extensión sobre PostgreSQL 16/17 en lugar de InfluxDB o MongoDB.

## Consecuencias
- **Positivas**:
  - Un único motor de base de datos para datos relacionales y series temporales (reduce la superficie operativa en Docker).
  - Integridad referencial completa con foreign keys.
  - Hypertables con compresión columnar automática (>90% de ahorro en almacenamiento tras 7 días).
  - Compatibilidad total con herramientas del ecosistema PostgreSQL (pgAdmin, DBeaver, SQLAlchemy).
- **Negativas / Compensaciones**:
  - InfluxDB 3.0 presenta una ligera ventaja en escenarios con millones de escrituras distribuidas por segundo. Para el alcance del MVP y flotas medianas de plantas, TimescaleDB ofrece un rendimiento superior con menor complejidad de mantenimiento.
