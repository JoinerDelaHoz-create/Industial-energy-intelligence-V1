# IEIP — Guía de Despliegue y Operación (DEPLOYMENT)

## 1. Requisitos de Infraestructura

### 1.1 Entorno On-Premise Industrial (Recomendado)
- **Servidor Físico o VM**: Servidor industrial o máquina virtual (VMware ESXi, Proxmox, Hyper-V, Ubuntu Server 22.04 LTS).
- **CPU**: 4 Cores x86-64 (mínimo) / 8 Cores (para flotas >50 equipos a 1 Hz).
- **Memoria RAM**: 8 GB (mínimo) / 16 GB (recomendado).
- **Almacenamiento**: SSD NVMe con al menos 100 GB para datos de series temporales particionadas en TimescaleDB.

---

## 2. Puesta en Producción con Docker Compose

```bash
# 1. Clonar el repositorio en el servidor de planta
git clone https://github.com/tu-usuario/industrial-energy-intelligence-platform.git
cd industrial-energy-intelligence-platform

# 2. Configurar variables de entorno productivas
cp .env.example .env
# Editar .env estableciendo contraseñas robustas y SECRET_KEY única:
# POSTGRES_PASSWORD=ClaveRobustaGenerada_1234
# SECRET_KEY=LlaveCriptograficaAleatoriaSegura

# 3. Lanzar contenedores en modo detached
docker compose -f docker-compose.yml up -d --build

# 4. Verificar estado de contenedores
docker compose ps
docker compose logs -f backend
```

---

## 3. Políticas de Retención de Datos en TimescaleDB
Para evitar la saturación de disco tras meses de operación continua a 1 Hz:

```sql
-- Ejecutar en PostgreSQL / TimescaleDB para retención automática
-- 1. Mantener datos brutos segundo a segundo durante 30 días:
SELECT add_retention_policy('telemetry_readings', INTERVAL '30 days');

-- 2. Comprimir chunks con más de 7 días de antigüedad (tasa de compresión ~90%):
ALTER TABLE telemetry_readings SET (
  timescaledb.compress,
  timescaledb.compress_segmentby = 'equipment_id',
  timescaledb.compress_orderby = 'time DESC'
);
SELECT add_compression_policy('telemetry_readings', INTERVAL '7 days');
```
