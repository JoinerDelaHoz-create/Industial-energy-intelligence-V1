# IEIP — Estrategia y Ejecución de Pruebas (TESTING)

## 1. Niveles de Pruebas
La suite de pruebas de IEIP cubre tres niveles críticos:
1. **Pruebas Unitarias de Modelos Físicos**: Validan que las ecuaciones de potencia activa, reactiva, factor de potencia y balance trifásico del gemelo digital respondan fielmente a las leyes de la física electromagnética.
2. **Pruebas Unitarias de Detección de Anomalías**: Validan que desbalances NEMA severos, huecos de tensión, sobrecorrientes y sobrecalentamientos disparen las clasificaciones correctas sin falsos positivos en operación nominal.
3. **Pruebas de Deduplicación ISA 18.2**: Validan que repeticiones dentro de la ventana de enfriamiento no generen registros duplicados y que la resolución por operador limpie adecuadamente el estado.

---

## 2. Comandos de Ejecución

### Ejecución de Pruebas Unitarias con Pytest:
```bash
cd backend
pytest tests/unit -v --durations=10
```

### Ejecución de Pruebas Específicas:
```bash
# Probar motor de inducción físico:
pytest tests/unit/test_motor_model.py -v

# Probar desbalance de fases NEMA:
pytest tests/unit/test_imbalance.py -v

# Probar supresión y deduplicación de alarmas:
pytest tests/unit/test_alert_deduplication.py -v
```
