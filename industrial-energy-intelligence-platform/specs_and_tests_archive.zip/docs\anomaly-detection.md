# IEIP — Motor de Detección de Anomalías Industriales

## 1. Fundamento Matemático y Normativo

El motor de analítica de IEIP implementa una arquitectura híbrida de detección en capas para monitoreo continuo de activos electromecánicos:

```
[Lectura Telemetría] 
        │
        ├──► 1. Reglas Determinísticas (Límites de Placa & Estándares)
        ├──► 2. Desbalance de Fases (NEMA MG-1 & Derating Térmico)
        ├──► 3. Análisis de Factor de Potencia (IEEE & Compensación Reactiva)
        ├──► 4. Detector Estadístico Dinámico (Rolling Z-Score |Z| > 3.2σ)
        └──► 5. Desviación de Línea Base (Horarios No Productivos / Fuga de kWh)
        │
[Candidatos a Anomalía] ──► [Deduplicador & Supresor ISA 18.2] ──► [Alertas & Prescripción]
```

---

## 2. Métodos de Detección

### 2.1 Sobrecorriente (Overcurrent)
- **Parámetro**: Corriente media trifásica $I_{avg} = (I_{L1} + I_{L2} + I_{L3})/3$.
- **Límite**: $I_{avg} > 1.10 \times \text{FLA}$ (Full Load Amps de placa).
- **Severidad**: 
  - $1.10 \times \text{FLA} \le I_{avg} < 1.30 \times \text{FLA}$: **HIGH**.
  - $I_{avg} \ge 1.30 \times \text{FLA}$: **CRITICAL**.

### 2.2 Desbalance de Fases NEMA MG-1
- **Fórmula**:
  $$\% \text{Desbalance} = \frac{\max(|I_{phase} - I_{avg}|)}{I_{avg}} \times 100\%$$
- **Penalización Térmica y Derating**:
  Un 1% de desbalance de tensión produce típicamente entre 6% y 10% de desbalance de corriente debido a la baja impedancia de secuencia negativa del rotor. El factor de desclasificación estimado se calcula como:
  $$k_{derating} = 1.0 - 0.02 \times (\% \text{Desbalance})$$

### 2.3 Factor de Potencia y Dimensionamiento Reactivo
- **Límite**: $PF < 0.85$ (con potencia activa $P > 3\text{ kW}$).
- **Cálculo de Banco de Condensadores Requerido**:
  $$Q_c = P \cdot \left[\tan(\arccos(PF_{actual})) - \tan(\arccos(0.95))\right]$$

### 2.4 Detección Estadística por Z-Score Móvil
Para capturar anomalías sutiles o derivas en variables donde no existe un umbral fijo único, se mantiene una ventana rodante Welford de $N=60$ muestras:
$$Z = \frac{x_t - \mu_{window}}{\sigma_{window}}$$
Si $|Z| \ge 3.2$, la muestra se cataloga como anomalía estadística con un índice de confianza:
$$C = \min\left(0.99, 0.70 + \frac{|Z|}{15.0}\right)$$

### 2.5 Consumo Fantasma Fuera de Turno
Evalúa potencia activa ($P > 20\% P_{nom}$) durante fines de semana, turno nocturno o cuando el estado operativo declarado es `IDLE` o `STOPPED`. Cuantifica el desperdicio en kWh y costo financiero en USD a tarifa industrial estándar ($0.14 USD/kWh).
