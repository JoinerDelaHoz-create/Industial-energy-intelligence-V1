# IEIP — Arquitectura Integral de la Plataforma (docs/architecture.md)

Este documento detalla la arquitectura de software, flujo de datos, modelo de capas y topología de despliegue de **IEIP (Industrial Energy & Intelligence Platform)**.

---

## 1. Diagrama de Arquitectura del Sistema

```mermaid
graph TD
    subgraph DataSources["Fuentes de Adquisición (Capa de Campo / Edge)"]
        SIM["SimulatorDataSource<br/>(Gemelo Digital MTR-305 + AR1 Noise)"]
        MQTT_SRC["MQTTDataSource<br/>(aiomqtt Client)"]
        MODBUS_SRC["ModbusDataSource<br/>(pymodbus Client)"]
    end

    subgraph Broker["Mensajería Industrial"]
        MOSQUITTO["Eclipse Mosquitto MQTT Broker<br/>Port 1883"]
    end

    subgraph Backend["IEIP Backend (Monolito Modular FastAPI)"]
        ACQ_MGR["AcquisitionManager"]
        INGEST["IngestionPipelineService<br/>(Validación de calidad y metrología)"]
        
        subgraph AnalyticsEngine["Motor Analítico Multinivel"]
            TH["ThresholdDetector<br/>(Nivel 1: Límites nominales)"]
            STAT["StatisticalDetector<br/>(Nivel 2: Z-Score móvil)"]
            IMB["PhaseImbalanceDetector<br/>(Nivel 3: NEMA MG-1)"]
            PF["PowerFactorDetector<br/>(Nivel 3: Penalización reactiva)"]
        end

        ALERT_ENG["AlertDeduplicator & State Machine<br/>(ISA 18.2 Cooldown & Deduplication)"]
        API_ROUTER["FastAPI REST Router (/api/v1)<br/>(Auth, Telemetry, KPIs, Equipment, Reports)"]
        EVENT_BUS["Internal Event Broadcaster"]
    end

    subgraph Storage["Persistencia de Datos (TimescaleDB / PostgreSQL)"]
        HYPER["Hypertable: telemetry_readings<br/>(Chunks diarios + Compresión 7 días)"]
        REL["Tablas Relacionales:<br/>equipment, measurement_points, alerts, events, users"]
    end

    subgraph Frontend["Capa de Presentación"]
        DASHBOARD["Dashboard Industrial SCADA<br/>(Diales trifásicos, Factor de Potencia, Gráficos en tiempo real)"]
        SCENARIO_CTRL["Panel de Simulación de Fallas<br/>(Inyección de escenarios en 1-click)"]
    end

    SIM --> ACQ_MGR
    MOSQUITTO --> MQTT_SRC --> ACQ_MGR
    MODBUS_SRC --> ACQ_MGR
    ACQ_MGR --> INGEST
    INGEST --> AnalyticsEngine
    AnalyticsEngine --> ALERT_ENG
    ALERT_ENG --> REL
    INGEST --> HYPER
    AnalyticsEngine --> REL
    
    API_ROUTER --> Storage
    API_ROUTER --> DASHBOARD
    SCENARIO_CTRL --> API_ROUTER
    EVENT_BUS --> DASHBOARD
```

---

## 2. Diagrama de Flujo de Datos (Data Flow)

```mermaid
sequenceDiagram
    autonumber
    participant Dev as Dispositivo / Gemelo Digital
    participant Broker as Mosquitto MQTT Broker
    participant Ingest as Pipeline de Ingesta (IEIP)
    participant Engine as Motor de Analítica
    participant Dedup as Gestor de Alarmas (ISA 18.2)
    participant DB as TimescaleDB
    participant UI as Dashboard Industrial

    Dev->>Broker: Publica telemetría a ieip/caribe/MTR-305/telemetry
    Broker->>Ingest: Notifica mensaje JSON QoS 1
    Ingest->>Ingest: Valida timestamp y calidad de señal (GOOD/UNCERTAIN/BAD)
    par Persistencia de Series Temporales
        Ingest->>DB: Inserción directa en Hypertable telemetry_readings
    and Evaluación Analítica
        Ingest->>Engine: Envía vector trifásico (V, I, kW, PF, THD)
        Engine->>Engine: Evalúa desbalance de corriente (NEMA MG-1)
        Engine->>Engine: Evalúa Z-Score dinámico sobre ventana móvil
        alt Anomalía Detectada
            Engine->>Dedup: Emite AnomalyCandidate
            Dedup->>Dedup: Calcula fingerprint SHA-256 y verifica cooldown
            alt Alarma Nueva / Cooldown Expirado
                Dedup->>DB: Registra/Actualiza Alerta (Status: OPEN)
                Dedup->>UI: Transmite evento de alarma inmediata
            else Dentro de ventana de Cooldown
                Dedup->>DB: Incrementa contador occurrence_count (Supresión)
            end
        end
    end
    UI->>DB: Polling de KPIs agregados y diales en vivo (1 Hz)
```

---

## 3. Diagrama de Despliegue (Deployment Topology)

```mermaid
graph TB
    subgraph Host["Host Docker / Servidor Industrial"]
        subgraph Net["Red Interna Docker (ieip-net)"]
            DB_SRV["db: timescale/timescaledb:latest-pg16<br/>Port 5432"]
            MQTT_SRV["mqtt: eclipse-mosquitto:2.0<br/>Port 1883"]
            BACK_SRV["backend: Python 3.12 + FastAPI<br/>Port 8000"]
            FRONT_SRV["frontend: Nginx + Vite Build<br/>Port 80"]
        end

        EXT_PORTS["Puertos Expuestos al Host:<br/>- 8000 (Backend API & UI)<br/>- 1883 (MQTT Broker)<br/>- 5432 (TimescaleDB)"]
    end

    BACK_SRV --> DB_SRV
    BACK_SRV --> MQTT_SRV
    FRONT_SRV --> BACK_SRV
```

---

## 4. Estándares y Normas Técnicas Incorporadas

| Norma / Estándar | Ámbito de Aplicación en IEIP |
|---|---|
| **NEMA MG-1 (Part 14)** | Cálculo de desbalance de tensión y corriente en motores de inducción con derating factor. |
| **IEEE 519** | Monitoreo de distorsión armónica total (THD) y límites recomendados en el punto de acoplamiento común. |
| **ISO 10816-3** | Clasificación de severidad de vibración mecánica para máquinas industriales (Clase I-IV). |
| **ISA 18.2** | Gestión del ciclo de vida de alarmas (Open, Acknowledged, Resolved) con deduplicación y prevención de inundación (*alarm flood*). |
| **RFC 4180** | Formato canónico de exportación de auditorías energéticas en CSV. |
