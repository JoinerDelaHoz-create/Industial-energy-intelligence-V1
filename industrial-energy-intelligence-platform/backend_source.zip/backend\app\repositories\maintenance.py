"""
IEIP Repositories — Maintenance Recommendation Repository
"""

from __future__ import annotations

import uuid
from typing import Sequence

from sqlalchemy import desc, select
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy.orm import selectinload

from app.models.maintenance import MaintenanceRecommendation, RecommendationStatus
from app.repositories.base import BaseRepository


class MaintenanceRepository(BaseRepository[MaintenanceRecommendation]):
    """Repository for condition-based maintenance recommendations."""

    def __init__(self, session: AsyncSession) -> None:
        super().__init__(MaintenanceRecommendation, session)

    async def list_for_equipment(
        self,
        equipment_id: uuid.UUID,
        status: RecommendationStatus | None = None,
    ) -> Sequence[MaintenanceRecommendation]:
        stmt = (
            select(MaintenanceRecommendation)
            .where(MaintenanceRecommendation.equipment_id == equipment_id)
            .options(
                selectinload(MaintenanceRecommendation.equipment),
                selectinload(MaintenanceRecommendation.anomaly),
            )
        )
        if status:
            stmt = stmt.where(MaintenanceRecommendation.status == status)

        stmt = stmt.order_by(desc(MaintenanceRecommendation.created_at))
        res = await self.session.execute(stmt)
        return res.scalars().all()

    async def list_all_active(self) -> Sequence[MaintenanceRecommendation]:
        stmt = (
            select(MaintenanceRecommendation)
            .where(
                MaintenanceRecommendation.status.in_(
                    [RecommendationStatus.PENDING, RecommendationStatus.IN_PROGRESS]
                )
            )
            .options(
                selectinload(MaintenanceRecommendation.equipment),
                selectinload(MaintenanceRecommendation.anomaly),
            )
            .order_by(desc(MaintenanceRecommendation.created_at))
        )
        res = await self.session.execute(stmt)
        return res.scalars().all()
