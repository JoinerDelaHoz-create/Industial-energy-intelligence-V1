"""
IEIP Repositories — Equipment Repository
"""

from __future__ import annotations

import uuid
from typing import Sequence

from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy.orm import selectinload

from app.models.equipment import Equipment, OperatingStatus
from app.repositories.base import BaseRepository


class EquipmentRepository(BaseRepository[Equipment]):
    """Equipment asset master repository."""

    def __init__(self, session: AsyncSession) -> None:
        super().__init__(Equipment, session)

    async def get_by_asset_code(self, asset_code: str) -> Equipment | None:
        stmt = (
            select(Equipment)
            .where(Equipment.asset_code == asset_code)
            .options(selectinload(Equipment.measurement_points))
        )
        res = await self.session.execute(stmt)
        return res.scalar_one_or_none()

    async def list_fleet(
        self,
        site_id: str | None = None,
        status: OperatingStatus | None = None,
        skip: int = 0,
        limit: int = 100,
    ) -> Sequence[Equipment]:
        stmt = select(Equipment).options(selectinload(Equipment.measurement_points))
        if site_id:
            stmt = stmt.where(Equipment.site_id == site_id)
        if status:
            stmt = stmt.where(Equipment.operating_status == status)

        stmt = stmt.offset(skip).limit(limit)
        res = await self.session.execute(stmt)
        return res.scalars().all()
