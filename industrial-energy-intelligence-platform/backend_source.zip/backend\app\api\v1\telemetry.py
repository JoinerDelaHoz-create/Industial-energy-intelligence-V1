"""
IEIP API v1 — Telemetry Ingestion & Aggregation Endpoints
"""

from __future__ import annotations

import uuid
from datetime import datetime

from fastapi import APIRouter, Depends, Query, status
from sqlalchemy.ext.asyncio import AsyncSession

from app.acquisition.base import RawTelemetryPayload
from app.dependencies import get_db, get_optional_user
from app.models.user import User
from app.repositories.telemetry import TelemetryRepository
from app.schemas.common import APIResponse
from app.schemas.telemetry import AggregationBucket, TelemetryIngest, TelemetryResponse
from app.telemetry.ingestion import IngestionPipelineService

router = APIRouter(prefix="/telemetry", tags=["Telemetry Ingestion & Queries"])


@router.post("/ingest", response_model=APIResponse[dict], status_code=status.HTTP_201_CREATED)
async def ingest_telemetry_reading(payload: TelemetryIngest):
    """External HTTP ingestion endpoint for edge gateways / IoT field devices."""
    service = IngestionPipelineService.get_instance()
    raw = RawTelemetryPayload(
        source_id="HTTP_API",
        equipment_code=str(payload.equipment_id),
        measurement_point_code=str(payload.measurement_point_id),
        timestamp=payload.time,
        voltage_l1=payload.voltage_l1,
        voltage_l2=payload.voltage_l2,
        voltage_l3=payload.voltage_l3,
        voltage_avg=payload.voltage_avg,
        current_l1=payload.current_l1,
        current_l2=payload.current_l2,
        current_l3=payload.current_l3,
        current_avg=payload.current_avg,
        active_power_kw=payload.active_power_kw,
        reactive_power_kvar=payload.reactive_power_kvar,
        apparent_power_kva=payload.apparent_power_kva,
        power_factor=payload.power_factor,
        frequency_hz=payload.frequency_hz,
        energy_kwh=payload.energy_kwh,
        current_unbalance_pct=payload.current_unbalance_pct,
        voltage_unbalance_pct=payload.voltage_unbalance_pct,
        thd_current_pct=payload.thd_current_pct,
        thd_voltage_pct=payload.thd_voltage_pct,
        temperature_c=payload.temperature_c,
        vibration_rms_mms=payload.vibration_rms_mms,
        operating_state=payload.operating_state or "RUNNING",
        load_pct=payload.load_pct,
        is_simulated=payload.is_simulated,
        quality_code=payload.quality_code,
    )
    result = await service.ingest_payload(raw)
    return APIResponse(
        message="Telemetry ingested and evaluated successfully",
        data={"persisted": result is not None, "time": payload.time.isoformat()},
    )


@router.get("/buckets", response_model=APIResponse[list[dict]])
async def get_time_buckets(
    equipment_id: uuid.UUID,
    interval: str = Query("5 minutes", description="PostgreSQL interval, e.g. 1 minute, 5 minutes, 1 hour"),
    start_time: datetime | None = None,
    end_time: datetime | None = None,
    db: AsyncSession = Depends(get_db),
    _user: User | None = Depends(get_optional_user),
):
    """Execute analytical time_bucket aggregation over TimescaleDB hypertable."""
    telem_repo = TelemetryRepository(db)
    buckets = await telem_repo.get_aggregated_buckets(
        equipment_id=equipment_id,
        bucket_interval=interval,
        start_time=start_time,
        end_time=end_time,
    )
    return APIResponse(data=buckets)
