"""
IEIP Backend — Equipment Schemas
"""

from __future__ import annotations

import uuid
from datetime import date, datetime
from pydantic import BaseModel, ConfigDict, Field

from app.models.equipment import EquipmentType, OperatingStatus
from app.schemas.measurement_point import MeasurementPointResponse


class EquipmentBase(BaseModel):
    asset_code: str = Field(min_length=2, max_length=50)
    name: str = Field(min_length=2, max_length=200)
    description: str | None = None
    equipment_type: EquipmentType = EquipmentType.MOTOR
    manufacturer: str | None = None
    model: str | None = None
    serial_number: str | None = None
    location: str = Field(min_length=2, max_length=200)
    site_id: str = Field(min_length=2, max_length=100)
    rated_power_kw: float | None = Field(None, gt=0)
    rated_voltage: float | None = Field(None, gt=0)
    rated_current: float | None = Field(None, gt=0)
    phases: int | None = Field(None, ge=1, le=3)
    frequency_hz: float | None = Field(None, gt=0)
    nominal_power_factor: float | None = Field(None, ge=0.0, le=1.0)
    operating_status: OperatingStatus = OperatingStatus.OPERATIONAL
    is_monitored: bool = True
    installation_date: date | None = None


class EquipmentCreate(EquipmentBase):
    pass


class EquipmentUpdate(BaseModel):
    name: str | None = None
    description: str | None = None
    equipment_type: EquipmentType | None = None
    manufacturer: str | None = None
    model: str | None = None
    serial_number: str | None = None
    location: str | None = None
    site_id: str | None = None
    rated_power_kw: float | None = None
    rated_voltage: float | None = None
    rated_current: float | None = None
    phases: int | None = None
    frequency_hz: float | None = None
    nominal_power_factor: float | None = None
    operating_status: OperatingStatus | None = None
    is_monitored: bool | None = None
    installation_date: date | None = None


class EquipmentResponse(EquipmentBase):
    model_config = ConfigDict(from_attributes=True)

    id: uuid.UUID
    created_at: datetime
    updated_at: datetime
    measurement_points: list[MeasurementPointResponse] = []


class EquipmentSummary(BaseModel):
    model_config = ConfigDict(from_attributes=True)

    id: uuid.UUID
    asset_code: str
    name: str
    equipment_type: EquipmentType
    location: str
    site_id: str
    operating_status: OperatingStatus
    is_monitored: bool
    rated_power_kw: float | None
    current_active_power_kw: float | None = None
    current_power_factor: float | None = None
    current_temperature_c: float | None = None
    active_anomalies_count: int = 0
    active_alerts_count: int = 0
