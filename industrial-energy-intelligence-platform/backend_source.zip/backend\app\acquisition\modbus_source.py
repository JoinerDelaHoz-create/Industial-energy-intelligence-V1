"""
IEIP Acquisition — Modbus TCP/RTU Data Source

Implements polling over Modbus TCP for industrial power analyzers and multi-function meters
(e.g. Schneider PM5000 / PM8000, Socomec Diris, Siemens SENTRON PAC).
"""

from __future__ import annotations

import asyncio
from typing import AsyncGenerator

from app.acquisition.base import BaseDataSource, RawTelemetryPayload
from app.core.logging import get_logger

logger = get_logger("ieip.acquisition.modbus")


class ModbusDataSource(BaseDataSource):
    """Acquisition source communicating via Modbus TCP."""

    def __init__(
        self,
        host: str = "127.0.0.1",
        port: int = 502,
        slave_id: int = 1,
        source_name: str = "ModbusTCPBridge",
    ) -> None:
        super().__init__(source_name=source_name)
        self.host = host
        self.port = port
        self.slave_id = slave_id
        self._queue: asyncio.Queue[RawTelemetryPayload] = asyncio.Queue(maxsize=100)
        self._poll_task: asyncio.Task | None = None

    async def connect(self) -> None:
        """Initialize Modbus polling loop."""
        self._is_connected = True
        logger.info(f"Modbus TCP source initialized for {self.host}:{self.port} (Slave {self.slave_id})")

    async def disconnect(self) -> None:
        """Halt Modbus polling."""
        self._is_connected = False
        if self._poll_task:
            self._poll_task.cancel()
        logger.info("Modbus TCP source disconnected")

    async def stream(self) -> AsyncGenerator[RawTelemetryPayload, None]:
        """Stream polled Modbus packets."""
        while self._is_connected:
            try:
                payload = await asyncio.wait_for(self._queue.get(), timeout=2.0)
                yield payload
                self._queue.task_done()
            except asyncio.TimeoutError:
                continue
