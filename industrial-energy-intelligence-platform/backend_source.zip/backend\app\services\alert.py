"""
IEIP Services — Alert Lifecycle Service
"""

from __future__ import annotations

import uuid
from sqlalchemy.ext.asyncio import AsyncSession

from app.alerts.deduplicator import AlertDeduplicator
from app.alerts.state_machine import AlertStateMachine
from app.core.exceptions import NotFoundError
from app.models.alert import Alert
from app.repositories.alert import AlertRepository


class AlertService:
    """Orchestrates operator actions on alerts."""

    def __init__(self, session: AsyncSession) -> None:
        self.session = session
        self.alert_repo = AlertRepository(session)
        self.deduplicator = AlertDeduplicator()

    async def acknowledge_alert(
        self,
        alert_id: uuid.UUID,
        user_id: uuid.UUID | None = None,
        comment: str | None = None,
    ) -> Alert:
        alert = await self.alert_repo.get_by_id(alert_id)
        if not alert:
            raise NotFoundError(f"Alert with id {alert_id} not found")

        AlertStateMachine.acknowledge(alert, user_id=user_id)
        if comment:
            alert.resolution_comment = f"ACK: {comment}"
        await self.session.commit()
        return alert

    async def resolve_alert(
        self,
        alert_id: uuid.UUID,
        user_id: uuid.UUID | None = None,
        resolution_comment: str = "Resolved by technician",
    ) -> Alert:
        alert = await self.alert_repo.get_by_id(alert_id)
        if not alert:
            raise NotFoundError(f"Alert with id {alert_id} not found")

        AlertStateMachine.resolve(alert, resolution_comment=resolution_comment, user_id=user_id)
        # Clear deduplication key to allow future alerts if condition recurs
        self.deduplicator.clear_key(alert.dedup_key)
        await self.session.commit()
        return alert
