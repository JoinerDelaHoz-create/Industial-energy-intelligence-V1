"""
IEIP API v1 — Equipment Endpoints
"""

from __future__ import annotations

import uuid
from datetime import datetime, timedelta, timezone

from fastapi import APIRouter, Depends, Query, status
from sqlalchemy.ext.asyncio import AsyncSession

from app.core.exceptions import NotFoundError
from app.dependencies import get_current_user, get_db, get_optional_user
from app.models.equipment import Equipment, OperatingStatus
from app.models.user import User
from app.repositories.equipment import EquipmentRepository
from app.repositories.telemetry import TelemetryRepository
from app.schemas.common import APIResponse
from app.schemas.equipment import (
    EquipmentCreate,
    EquipmentResponse,
    EquipmentSummary,
    EquipmentUpdate,
)
from app.schemas.kpi import EquipmentKPIs
from app.schemas.telemetry import RealTimeSnapshot, TelemetryResponse
from app.services.equipment import EquipmentService
from app.services.kpi import KPIService

router = APIRouter(prefix="/equipment", tags=["Equipment Fleet"])


@router.get("", response_model=APIResponse[list[EquipmentSummary]])
async def list_fleet(
    site_id: str | None = None,
    db: AsyncSession = Depends(get_db),
    _user: User | None = Depends(get_optional_user),
):
    """Retrieve equipment fleet cards with live operating metrics."""
    service = EquipmentService(db)
    summaries = await service.get_fleet_summaries(site_id=site_id)
    return APIResponse(data=summaries)


@router.post("", response_model=APIResponse[EquipmentResponse], status_code=status.HTTP_201_CREATED)
async def create_equipment(
    payload: EquipmentCreate,
    db: AsyncSession = Depends(get_db),
    _user: User = Depends(get_current_user),
):
    """Register a new industrial equipment in the asset catalog."""
    repo = EquipmentRepository(db)
    existing = await repo.get_by_asset_code(payload.asset_code)
    if existing:
        raise ValueError(f"Equipment with asset_code '{payload.asset_code}' already exists")

    equip = Equipment(**payload.model_dump())
    await repo.create(equip)
    await db.commit()
    # Reload with relations
    saved = await repo.get_by_asset_code(payload.asset_code)
    return APIResponse(message="Equipment created successfully", data=EquipmentResponse.model_validate(saved))


@router.get("/{equipment_id}", response_model=APIResponse[EquipmentResponse])
async def get_equipment(
    equipment_id: uuid.UUID,
    db: AsyncSession = Depends(get_db),
    _user: User | None = Depends(get_optional_user),
):
    """Retrieve full nameplate specifications and channels for an equipment."""
    repo = EquipmentRepository(db)
    equip = await repo.get_by_id(equipment_id)
    if not equip:
        raise NotFoundError("Equipment not found")
    return APIResponse(data=EquipmentResponse.model_validate(equip))


@router.get("/{equipment_id}/realtime", response_model=APIResponse[RealTimeSnapshot | None])
async def get_realtime_snapshot(
    equipment_id: uuid.UUID,
    db: AsyncSession = Depends(get_db),
    _user: User | None = Depends(get_optional_user),
):
    """Get the latest instrument readings for live gauge dials."""
    equip_repo = EquipmentRepository(db)
    equip = await equip_repo.get_by_id(equipment_id)
    if not equip:
        raise NotFoundError("Equipment not found")

    telem_repo = TelemetryRepository(db)
    reading = await telem_repo.get_latest_by_equipment(equipment_id)
    if not reading:
        return APIResponse(data=None)

    snapshot = RealTimeSnapshot(
        equipment_id=equip.id,
        asset_code=equip.asset_code,
        timestamp=reading.time,
        active_power_kw=reading.active_power_kw or 0.0,
        reactive_power_kvar=reading.reactive_power_kvar or 0.0,
        power_factor=reading.power_factor or 0.0,
        current_l1=reading.current_l1 or 0.0,
        current_l2=reading.current_l2 or 0.0,
        current_l3=reading.current_l3 or 0.0,
        voltage_l1=reading.voltage_l1 or 0.0,
        voltage_l2=reading.voltage_l2 or 0.0,
        voltage_l3=reading.voltage_l3 or 0.0,
        frequency_hz=reading.frequency_hz or 60.0,
        current_unbalance_pct=reading.current_unbalance_pct or 0.0,
        temperature_c=reading.temperature_c or 0.0,
        vibration_rms_mms=reading.vibration_rms_mms or 0.0,
        operating_state=reading.operating_state or "RUNNING",
        load_pct=reading.load_pct or 0.0,
        is_simulated=reading.is_simulated,
    )
    return APIResponse(data=snapshot)


@router.get("/{equipment_id}/kpis", response_model=APIResponse[EquipmentKPIs])
async def get_equipment_kpis(
    equipment_id: uuid.UUID,
    period_hours: int = Query(24, ge=1, le=720),
    db: AsyncSession = Depends(get_db),
    _user: User | None = Depends(get_optional_user),
):
    """Get calculated electrical quality and operational KPIs for equipment."""
    kpi_service = KPIService(db)
    kpis = await kpi_service.get_equipment_kpis(equipment_id, period_hours=period_hours)
    if not kpis:
        raise NotFoundError("Equipment not found")
    return APIResponse(data=kpis)


@router.get("/{equipment_id}/telemetry", response_model=APIResponse[list[TelemetryResponse]])
async def get_equipment_telemetry(
    equipment_id: uuid.UUID,
    hours: int = Query(2, ge=1, le=168),
    limit: int = Query(300, ge=10, le=2000),
    db: AsyncSession = Depends(get_db),
    _user: User | None = Depends(get_optional_user),
):
    """Fetch raw time series data for trend charts."""
    telem_repo = TelemetryRepository(db)
    now = datetime.now(timezone.utc)
    start = now - timedelta(hours=hours)
    readings = await telem_repo.get_time_series(equipment_id, start_time=start, end_time=now, limit=limit)
    return APIResponse(data=[TelemetryResponse.model_validate(r) for r in readings])
