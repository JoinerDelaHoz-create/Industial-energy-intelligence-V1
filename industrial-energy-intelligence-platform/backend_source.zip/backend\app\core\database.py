"""
IEIP Backend — Database Engine & Session Factory

Uses SQLAlchemy 2.0 async API with asyncpg driver.
TimescaleDB hypertable setup is handled in init.sql (infrastructure/database/).
"""

from __future__ import annotations

from collections.abc import AsyncGenerator
from typing import Any

from sqlalchemy import event, text
from sqlalchemy.ext.asyncio import (
    AsyncConnection,
    AsyncEngine,
    AsyncSession,
    async_sessionmaker,
    create_async_engine,
)
from sqlalchemy.orm import DeclarativeBase, MappedColumn

from app.config import settings
from app.core.logging import get_logger

logger = get_logger(__name__)


class Base(DeclarativeBase):
    """Base class for all SQLAlchemy ORM models."""

    pass


# ── Engine ─────────────────────────────────────────────────────────────────────

def _create_engine() -> AsyncEngine:
    """Create the async SQLAlchemy engine with production-safe settings."""
    engine = create_async_engine(
        settings.database_url,
        echo=settings.is_development,  # Log SQL only in development
        pool_size=10,
        max_overflow=20,
        pool_pre_ping=True,     # Detect stale connections
        pool_recycle=3600,      # Recycle connections after 1 hour
    )
    logger.info("Database engine created", url=settings.db_host, db=settings.db_name)
    return engine


engine = _create_engine()

# ── Session Factory ─────────────────────────────────────────────────────────────

AsyncSessionLocal = async_sessionmaker(
    bind=engine,
    class_=AsyncSession,
    expire_on_commit=False,     # Required for async — prevents lazy load after commit
    autocommit=False,
    autoflush=False,
)


# ── Dependency ─────────────────────────────────────────────────────────────────

async def get_db() -> AsyncGenerator[AsyncSession, None]:
    """FastAPI dependency that yields an async database session.

    Session lifecycle:
    - Created at request start
    - Yielded to the route handler
    - Committed if no exception, rolled back otherwise
    - Closed after the response is sent
    """
    async with AsyncSessionLocal() as session:
        try:
            yield session
            await session.commit()
        except Exception:
            await session.rollback()
            raise
        finally:
            await session.close()


# ── Startup / Shutdown ─────────────────────────────────────────────────────────

async def create_tables() -> None:
    """Create all tables defined in ORM models.

    Note: TimescaleDB hypertables are created via init.sql, not here.
    This is used as a fallback for testing environments without Docker.
    """
    async with engine.begin() as conn:
        await conn.run_sync(Base.metadata.create_all)
        logger.info("Database tables created/verified")


async def verify_connection() -> bool:
    """Verify the database connection is healthy.

    Returns True if connected, False otherwise.
    """
    try:
        async with engine.connect() as conn:
            await conn.execute(text("SELECT 1"))
        logger.info("Database connection verified successfully")
        return True
    except Exception as exc:
        logger.error("Database connection failed", error=str(exc))
        return False


async def dispose_engine() -> None:
    """Dispose the engine and close all connections.

    Called during application shutdown to cleanly release resources.
    """
    await engine.dispose()
    logger.info("Database engine disposed")
