"""
IEIP Services — Industrial Reporting & CSV Export Service

Generates audit-ready CSV exports of historical telemetry, anomalies, and energy balances.
"""

from __future__ import annotations

import csv
import io
import uuid
from datetime import datetime, timezone
from typing import Sequence

from sqlalchemy.ext.asyncio import AsyncSession

from app.models.anomaly import Anomaly
from app.models.telemetry import TelemetryReading
from app.repositories.anomaly import AnomalyRepository
from app.repositories.equipment import EquipmentRepository
from app.repositories.telemetry import TelemetryRepository


class ReportService:
    """Exports structured industrial telemetry and event logs to CSV."""

    def __init__(self, session: AsyncSession) -> None:
        self.session = session
        self.telemetry_repo = TelemetryRepository(session)
        self.anomaly_repo = AnomalyRepository(session)
        self.equip_repo = EquipmentRepository(session)

    async def generate_telemetry_csv(
        self,
        equipment_id: uuid.UUID,
        start_time: datetime,
        end_time: datetime,
    ) -> str:
        """Export raw telemetry readings in RFC 4180 CSV format."""
        readings = await self.telemetry_repo.get_time_series(
            equipment_id=equipment_id,
            start_time=start_time,
            end_time=end_time,
            limit=5000,
        )

        output = io.StringIO()
        writer = csv.writer(output)

        # Header row
        writer.writerow([
            "Timestamp_UTC",
            "Active_Power_kW",
            "Reactive_Power_kVAR",
            "Apparent_Power_kVA",
            "Power_Factor",
            "Voltage_L1_V",
            "Voltage_L2_V",
            "Voltage_L3_V",
            "Voltage_Avg_V",
            "Current_L1_A",
            "Current_L2_A",
            "Current_L3_A",
            "Current_Avg_A",
            "Frequency_Hz",
            "Current_Unbalance_Pct",
            "Voltage_Unbalance_Pct",
            "THD_Current_Pct",
            "Temperature_C",
            "Vibration_RMS_mms",
            "Operating_State",
            "Cumulative_Energy_kWh",
            "Is_Simulated",
        ])

        for r in readings:
            writer.writerow([
                r.time.isoformat() if r.time else "",
                r.active_power_kw or 0.0,
                r.reactive_power_kvar or 0.0,
                r.apparent_power_kva or 0.0,
                r.power_factor or 0.0,
                r.voltage_l1 or 0.0,
                r.voltage_l2 or 0.0,
                r.voltage_l3 or 0.0,
                r.voltage_avg or 0.0,
                r.current_l1 or 0.0,
                r.current_l2 or 0.0,
                r.current_l3 or 0.0,
                r.current_avg or 0.0,
                r.frequency_hz or 60.0,
                r.current_unbalance_pct or 0.0,
                r.voltage_unbalance_pct or 0.0,
                r.thd_current_pct or 0.0,
                r.temperature_c or 0.0,
                r.vibration_rms_mms or 0.0,
                r.operating_state or "",
                r.energy_kwh or 0.0,
                "YES" if r.is_simulated else "NO",
            ])

        return output.getvalue()

    async def generate_anomalies_csv(
        self,
        equipment_id: uuid.UUID | None = None,
        start_time: datetime | None = None,
        end_time: datetime | None = None,
    ) -> str:
        """Export detected anomalies with algorithmic evidence and metrics."""
        anomalies, _ = await self.anomaly_repo.list_filtered(
            equipment_id=equipment_id,
            start_time=start_time,
            end_time=end_time,
            limit=2000,
        )

        output = io.StringIO()
        writer = csv.writer(output)

        writer.writerow([
            "Anomaly_ID",
            "Equipment_ID",
            "Detected_At_UTC",
            "Anomaly_Type",
            "Severity",
            "Algorithm_Used",
            "Metric_Name",
            "Observed_Value",
            "Expected_Value",
            "Threshold_Value",
            "Deviation_Pct",
            "Confidence_Score",
            "Status",
            "Description",
        ])

        for a in anomalies:
            writer.writerow([
                str(a.id),
                str(a.equipment_id),
                a.detected_at.isoformat() if a.detected_at else "",
                a.anomaly_type.value,
                a.severity.value,
                a.algorithm_used,
                a.metric_name,
                a.observed_value,
                a.expected_value or "",
                a.threshold_value or "",
                a.deviation_pct or "",
                a.confidence_score,
                a.status.value,
                a.description,
            ])

        return output.getvalue()
