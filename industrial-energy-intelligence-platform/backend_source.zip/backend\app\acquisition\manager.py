"""
IEIP Acquisition — Multi-Protocol Acquisition Manager

Coordinates concurrent telemetry sources (Simulator, MQTT, Modbus), multiplexes their
payload streams, and routes them to the central analytics and ingestion pipeline.
"""

from __future__ import annotations

import asyncio
from typing import Callable, Coroutine

from app.acquisition.base import BaseDataSource, RawTelemetryPayload
from app.acquisition.mqtt_source import MQTTDataSource
from app.acquisition.simulator import SimulatorDataSource
from app.core.logging import get_logger

logger = get_logger("ieip.acquisition.manager")


class AcquisitionManager:
    """Central orchestrator for industrial field communication channels."""

    _instance: AcquisitionManager | None = None

    def __init__(self) -> None:
        self.sources: dict[str, BaseDataSource] = {}
        self.is_running: bool = False
        self._source_tasks: list[asyncio.Task] = []
        self._listeners: list[Callable[[RawTelemetryPayload], Coroutine]] = []

    @classmethod
    def get_instance(cls) -> AcquisitionManager:
        if cls._instance is None:
            cls._instance = cls()
        return cls._instance

    def register_source(self, name: str, source: BaseDataSource) -> None:
        """Register a new data acquisition interface."""
        self.sources[name] = source
        logger.info(f"Registered acquisition source: {name}")

    def add_listener(self, listener: Callable[[RawTelemetryPayload], Coroutine]) -> None:
        """Register an async consumer (e.g. IngestionPipeline)."""
        if listener not in self._listeners:
            self._listeners.append(listener)

    async def start(self) -> None:
        """Connect all registered sources and start streaming loops."""
        if self.is_running:
            return
        self.is_running = True

        # Default standard sources if not manually populated
        if not self.sources:
            self.register_source("simulator", SimulatorDataSource())
            self.register_source("mqtt", MQTTDataSource())

        for name, source in self.sources.items():
            try:
                await source.connect()
                task = asyncio.create_task(self._consume_source(name, source))
                self._source_tasks.append(task)
                logger.info(f"Started streaming from acquisition source '{name}'")
            except Exception as err:
                logger.error(f"Failed to start acquisition source '{name}': {err}")

    async def stop(self) -> None:
        """Gracefully disconnect all sources."""
        self.is_running = False
        for task in self._source_tasks:
            task.cancel()
        for name, source in self.sources.items():
            try:
                await source.disconnect()
            except Exception as err:
                logger.error(f"Error disconnecting source '{name}': {err}")
        self._source_tasks.clear()
        logger.info("AcquisitionManager stopped")

    async def _consume_source(self, source_name: str, source: BaseDataSource) -> None:
        """Reads stream from a single source and fans out to listeners."""
        while self.is_running:
            try:
                async for payload in source.stream():
                    for listener in self._listeners:
                        try:
                            await listener(payload)
                        except Exception as l_err:
                            logger.error(f"Listener error in {source_name} pipeline: {l_err}")
            except asyncio.CancelledError:
                break
            except Exception as err:
                logger.error(f"Error consuming stream from {source_name}: {err}")
                await asyncio.sleep(2.0)
