"""
IEIP API v1 — Authentication Endpoints
"""

from __future__ import annotations

from datetime import timedelta

from fastapi import APIRouter, Depends, status
from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession

from app.config import get_settings
from app.core.exceptions import AuthenticationError
from app.core.security import create_access_token, verify_password
from app.dependencies import get_current_user, get_db
from app.models.user import User
from app.schemas.common import APIResponse
from app.schemas.user import LoginRequest, Token, UserResponse

router = APIRouter(prefix="/auth", tags=["Authentication"])
settings = get_settings()


@router.post("/login", response_model=APIResponse[Token])
async def login(credentials: LoginRequest, db: AsyncSession = Depends(get_db)):
    """Authenticate with username/email and password to receive Bearer JWT."""
    stmt = select(User).where(User.email == credentials.username)
    res = await db.execute(stmt)
    user = res.scalar_one_or_none()

    if not user or not verify_password(credentials.password, user.hashed_password):
        raise AuthenticationError("Invalid email or password")

    if not user.is_active:
        raise AuthenticationError("Account is inactive")

    expires_delta = timedelta(minutes=settings.JWT_ACCESS_TOKEN_EXPIRE_MINUTES)
    token_str = create_access_token(
        subject=str(user.id),
        role=user.role.value,
        expires_delta=expires_delta,
    )

    return APIResponse(
        message="Login successful",
        data=Token(
            access_token=token_str,
            token_type="bearer",
            expires_in=settings.JWT_ACCESS_TOKEN_EXPIRE_MINUTES * 60,
            user=UserResponse.model_validate(user),
        ),
    )


@router.get("/me", response_model=APIResponse[UserResponse])
async def get_current_user_profile(current_user: User = Depends(get_current_user)):
    """Get authenticated user profile."""
    return APIResponse(
        message="User profile retrieved",
        data=UserResponse.model_validate(current_user),
    )
