"""
IEIP Alerts — Operational State Machine

Enforces deterministic transitions for the Alert lifecycle:
   [OPEN] ──acknowledge()──> [ACKNOWLEDGED] ──resolve()──> [RESOLVED]
     │                                                           ▲
     └─────────────────────────resolve()─────────────────────────┘
"""

from __future__ import annotations

import uuid
from datetime import datetime, timezone

from app.core.exceptions import ValidationError
from app.models.alert import Alert, AlertStatus


class AlertStateMachine:
    """Validates and applies state transitions to Alert records."""

    VALID_TRANSITIONS: dict[AlertStatus, set[AlertStatus]] = {
        AlertStatus.OPEN: {AlertStatus.ACKNOWLEDGED, AlertStatus.RESOLVED, AlertStatus.SUPPRESSED},
        AlertStatus.ACKNOWLEDGED: {AlertStatus.RESOLVED, AlertStatus.OPEN},
        AlertStatus.RESOLVED: set(),  # Terminal state
        AlertStatus.SUPPRESSED: {AlertStatus.OPEN, AlertStatus.RESOLVED},
    }

    @classmethod
    def can_transition(cls, current_status: AlertStatus, target_status: AlertStatus) -> bool:
        return target_status in cls.VALID_TRANSITIONS.get(current_status, set())

    @classmethod
    def acknowledge(cls, alert: Alert, user_id: uuid.UUID | None = None) -> None:
        """Move alert to ACKNOWLEDGED state."""
        if not cls.can_transition(alert.status, AlertStatus.ACKNOWLEDGED):
            raise ValidationError(
                f"Cannot acknowledge alert in state '{alert.status.value}'"
            )

        alert.status = AlertStatus.ACKNOWLEDGED
        alert.acknowledged_at = datetime.now(timezone.utc)
        alert.acknowledged_by_id = user_id

    @classmethod
    def resolve(
        cls,
        alert: Alert,
        resolution_comment: str,
        user_id: uuid.UUID | None = None,
    ) -> None:
        """Move alert to RESOLVED state."""
        if not cls.can_transition(alert.status, AlertStatus.RESOLVED):
            raise ValidationError(
                f"Cannot resolve alert in state '{alert.status.value}'"
            )

        alert.status = AlertStatus.RESOLVED
        alert.resolved_at = datetime.now(timezone.utc)
        alert.resolved_by_id = user_id
        alert.resolution_comment = resolution_comment
