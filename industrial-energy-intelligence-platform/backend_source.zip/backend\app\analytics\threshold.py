"""
IEIP Analytics — Threshold-Based Rule Detector

Evaluates deterministic engineering boundaries:
- Overcurrent (current > 110% FLA)
- Undervoltage (voltage < 90% nominal)
- Overvoltage (voltage > 110% nominal)
- High Stator / Bearing Temperature (temp > 85°C / 100°C)
- ISO 10816-3 Vibration Exceedance (> 4.5 mm/s RMS)
- Harmonic Distortion limits (IEEE 519: THD-V > 5%, THD-I > 10%)
"""

from __future__ import annotations

from dataclasses import dataclass
from datetime import datetime
from typing import Any

from app.models.anomaly import AnomalySeverity, AnomalyType


@dataclass
class AnomalyCandidate:
    """Internal candidate emitted by detection algorithms."""

    anomaly_type: AnomalyType
    severity: AnomalySeverity
    algorithm: str
    metric_name: str
    observed_value: float
    expected_value: float | None
    threshold_value: float | None
    deviation_pct: float | None
    confidence_score: float
    description: str
    context: dict[str, Any]


class ThresholdRuleDetector:
    """Deterministic engineering rule checks against nameplate and standard limits."""

    def evaluate(self, telemetry: dict[str, Any], equipment_specs: dict[str, Any]) -> list[AnomalyCandidate]:
        candidates: list[AnomalyCandidate] = []

        # 1. Overcurrent check (relative to rated_current FLA)
        rated_current = equipment_specs.get("rated_current") or 115.0
        current_avg = telemetry.get("current_avg") or 0.0

        if current_avg > (rated_current * 1.10):
            dev = ((current_avg - rated_current) / rated_current) * 100.0
            sev = AnomalySeverity.CRITICAL if current_avg > (rated_current * 1.30) else AnomalySeverity.HIGH
            candidates.append(
                AnomalyCandidate(
                    anomaly_type=AnomalyType.OVERCURRENT,
                    severity=sev,
                    algorithm="THRESHOLD_FLA_LIMIT",
                    metric_name="current_avg",
                    observed_value=round(current_avg, 2),
                    expected_value=round(rated_current, 2),
                    threshold_value=round(rated_current * 1.10, 2),
                    deviation_pct=round(dev, 1),
                    confidence_score=0.98,
                    description=f"Corriente promedio ({current_avg:.1f}A) supera el 110% de corriente nominal de placa ({rated_current:.1f}A).",
                    context={"current_l1": telemetry.get("current_l1"), "current_l2": telemetry.get("current_l2"), "current_l3": telemetry.get("current_l3")},
                )
            )

        # 2. Undervoltage check (relative to rated_voltage)
        rated_voltage = equipment_specs.get("rated_voltage") or 460.0
        voltage_avg = telemetry.get("voltage_avg") or 0.0

        if 0 < voltage_avg < (rated_voltage * 0.90):
            dev = ((rated_voltage - voltage_avg) / rated_voltage) * 100.0
            candidates.append(
                AnomalyCandidate(
                    anomaly_type=AnomalyType.UNDERVOLTAGE,
                    severity=AnomalySeverity.HIGH,
                    algorithm="THRESHOLD_VOLTAGE_SAG",
                    metric_name="voltage_avg",
                    observed_value=round(voltage_avg, 1),
                    expected_value=round(rated_voltage, 1),
                    threshold_value=round(rated_voltage * 0.90, 1),
                    deviation_pct=round(-dev, 1),
                    confidence_score=0.95,
                    description=f"Tensión media de línea ({voltage_avg:.1f}V) inferior al 90% nominal ({rated_voltage * 0.90:.1f}V).",
                    context={"voltage_l1": telemetry.get("voltage_l1"), "voltage_l2": telemetry.get("voltage_l2"), "voltage_l3": telemetry.get("voltage_l3")},
                )
            )

        # 3. Overvoltage check
        if voltage_avg > (rated_voltage * 1.10):
            dev = ((voltage_avg - rated_voltage) / rated_voltage) * 100.0
            candidates.append(
                AnomalyCandidate(
                    anomaly_type=AnomalyType.OVERVOLTAGE,
                    severity=AnomalySeverity.MEDIUM,
                    algorithm="THRESHOLD_VOLTAGE_SWELL",
                    metric_name="voltage_avg",
                    observed_value=round(voltage_avg, 1),
                    expected_value=round(rated_voltage, 1),
                    threshold_value=round(rated_voltage * 1.10, 1),
                    deviation_pct=round(dev, 1),
                    confidence_score=0.95,
                    description=f"Sobretensión en bornes ({voltage_avg:.1f}V) superior al límite de seguridad (+10%).",
                    context={"voltage_l1": telemetry.get("voltage_l1"), "voltage_l2": telemetry.get("voltage_l2")},
                )
            )

        # 4. Thermal overload check (Class B insulation standard max ~95°C continuous)
        temp_c = telemetry.get("temperature_c")
        if temp_c is not None:
            if temp_c >= 105.0:
                candidates.append(
                    AnomalyCandidate(
                        anomaly_type=AnomalyType.THERMAL_OVERLOAD,
                        severity=AnomalySeverity.CRITICAL,
                        algorithm="THRESHOLD_THERMAL_CLASS_B",
                        metric_name="temperature_c",
                        observed_value=round(temp_c, 1),
                        expected_value=75.0,
                        threshold_value=105.0,
                        deviation_pct=round(((temp_c - 75.0) / 75.0) * 100.0, 1),
                        confidence_score=0.99,
                        description=f"Temperatura de carcasa/devanados ({temp_c:.1f}°C) en zona crítica (>105°C). Riesgo de degradación de aislamiento.",
                        context={"ambient_temp_c": 28.0},
                    )
                )
            elif temp_c >= 90.0:
                candidates.append(
                    AnomalyCandidate(
                        anomaly_type=AnomalyType.THERMAL_OVERLOAD,
                        severity=AnomalySeverity.HIGH,
                        algorithm="THRESHOLD_THERMAL_WARNING",
                        metric_name="temperature_c",
                        observed_value=round(temp_c, 1),
                        expected_value=75.0,
                        threshold_value=90.0,
                        deviation_pct=round(((temp_c - 75.0) / 75.0) * 100.0, 1),
                        confidence_score=0.95,
                        description=f"Temperatura de equipo ({temp_c:.1f}°C) en alerta preventiva (>90°C).",
                        context={"ambient_temp_c": 28.0},
                    )
                )

        # 5. Mechanical vibration check (ISO 10816-3 Zone C/D for medium industrial machines)
        vib_rms = telemetry.get("vibration_rms_mms")
        if vib_rms is not None:
            if vib_rms >= 4.5:
                candidates.append(
                    AnomalyCandidate(
                        anomaly_type=AnomalyType.EXCESSIVE_VIBRATION,
                        severity=AnomalySeverity.CRITICAL if vib_rms >= 7.1 else AnomalySeverity.HIGH,
                        algorithm="ISO_10816_3_SEVERITY",
                        metric_name="vibration_rms_mms",
                        observed_value=round(vib_rms, 2),
                        expected_value=1.4,
                        threshold_value=4.5,
                        deviation_pct=round(((vib_rms - 1.4) / 1.4) * 100.0, 1),
                        confidence_score=0.97,
                        description=f"Vibración RMS ({vib_rms:.2f} mm/s) en zona de alarma/peligro según norma ISO 10816-3.",
                        context={"baseline_vibration": 1.4},
                    )
                )

        # 6. Harmonic distortion check (IEEE 519)
        thd_i = telemetry.get("thd_current_pct")
        if thd_i is not None and thd_i >= 12.0:
            candidates.append(
                AnomalyCandidate(
                    anomaly_type=AnomalyType.HARMONIC_DISTORTION,
                    severity=AnomalySeverity.MEDIUM,
                    algorithm="IEEE_519_THD_LIMIT",
                    metric_name="thd_current_pct",
                    observed_value=round(thd_i, 1),
                    expected_value=3.5,
                    threshold_value=12.0,
                    deviation_pct=round(((thd_i - 3.5) / 3.5) * 100.0, 1),
                    confidence_score=0.92,
                    description=f"Distorsión armónica total de corriente ({thd_i:.1f}%) supera límites recomendados por IEEE 519.",
                    context={"thd_voltage_pct": telemetry.get("thd_voltage_pct")},
                )
            )

        return candidates
