"""
IEIP Analytics — Unified Multi-Detector Analytics Pipeline

Runs deterministic, statistical, imbalance, baseline, and power factor algorithms
in parallel against every incoming telemetry reading frame.
"""

from __future__ import annotations

from typing import Any
from app.analytics.baseline import BaselineEnergyDetector
from app.analytics.imbalance import PhaseImbalanceDetector
from app.analytics.power_factor import PowerFactorDetector
from app.analytics.statistical import RollingZScoreDetector
from app.analytics.threshold import AnomalyCandidate, ThresholdRuleDetector


class AnalyticsPipeline:
    """Unified engine coordinating all intelligence modules."""

    def __init__(self) -> None:
        self.threshold_detector = ThresholdRuleDetector()
        self.imbalance_detector = PhaseImbalanceDetector()
        self.pf_detector = PowerFactorDetector()
        self.zscore_detector = RollingZScoreDetector(window_size=60, z_threshold=3.2)
        self.baseline_detector = BaselineEnergyDetector()

    def process_frame(
        self,
        telemetry: dict[str, Any],
        equipment_specs: dict[str, Any],
    ) -> list[AnomalyCandidate]:
        """Execute all analytical detectors against frame and collect anomaly candidates."""
        candidates: list[AnomalyCandidate] = []

        # 1. Deterministic engineering limits
        candidates.extend(self.threshold_detector.evaluate(telemetry, equipment_specs))

        # 2. Phase balance & NEMA checks
        candidates.extend(self.imbalance_detector.evaluate(telemetry, equipment_specs))

        # 3. Power factor & reactive power
        candidates.extend(self.pf_detector.evaluate(telemetry, equipment_specs))

        # 4. Statistical outlier Z-Score
        candidates.extend(self.zscore_detector.evaluate(telemetry, equipment_specs))

        # 5. Baseline & phantom consumption
        candidates.extend(self.baseline_detector.evaluate(telemetry, equipment_specs))

        return candidates
