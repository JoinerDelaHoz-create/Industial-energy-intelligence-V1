"""
IEIP Backend — Security Utilities

Handles:
- JWT token creation and verification
- Password hashing with bcrypt
- Current user extraction

SECURITY:
- Passwords are never stored in plaintext
- Tokens are signed with SECRET_KEY from environment
- Stack traces are never returned to clients
"""

from __future__ import annotations

from datetime import datetime, timedelta, timezone
from typing import Any

from jose import JWTError, jwt
from passlib.context import CryptContext

from app.config import settings
from app.core.logging import get_logger

logger = get_logger(__name__)

# ── Password Hashing ───────────────────────────────────────────────────────────

_pwd_context = CryptContext(schemes=["bcrypt"], deprecated="auto")


def hash_password(plain_password: str) -> str:
    """Return a bcrypt hash of the given password.

    Never store the plain_password. Only the returned hash is persisted.
    """
    return _pwd_context.hash(plain_password)


def verify_password(plain_password: str, hashed_password: str) -> bool:
    """Verify a plaintext password against a bcrypt hash.

    Returns True if they match, False otherwise.
    """
    return _pwd_context.verify(plain_password, hashed_password)


# ── JWT Tokens ─────────────────────────────────────────────────────────────────

def create_access_token(
    subject: str,
    role: str,
    extra_claims: dict[str, Any] | None = None,
) -> str:
    """Create a short-lived JWT access token.

    Args:
        subject: User identifier (username or UUID).
        role: User role (ADMIN, ENGINEER, OPERATOR, VIEWER).
        extra_claims: Optional additional claims to embed.

    Returns:
        Encoded JWT string.
    """
    now = datetime.now(timezone.utc)
    expire = now + timedelta(minutes=settings.access_token_expire_minutes)

    payload: dict[str, Any] = {
        "sub": subject,
        "role": role,
        "type": "access",
        "iat": now,
        "exp": expire,
    }
    if extra_claims:
        payload.update(extra_claims)

    return jwt.encode(payload, settings.secret_key, algorithm=settings.algorithm)


def create_refresh_token(subject: str) -> str:
    """Create a long-lived JWT refresh token.

    Refresh tokens contain minimal claims — only subject and expiry.
    They are used solely to obtain a new access token.

    Args:
        subject: User identifier.

    Returns:
        Encoded JWT string.
    """
    now = datetime.now(timezone.utc)
    expire = now + timedelta(days=settings.refresh_token_expire_days)

    payload: dict[str, Any] = {
        "sub": subject,
        "type": "refresh",
        "iat": now,
        "exp": expire,
    }
    return jwt.encode(payload, settings.secret_key, algorithm=settings.algorithm)


def decode_token(token: str) -> dict[str, Any]:
    """Decode and verify a JWT token.

    Args:
        token: The raw JWT string.

    Returns:
        Decoded payload dictionary.

    Raises:
        JWTError: If the token is invalid, expired, or tampered with.
    """
    try:
        payload = jwt.decode(
            token,
            settings.secret_key,
            algorithms=[settings.algorithm],
        )
        return payload  # type: ignore[return-value]
    except JWTError as exc:
        logger.warning("JWT decode failed", error=str(exc))
        raise


def extract_subject(token: str) -> str | None:
    """Extract the subject claim from a token without raising on error.

    Used for lightweight checks where a full decode is not required.
    Returns None if extraction fails.
    """
    try:
        payload = decode_token(token)
        return str(payload.get("sub"))
    except JWTError:
        return None
