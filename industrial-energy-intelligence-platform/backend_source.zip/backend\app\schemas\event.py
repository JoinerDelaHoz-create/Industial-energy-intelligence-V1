"""
IEIP Backend — Operational Event Schemas
"""

from __future__ import annotations

import uuid
from datetime import datetime
from typing import Any
from pydantic import BaseModel, ConfigDict, Field

from app.models.event import EventCategory


class OperationalEventBase(BaseModel):
    equipment_id: uuid.UUID | None = None
    event_time: datetime
    category: EventCategory
    event_name: str = Field(min_length=2, max_length=150)
    description: str
    source: str = "SYSTEM"
    payload: dict[str, Any] | None = None


class OperationalEventCreate(OperationalEventBase):
    user_id: uuid.UUID | None = None


class OperationalEventResponse(OperationalEventBase):
    model_config = ConfigDict(from_attributes=True)

    id: uuid.UUID
    user_id: uuid.UUID | None = None
    created_at: datetime


class EventFilter(BaseModel):
    equipment_id: uuid.UUID | None = None
    category: EventCategory | None = None
    source: str | None = None
    start_time: datetime | None = None
    end_time: datetime | None = None
