"""
IEIP Backend — Common Schemas & DTOs
"""

from __future__ import annotations

from datetime import datetime
from typing import Generic, TypeVar
from pydantic import BaseModel, ConfigDict, Field

T = TypeVar("T")


class APIResponse(BaseModel, Generic[T]):
    """Standardized API response wrapper."""

    success: bool = True
    message: str = "Operation successful"
    data: T
    timestamp: datetime = Field(default_factory=datetime.utcnow)


class PaginatedResponse(BaseModel, Generic[T]):
    """Standardized pagination response container."""

    items: list[T]
    total: int = Field(ge=0, description="Total count of matching records")
    page: int = Field(ge=1, default=1, description="Current page index (1-based)")
    page_size: int = Field(ge=1, le=500, default=50, description="Items per page")
    total_pages: int = Field(ge=0, description="Total calculated pages")


class TimeRangeFilter(BaseModel):
    """Query parameters for time-filtered telemetry and analytics queries."""

    model_config = ConfigDict(extra="forbid")

    start_time: datetime | None = Field(
        None, description="Start timestamp in UTC (inclusive)"
    )
    end_time: datetime | None = Field(
        None, description="End timestamp in UTC (inclusive)"
    )
