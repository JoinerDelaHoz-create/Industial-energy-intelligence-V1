"""
IEIP Backend — Anomaly Event ORM Model

Records anomalies identified by the analytics engine (statistical, baseline,
imbalance, threshold rules) along with quantitative evidence.
"""

from __future__ import annotations

import enum
import uuid
from datetime import datetime
from typing import Any

from sqlalchemy import (
    DateTime,
    Enum as SAEnum,
    Float,
    ForeignKey,
    Index,
    String,
    Text,
)
from sqlalchemy.dialects.postgresql import JSONB, UUID
from sqlalchemy.orm import Mapped, mapped_column

from app.core.database import Base
from app.models.mixins import TimestampMixin, UUIDMixin


class AnomalyType(str, enum.Enum):
    """Categorized industrial anomaly types."""

    OVERCURRENT = "OVERCURRENT"
    UNDERVOLTAGE = "UNDERVOLTAGE"
    OVERVOLTAGE = "OVERVOLTAGE"
    PHASE_IMBALANCE = "PHASE_IMBALANCE"
    LOW_POWER_FACTOR = "LOW_POWER_FACTOR"
    THERMAL_OVERLOAD = "THERMAL_OVERLOAD"
    EXCESSIVE_VIBRATION = "EXCESSIVE_VIBRATION"
    OFF_HOURS_CONSUMPTION = "OFF_HOURS_CONSUMPTION"
    UNEXPECTED_STOP = "UNEXPECTED_STOP"
    HARMONIC_DISTORTION = "HARMONIC_DISTORTION"
    SENSOR_DRIFT = "SENSOR_DRIFT"


class AnomalySeverity(str, enum.Enum):
    """Severity level of an anomaly."""

    INFO = "INFO"
    LOW = "LOW"
    MEDIUM = "MEDIUM"
    HIGH = "HIGH"
    CRITICAL = "CRITICAL"


class AnomalyStatus(str, enum.Enum):
    """Lifecycle status of a detected anomaly."""

    DETECTED = "DETECTED"
    CONFIRMED = "CONFIRMED"
    FALSE_POSITIVE = "FALSE_POSITIVE"
    RESOLVED = "RESOLVED"


class Anomaly(UUIDMixin, TimestampMixin, Base):
    """Detailed anomaly record with mathematical and contextual evidence."""

    __tablename__ = "anomalies"

    equipment_id: Mapped[uuid.UUID] = mapped_column(
        UUID(as_uuid=True),
        ForeignKey("equipment.id", ondelete="CASCADE"),
        nullable=False,
        index=True,
    )
    measurement_point_id: Mapped[uuid.UUID | None] = mapped_column(
        UUID(as_uuid=True),
        ForeignKey("measurement_points.id", ondelete="SET NULL"),
        nullable=True,
        index=True,
    )

    detected_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True),
        nullable=False,
        index=True,
        comment="Exact timestamp when the condition was flagged",
    )
    anomaly_type: Mapped[AnomalyType] = mapped_column(
        SAEnum(AnomalyType, name="anomaly_type_enum"),
        nullable=False,
        index=True,
    )
    severity: Mapped[AnomalySeverity] = mapped_column(
        SAEnum(AnomalySeverity, name="anomaly_severity_enum"),
        nullable=False,
        index=True,
    )
    status: Mapped[AnomalyStatus] = mapped_column(
        SAEnum(AnomalyStatus, name="anomaly_status_enum"),
        nullable=False,
        default=AnomalyStatus.DETECTED,
        index=True,
    )

    # ── Detection Evidence ──────────────────────────────────────────────────────
    algorithm_used: Mapped[str] = mapped_column(
        String(100),
        nullable=False,
        comment="Algorithm name: e.g. THRESHOLD, STATISTICAL_ZSCORE, NEMA_IMBALANCE",
    )
    metric_name: Mapped[str] = mapped_column(
        String(100),
        nullable=False,
        comment="Physical variable implicated, e.g. current_l1, power_factor, thd_current",
    )
    observed_value: Mapped[float] = mapped_column(
        Float,
        nullable=False,
        comment="Numerical value that triggered the anomaly",
    )
    expected_value: Mapped[float | None] = mapped_column(
        Float,
        nullable=True,
        comment="Nominal, baseline, or mean value for comparison",
    )
    threshold_value: Mapped[float | None] = mapped_column(
        Float,
        nullable=True,
        comment="Configured boundary limit",
    )
    deviation_pct: Mapped[float | None] = mapped_column(
        Float,
        nullable=True,
        comment="Percentage deviation relative to expected/threshold",
    )
    confidence_score: Mapped[float] = mapped_column(
        Float,
        nullable=False,
        default=1.0,
        comment="Algorithmic confidence (0.0 to 1.0)",
    )

    # ── Context & Resolution ────────────────────────────────────────────────────
    description: Mapped[str] = mapped_column(Text, nullable=False)
    context_snapshot: Mapped[dict[str, Any] | None] = mapped_column(
        JSONB,
        nullable=True,
        comment="Snapshot of surrounding telemetry variables for root cause analysis",
    )
    resolved_at: Mapped[datetime | None] = mapped_column(
        DateTime(timezone=True),
        nullable=True,
    )
    resolution_notes: Mapped[str | None] = mapped_column(Text, nullable=True)

    __table_args__ = (
        Index("idx_anomaly_equip_status", "equipment_id", "status"),
    )

    def __repr__(self) -> str:
        return f"<Anomaly {self.anomaly_type.value} [{self.severity.value}] equip={self.equipment_id}>"
