"""
IEIP API v1 — Central Router Aggregator
"""

from fastapi import APIRouter

from app.api.v1.alerts import router as alerts_router
from app.api.v1.anomalies import router as anomalies_router
from app.api.v1.auth import router as auth_router
from app.api.v1.equipment import router as equipment_router
from app.api.v1.events import router as events_router
from app.api.v1.kpis import router as kpis_router
from app.api.v1.maintenance import router as maintenance_router
from app.api.v1.reports import router as reports_router
from app.api.v1.simulation import router as simulation_router
from app.api.v1.telemetry import router as telemetry_router

api_router = APIRouter(prefix="/v1")

api_router.include_router(auth_router)
api_router.include_router(equipment_router)
api_router.include_router(telemetry_router)
api_router.include_router(anomalies_router)
api_router.include_router(alerts_router)
api_router.include_router(events_router)
api_router.include_router(kpis_router)
api_router.include_router(simulation_router)
api_router.include_router(reports_router)
api_router.include_router(maintenance_router)
