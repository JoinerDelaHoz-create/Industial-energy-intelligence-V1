"""
IEIP Backend — User ORM Model

Handles user accounts, authentication credentials, and role-based access control.
"""

from __future__ import annotations

import enum
from sqlalchemy import Boolean, Enum as SAEnum, String
from sqlalchemy.orm import Mapped, mapped_column

from app.core.database import Base
from app.models.mixins import TimestampMixin, UUIDMixin


class UserRole(str, enum.Enum):
    """User access control roles."""

    ADMIN = "ADMIN"
    OPERATOR = "OPERATOR"
    ENGINEER = "ENGINEER"
    VIEWER = "VIEWER"


class User(UUIDMixin, TimestampMixin, Base):
    """System user model for authentication and audit trails."""

    __tablename__ = "users"

    email: Mapped[str] = mapped_column(
        String(255), unique=True, nullable=False, index=True,
        comment="User email address (login credential)",
    )
    hashed_password: Mapped[str] = mapped_column(
        String(255), nullable=False,
        comment="Bcrypt-hashed password",
    )
    full_name: Mapped[str] = mapped_column(
        String(200), nullable=False,
        comment="Full legal / operational name",
    )
    role: Mapped[UserRole] = mapped_column(
        SAEnum(UserRole, name="user_role_enum"),
        nullable=False,
        default=UserRole.VIEWER,
        server_default=UserRole.VIEWER.value,
    )
    is_active: Mapped[bool] = mapped_column(
        Boolean, nullable=False, default=True, server_default="true",
    )
    is_superuser: Mapped[bool] = mapped_column(
        Boolean, nullable=False, default=False, server_default="false",
    )

    def __repr__(self) -> str:
        return f"<User {self.email} ({self.role.value})>"
