"""
IEIP Analytics — Baseline & Off-Hours Energy Waste Detector

Compares active load profiles against expected baseline consumption bands,
flagging unprogrammed idle running, off-hours energy leakage, and unexpected shutdowns.
"""

from __future__ import annotations

from datetime import datetime
from typing import Any
from app.analytics.threshold import AnomalyCandidate
from app.models.anomaly import AnomalySeverity, AnomalyType


class BaselineEnergyDetector:
    """Evaluates equipment load against nominal operating baselines."""

    def evaluate(self, telemetry: dict[str, Any], equipment_specs: dict[str, Any]) -> list[AnomalyCandidate]:
        candidates: list[AnomalyCandidate] = []

        active_power_kw = telemetry.get("active_power_kw") or 0.0
        operating_state = telemetry.get("operating_state", "RUNNING")
        rated_power_kw = equipment_specs.get("rated_power_kw") or 75.0
        timestamp = telemetry.get("timestamp") or datetime.utcnow()

        # 1. Off-Hours Phantom Consumption
        # Off-hours defined as weekends or night shift (e.g. 22:00 - 05:00) or explicit state flag
        is_weekend = timestamp.weekday() >= 5 if hasattr(timestamp, "weekday") else False
        is_night = (timestamp.hour >= 22 or timestamp.hour < 5) if hasattr(timestamp, "hour") else False
        is_off_hours_scenario = operating_state == "OFF_HOURS_RUN"

        if (is_weekend or is_night or is_off_hours_scenario) and active_power_kw > (rated_power_kw * 0.20):
            # Baseline expectation during off-hours is < 5% or 0 kW
            wasted_kwh_hr = active_power_kw
            estimated_cost_usd_hr = wasted_kwh_hr * 0.14  # Typical industrial rate $0.14/kWh

            candidates.append(
                AnomalyCandidate(
                    anomaly_type=AnomalyType.OFF_HOURS_CONSUMPTION,
                    severity=AnomalySeverity.MEDIUM,
                    algorithm="BASELINE_OFF_HOURS_LEAKAGE",
                    metric_name="active_power_kw",
                    observed_value=round(active_power_kw, 2),
                    expected_value=0.0,
                    threshold_value=round(rated_power_kw * 0.05, 2),
                    deviation_pct=100.0,
                    confidence_score=0.94,
                    description=(
                        f"Consumo energético no programado fuera de horario productivo ({active_power_kw:.1f} kW). "
                        f"Desperdicio estimado: {wasted_kwh_hr:.1f} kWh/h (${estimated_cost_usd_hr:.2f} USD/h)."
                    ),
                    context={
                        "is_weekend": is_weekend,
                        "is_night": is_night,
                        "estimated_waste_kwh_hr": round(wasted_kwh_hr, 2),
                        "estimated_cost_usd_hr": round(estimated_cost_usd_hr, 2),
                    },
                )
            )

        # 2. Unexpected shutdown detection
        if operating_state == "TRIPPED":
            candidates.append(
                AnomalyCandidate(
                    anomaly_type=AnomalyType.UNEXPECTED_STOP,
                    severity=AnomalySeverity.CRITICAL,
                    algorithm="BASELINE_OPERATIONAL_STATE_CHECK",
                    metric_name="operating_state",
                    observed_value=0.0,
                    expected_value=round(rated_power_kw * 0.80, 2),
                    threshold_value=0.0,
                    deviation_pct=100.0,
                    confidence_score=0.99,
                    description="Parada intempestiva del equipo registrada durante ciclo operativo activo.",
                    context={"operating_state": operating_state},
                )
            )

        return candidates
