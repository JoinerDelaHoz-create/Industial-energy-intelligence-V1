"""
IEIP Simulation — Async Simulation Engine Runner

Coordinates digital twin instances for plant equipment fleet, executes scheduled time-steps,
manages scenario durations and transitions, and dispatches frames to acquisition/pipeline.
"""

from __future__ import annotations

import asyncio
import time
import uuid
from datetime import datetime, timezone
from typing import Callable, Coroutine

from app.core.logging import get_logger
from app.simulation.motor_model import InductionMotorTwin, MotorSpecifications
from app.simulation.scenarios import SCENARIO_CATALOG, SimulationScenario

logger = get_logger("ieip.simulation")


class SimulationRunner:
    """Singleton simulation manager coordinating virtual plant fleet."""

    _instance: SimulationRunner | None = None

    def __init__(self) -> None:
        self.is_running: bool = False
        self._task: asyncio.Task | None = None
        self._subscribers: list[Callable[[dict], Coroutine]] = []

        # Fleet of digital twins indexed by equipment asset code
        self.fleet: dict[str, InductionMotorTwin] = {
            "MTR-305": InductionMotorTwin(MotorSpecifications(rated_power_kw=75.0, rated_current_a=115.0)),
            "PMP-101": InductionMotorTwin(MotorSpecifications(rated_power_kw=45.0, rated_current_a=72.0)),
            "CMP-201": InductionMotorTwin(MotorSpecifications(rated_power_kw=90.0, rated_current_a=140.0)),
            "FAN-102": InductionMotorTwin(MotorSpecifications(rated_power_kw=30.0, rated_current_a=48.0)),
            "CNV-401": InductionMotorTwin(MotorSpecifications(rated_power_kw=15.0, rated_current_a=26.0)),
            "GEN-101": InductionMotorTwin(MotorSpecifications(rated_power_kw=110.0, rated_current_a=165.0)),
        }

        # Active scenario state
        self.active_scenario_id: str = "NORMAL_OPERATION"
        self.target_asset_code: str = "MTR-305"
        self.scenario_start_time: float = 0.0
        self.scenario_duration_seconds: float = 0.0
        self.severity_multiplier: float = 1.0
        self.total_samples_generated: int = 0
        self.tick_rate_hz: float = 1.0

    @classmethod
    def get_instance(cls) -> SimulationRunner:
        if cls._instance is None:
            cls._instance = cls()
        return cls._instance

    def subscribe(self, callback: Callable[[dict], Coroutine]) -> None:
        """Register an async callback invoked on every generated telemetry sample."""
        if callback not in self._subscribers:
            self._subscribers.append(callback)

    def unsubscribe(self, callback: Callable[[dict], Coroutine]) -> None:
        if callback in self._subscribers:
            self._subscribers.remove(callback)

    def trigger_scenario(
        self,
        scenario_id: str,
        asset_code: str = "MTR-305",
        duration_seconds: float = 60.0,
        severity: float = 1.0,
    ) -> bool:
        """Trigger an operational fault scenario for a given duration."""
        if scenario_id not in SCENARIO_CATALOG:
            logger.warning(f"Unknown scenario ID: {scenario_id}")
            return False

        scenario = SCENARIO_CATALOG[scenario_id]
        target_twin = self.fleet.get(asset_code)
        if not target_twin:
            logger.warning(f"Target equipment code {asset_code} not found in fleet")
            return False

        # Apply scenario mutation
        scenario.apply_fn(target_twin, severity)

        self.active_scenario_id = scenario_id
        self.target_asset_code = asset_code
        self.scenario_start_time = time.monotonic()
        self.scenario_duration_seconds = duration_seconds
        self.severity_multiplier = severity

        logger.info(
            f"Scenario triggered: {scenario_id} on {asset_code} "
            f"(duration: {duration_seconds}s, severity: {severity})",
            scenario_id=scenario_id,
            asset_code=asset_code,
            duration=duration_seconds,
        )
        return True

    def reset_to_normal(self, asset_code: str | None = None) -> None:
        """Revert equipment fleet to normal baseline operation."""
        targets = [asset_code] if asset_code and asset_code in self.fleet else list(self.fleet.keys())
        normal_scenario = SCENARIO_CATALOG["NORMAL_OPERATION"]

        for code in targets:
            normal_scenario.apply_fn(self.fleet[code], 1.0)

        self.active_scenario_id = "NORMAL_OPERATION"
        self.scenario_duration_seconds = 0.0
        logger.info("Equipment reverted to NORMAL_OPERATION", targets=targets)

    def get_status(self) -> dict:
        """Retrieve current simulation engine health and scenario metrics."""
        elapsed = (time.monotonic() - self.scenario_start_time) if self.scenario_duration_seconds > 0 else 0.0
        remaining = max(0.0, self.scenario_duration_seconds - elapsed) if self.scenario_duration_seconds > 0 else 0.0

        return {
            "is_running": self.is_running,
            "active_scenario": self.active_scenario_id,
            "target_asset_code": self.target_asset_code,
            "elapsed_seconds": round(elapsed, 1),
            "remaining_seconds": round(remaining, 1),
            "tick_rate_hz": self.tick_rate_hz,
            "total_samples_generated": self.total_samples_generated,
            "scenarios_available": [
                {
                    "scenario_id": s.scenario_id,
                    "name": s.name,
                    "category": s.category,
                    "description": s.description,
                    "expected_anomaly": s.expected_anomaly,
                }
                for s in SCENARIO_CATALOG.values()
            ],
        }

    async def start(self) -> None:
        """Start the background generation loop."""
        if self.is_running:
            return
        self.is_running = True
        self._task = asyncio.create_task(self._simulation_loop())
        logger.info("Simulation runner loop started")

    async def stop(self) -> None:
        """Stop background generation."""
        self.is_running = False
        if self._task:
            self._task.cancel()
            try:
                await self._task
            except asyncio.CancelledError:
                pass
        logger.info("Simulation runner loop stopped")

    async def _simulation_loop(self) -> None:
        """Main periodic loop computing physics frames and dispatching to subscribers."""
        while self.is_running:
            start_tick = time.monotonic()

            # Check scenario timeout expiration
            if self.scenario_duration_seconds > 0:
                elapsed = time.monotonic() - self.scenario_start_time
                if elapsed >= self.scenario_duration_seconds:
                    logger.info(f"Scenario {self.active_scenario_id} expired. Reverting to normal.")
                    self.reset_to_normal(self.target_asset_code)

            now_utc = datetime.now(timezone.utc)

            # Step each equipment in the virtual plant fleet
            for asset_code, motor in self.fleet.items():
                data = motor.step(delta_time_sec=1.0 / self.tick_rate_hz)
                data["asset_code"] = asset_code
                data["timestamp"] = now_utc

                # Notify subscribers (ingestion pipeline, websockets, MQTT publisher)
                for subscriber in list(self._subscribers):
                    try:
                        await subscriber(data)
                    except Exception as err:
                        logger.error(f"Error in simulation subscriber callback: {err}")

                self.total_samples_generated += 1

            # Sleep to maintain tick rate
            compute_time = time.monotonic() - start_tick
            sleep_time = max(0.01, (1.0 / self.tick_rate_hz) - compute_time)
            await asyncio.sleep(sleep_time)
