"""
IEIP Backend — Simulation & Scenario Schemas
"""

from __future__ import annotations

import uuid
from pydantic import BaseModel, Field


class SimulationScenarioRequest(BaseModel):
    scenario_id: str = Field(..., description="Unique scenario identifier, e.g. OVERCURRENT, PHASE_IMBALANCE")
    equipment_id: uuid.UUID | None = Field(
        None, description="Target equipment. If None, applies to default demonstration motor"
    )
    duration_seconds: int = Field(default=60, ge=5, le=3600, description="Duration before returning to normal")
    severity_multiplier: float = Field(default=1.0, ge=0.5, le=3.0, description="Fault magnitude factor")


class SimulationStatusResponse(BaseModel):
    is_running: bool
    active_scenario: str | None = None
    target_equipment_id: uuid.UUID | None = None
    elapsed_seconds: float = 0.0
    remaining_seconds: float = 0.0
    tick_rate_hz: float = 1.0
    total_samples_generated: int = 0
    scenarios_available: list[dict[str, str]] = []
