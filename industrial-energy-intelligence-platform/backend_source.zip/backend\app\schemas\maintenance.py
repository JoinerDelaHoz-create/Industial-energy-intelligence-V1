"""
IEIP Backend — Maintenance Recommendation Schemas
"""

from __future__ import annotations

import uuid
from datetime import datetime
from pydantic import BaseModel, ConfigDict, Field

from app.models.maintenance import RecommendationPriority, RecommendationStatus


class MaintenanceRecommendationBase(BaseModel):
    equipment_id: uuid.UUID
    anomaly_id: uuid.UUID | None = None
    title: str = Field(min_length=3, max_length=200)
    technical_rationale: str
    suggested_actions: str
    priority: RecommendationPriority = RecommendationPriority.MEDIUM
    status: RecommendationStatus = RecommendationStatus.PENDING
    estimated_monthly_kwh_waste: float | None = None
    estimated_monthly_cost_usd: float | None = None


class MaintenanceRecommendationCreate(MaintenanceRecommendationBase):
    pass


class MaintenanceRecommendationUpdate(BaseModel):
    status: RecommendationStatus | None = None
    priority: RecommendationPriority | None = None


class MaintenanceRecommendationResponse(MaintenanceRecommendationBase):
    model_config = ConfigDict(from_attributes=True)

    id: uuid.UUID
    implemented_at: datetime | None = None
    implemented_by_id: uuid.UUID | None = None
    created_at: datetime
    updated_at: datetime
