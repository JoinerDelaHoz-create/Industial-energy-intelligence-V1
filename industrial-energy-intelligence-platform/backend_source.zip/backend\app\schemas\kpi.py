"""
IEIP Backend — KPI & Energy Analytics Schemas
"""

from __future__ import annotations

import uuid
from datetime import datetime
from pydantic import BaseModel, Field


class EnergyConsumptionItem(BaseModel):
    equipment_id: uuid.UUID
    asset_code: str
    name: str
    total_kwh: float
    percentage_of_total: float
    cost_usd: float


class PlantKPIs(BaseModel):
    timestamp: datetime = Field(default_factory=datetime.utcnow)
    active_power_total_kw: float
    daily_energy_consumption_kwh: float
    daily_energy_cost_usd: float
    average_power_factor: float
    total_equipment_count: int
    operational_count: int
    warning_count: int
    critical_count: int
    offline_count: int
    active_anomalies_count: int
    open_alerts_count: int
    top_consumers: list[EnergyConsumptionItem] = []


class EquipmentKPIs(BaseModel):
    equipment_id: uuid.UUID
    asset_code: str
    period_hours: int
    total_energy_kwh: float
    average_power_kw: float
    peak_power_kw: float
    average_power_factor: float
    average_current_unbalance_pct: float
    average_temperature_c: float
    max_vibration_mms: float
    running_hours: float
    availability_pct: float
    estimated_cost_usd: float
    anomalies_detected: int
