"""
IEIP Simulation — Three-Phase Induction Motor Digital Twin

Physics-based model replicating electrical, thermal, and mechanical characteristics
of industrial induction motors according to IEEE and NEMA standards.
"""

from __future__ import annotations

import math
import random
from dataclasses import dataclass, field
from app.simulation.noise import IndustrialNoiseGenerator


@dataclass
class MotorSpecifications:
    """Nameplate specifications for industrial motor."""

    rated_power_kw: float = 75.0      # 100 HP class
    rated_voltage_v: float = 460.0    # Line-to-line RMS (V)
    rated_current_a: float = 115.0    # Full Load Amps (FLA)
    nominal_power_factor: float = 0.88
    nominal_efficiency: float = 0.94   # IE3 Premium efficiency
    nominal_frequency_hz: float = 60.0
    poles: int = 4                    # 1800 RPM synchronous
    stator_resistance_ohms: float = 0.08
    thermal_time_constant_sec: float = 900.0  # 15 minutes to reach steady temp
    ambient_temperature_c: float = 28.0
    rated_temperature_rise_c: float = 65.0   # Class B rise (approx 93°C hot)


class InductionMotorTwin:
    """Dynamic simulation state for a three-phase induction motor asset."""

    def __init__(self, specs: MotorSpecifications | None = None) -> None:
        self.specs = specs or MotorSpecifications()

        # Operational state variables
        self.load_factor: float = 0.82  # Nominal steady operating point (82% load)
        self.operating_state: str = "RUNNING"
        self.is_running: bool = True
        self.energy_accumulator_kwh: float = 12450.0  # Simulated cumulative meter reading

        # Phase imbalance factors (multipliers per phase: L1, L2, L3)
        self.voltage_unbalance_factors = [1.0, 1.0, 1.0]
        self.current_unbalance_factors = [1.0, 1.0, 1.0]

        # Thermal state
        self.current_temperature_c: float = (
            self.specs.ambient_temperature_c
            + self.specs.rated_temperature_rise_c * (self.load_factor**1.6)
        )

        # Vibration state
        self.baseline_vibration_mms: float = 1.4  # ISO 10816-3 Good zone (< 2.3 mm/s)
        self.extra_vibration_mms: float = 0.0

        # Harmonic distortion (%)
        self.thd_voltage_pct: float = 1.8
        self.thd_current_pct: float = 3.2

        # Noise generators for realistic industrial measurement jitter
        self._v_noise = IndustrialNoiseGenerator(mean=0.0, std_dev=0.8, phi=0.8)
        self._i_noise = IndustrialNoiseGenerator(mean=0.0, std_dev=0.4, phi=0.8)
        self._pf_noise = IndustrialNoiseGenerator(mean=0.0, std_dev=0.003, phi=0.85)
        self._t_noise = IndustrialNoiseGenerator(mean=0.0, std_dev=0.08, phi=0.95)
        self._vib_noise = IndustrialNoiseGenerator(mean=0.0, std_dev=0.05, phi=0.7)

    def step(self, delta_time_sec: float = 1.0) -> dict[str, float | str | bool]:
        """Compute the next time step of motor physics and electrical variables."""
        if not self.is_running:
            # Motor is de-energized
            cooling_rate = (self.current_temperature_c - self.specs.ambient_temperature_c) / self.specs.thermal_time_constant_sec
            self.current_temperature_c -= cooling_rate * delta_time_sec
            return {
                "voltage_l1": 0.0,
                "voltage_l2": 0.0,
                "voltage_l3": 0.0,
                "voltage_avg": 0.0,
                "current_l1": 0.0,
                "current_l2": 0.0,
                "current_l3": 0.0,
                "current_avg": 0.0,
                "active_power_kw": 0.0,
                "reactive_power_kvar": 0.0,
                "apparent_power_kva": 0.0,
                "power_factor": 1.0,
                "frequency_hz": 60.0,
                "energy_kwh": round(self.energy_accumulator_kwh, 3),
                "current_unbalance_pct": 0.0,
                "voltage_unbalance_pct": 0.0,
                "thd_current_pct": 0.0,
                "thd_voltage_pct": 0.0,
                "temperature_c": round(self.current_temperature_c, 2),
                "vibration_rms_mms": 0.05,
                "operating_state": "STOPPED",
                "load_pct": 0.0,
                "is_simulated": True,
            }

        # 1. Voltages per phase
        v_base = self.specs.rated_voltage_v + self._v_noise.next_value()
        v_l1 = v_base * self.voltage_unbalance_factors[0]
        v_l2 = v_base * self.voltage_unbalance_factors[1]
        v_l3 = v_base * self.voltage_unbalance_factors[2]
        v_avg = (v_l1 + v_l2 + v_l3) / 3.0

        # NEMA Voltage Unbalance
        max_v_dev = max(abs(v_l1 - v_avg), abs(v_l2 - v_avg), abs(v_l3 - v_avg))
        voltage_unbalance = (max_v_dev / v_avg * 100.0) if v_avg > 0 else 0.0

        # 2. Power factor as function of load
        # Induction motor PF drops dramatically under partial loading
        pf_load_curve = 0.65 + 0.35 * math.sqrt(max(0.05, min(1.2, self.load_factor)))
        pf = min(0.98, max(0.20, self.specs.nominal_power_factor * pf_load_curve + self._pf_noise.next_value()))

        # 3. Active power & Efficiency
        # Efficiency curve drops under light load
        eff = self.specs.nominal_efficiency * (1.0 - 0.15 * (1.0 - min(1.0, self.load_factor)) ** 2)
        active_power_kw = (self.load_factor * self.specs.rated_power_kw) / max(0.5, eff)

        # 4. Phase currents
        # P = sqrt(3) * V * I * cos(phi) => I = (P * 1000) / (sqrt(3) * V * PF)
        denom = math.sqrt(3.0) * v_avg * pf
        i_avg_theoretical = (active_power_kw * 1000.0) / denom if denom > 0 else 0.0
        i_base = i_avg_theoretical + self._i_noise.next_value()

        # Phase imbalance amplification: NEMA MG-1 states 1% voltage unbalance causes 6-10% current unbalance
        i_l1 = max(0.0, i_base * self.current_unbalance_factors[0])
        i_l2 = max(0.0, i_base * self.current_unbalance_factors[1])
        i_l3 = max(0.0, i_base * self.current_unbalance_factors[2])
        i_avg = (i_l1 + i_l2 + i_l3) / 3.0

        max_i_dev = max(abs(i_l1 - i_avg), abs(i_l2 - i_avg), abs(i_l3 - i_avg))
        current_unbalance = (max_i_dev / i_avg * 100.0) if i_avg > 0 else 0.0

        # 5. Apparent & Reactive power
        apparent_power_kva = (math.sqrt(3.0) * v_avg * i_avg) / 1000.0
        q_squared = max(0.0, (apparent_power_kva**2) - (active_power_kw**2))
        reactive_power_kvar = math.sqrt(q_squared)

        # 6. Thermal dynamics: dT/dt = (P_loss - (T - T_amb)/R_th) / C_th
        p_loss_kw = active_power_kw - (self.load_factor * self.specs.rated_power_kw)
        # Extra losses from unbalance heating
        unbalance_loss_penalty = 1.0 + 2.0 * ((current_unbalance / 100.0) ** 2)
        target_temp = (
            self.specs.ambient_temperature_c
            + self.specs.rated_temperature_rise_c * ((self.load_factor * unbalance_loss_penalty) ** 1.6)
        )
        temp_delta = (target_temp - self.current_temperature_c) * (delta_time_sec / self.specs.thermal_time_constant_sec)
        self.current_temperature_c += temp_delta

        # 7. Mechanical vibration
        vibration_rms = (
            self.baseline_vibration_mms
            + (self.load_factor * 0.4)
            + self.extra_vibration_mms
            + self._vib_noise.next_value()
        )
        vibration_rms = max(0.1, vibration_rms)

        # 8. Cumulative energy increment
        # Energy (kWh) = Power (kW) * time (hours)
        self.energy_accumulator_kwh += (active_power_kw * delta_time_sec) / 3600.0

        return {
            "voltage_l1": round(v_l1, 1),
            "voltage_l2": round(v_l2, 1),
            "voltage_l3": round(v_l3, 1),
            "voltage_avg": round(v_avg, 1),
            "current_l1": round(i_l1, 2),
            "current_l2": round(i_l2, 2),
            "current_l3": round(i_l3, 2),
            "current_avg": round(i_avg, 2),
            "active_power_kw": round(active_power_kw, 2),
            "reactive_power_kvar": round(reactive_power_kvar, 2),
            "apparent_power_kva": round(apparent_power_kva, 2),
            "power_factor": round(pf, 3),
            "frequency_hz": round(self.specs.nominal_frequency_hz + random.uniform(-0.04, 0.04), 2),
            "energy_kwh": round(self.energy_accumulator_kwh, 3),
            "current_unbalance_pct": round(current_unbalance, 2),
            "voltage_unbalance_pct": round(voltage_unbalance, 2),
            "thd_current_pct": round(self.thd_current_pct + random.uniform(-0.1, 0.1), 2),
            "thd_voltage_pct": round(self.thd_voltage_pct + random.uniform(-0.05, 0.05), 2),
            "temperature_c": round(self.current_temperature_c + self._t_noise.next_value(), 2),
            "vibration_rms_mms": round(vibration_rms, 2),
            "operating_state": self.operating_state,
            "load_pct": round(self.load_factor * 100.0, 1),
            "is_simulated": True,
        }
