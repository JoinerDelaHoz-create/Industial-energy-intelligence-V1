/**
 * IEIP — Industrial Energy & Intelligence Platform
 * Frontend Controller & Real-Time Telemetry Client
 */

class IndustrialApp {
  constructor() {
    this.targetAssetCode = 'MTR-305';
    this.targetEquipmentId = 'e0000000-0000-0000-0000-000000000305';
    this.isChartPaused = false;
    this.trendChart = null;
    this.chartDataBuffer = {
      labels: [],
      power: [],
      current: []
    };

    this.init();
  }

  async init() {
    this.initNavigation();
    this.initChart();
    this.initClock();
    this.bindEvents();

    // Initial fetch
    await this.fetchPlantKPIs();
    await this.fetchRealtimeTelemetry();
    await this.fetchFleet();
    await this.fetchAnomalies();
    await this.fetchAlerts();
    await this.fetchRecommendations();
    await this.fetchSimulationStatus();

    // Periodic telemetry loop (1 Hz)
    setInterval(() => this.fetchRealtimeTelemetry(), 1000);
    // Secondary polling (every 3 seconds) for anomalies, alerts, KPIs
    setInterval(() => {
      this.fetchPlantKPIs();
      this.fetchAnomalies();
      this.fetchAlerts();
      this.fetchSimulationStatus();
    }, 3000);
  }

  initClock() {
    const updateClock = () => {
      const now = new Date();
      const el = document.getElementById('system-clock');
      if (el) {
        el.textContent = now.toISOString().substring(11, 19) + ' UTC';
      }
    };
    updateClock();
    setInterval(updateClock, 1000);
  }

  initNavigation() {
    const tabs = document.querySelectorAll('.nav-tab');
    tabs.forEach(tab => {
      tab.addEventListener('click', () => {
        tabs.forEach(t => t.classList.remove('active'));
        document.querySelectorAll('.tab-view').forEach(v => v.classList.remove('active'));

        tab.classList.add('active');
        const targetId = tab.getAttribute('data-target');
        const targetView = document.getElementById(targetId);
        if (targetView) {
          targetView.classList.add('active');
        }
      });
    });

    const topAlertBtn = document.getElementById('btn-top-alerts');
    if (topAlertBtn) {
      topAlertBtn.addEventListener('click', () => {
        const alertTab = document.querySelector('[data-target="view-alerts"]');
        if (alertTab) alertTab.click();
      });
    }
  }

  initChart() {
    const ctx = document.getElementById('liveTrendChart');
    if (!ctx) return;

    this.trendChart = new Chart(ctx, {
      type: 'line',
      data: {
        labels: [],
        datasets: [
          {
            label: 'Potencia Activa (kW)',
            borderColor: '#06b6d4',
            backgroundColor: 'rgba(6, 182, 212, 0.1)',
            data: [],
            borderWidth: 2,
            tension: 0.3,
            fill: true,
            yAxisID: 'yPower',
          },
          {
            label: 'Corriente Media (A)',
            borderColor: '#f59e0b',
            backgroundColor: 'transparent',
            data: [],
            borderWidth: 2,
            tension: 0.3,
            borderDash: [4, 4],
            yAxisID: 'yCurrent',
          }
        ]
      },
      options: {
        responsive: true,
        maintainAspectRatio: false,
        animation: { duration: 0 },
        scales: {
          x: {
            grid: { color: '#1f2937' },
            ticks: { color: '#9ca3af', font: { family: 'JetBrains Mono', size: 10 } }
          },
          yPower: {
            position: 'left',
            grid: { color: '#1f2937' },
            ticks: { color: '#06b6d4', font: { family: 'JetBrains Mono', size: 11 } },
            title: { display: true, text: 'Potencia (kW)', color: '#06b6d4' }
          },
          yCurrent: {
            position: 'right',
            grid: { drawOnChartArea: false },
            ticks: { color: '#f59e0b', font: { family: 'JetBrains Mono', size: 11 } },
            title: { display: true, text: 'Corriente (A)', color: '#f59e0b' }
          }
        },
        plugins: {
          legend: {
            labels: { color: '#f3f4f6', font: { family: 'Inter', size: 11 } }
          }
        }
      }
    });

    const pauseBtn = document.getElementById('btn-chart-pause');
    if (pauseBtn) {
      pauseBtn.addEventListener('click', () => {
        this.isChartPaused = !this.isChartPaused;
        pauseBtn.textContent = this.isChartPaused ? 'Reanudar' : 'Pausar';
        pauseBtn.classList.toggle('active', this.isChartPaused);
      });
    }
  }

  bindEvents() {
    const quickReset = document.getElementById('btn-quick-reset');
    const globalReset = document.getElementById('btn-global-reset');
    if (quickReset) quickReset.addEventListener('click', () => this.resetSimulation());
    if (globalReset) globalReset.addEventListener('click', () => this.resetSimulation());

    const anomFilter = document.getElementById('filter-anomaly-type');
    if (anomFilter) {
      anomFilter.addEventListener('change', () => this.fetchAnomalies());
    }
  }

  // ── API Fetchers ────────────────────────────────────────────────────────────

  async fetchPlantKPIs() {
    try {
      const res = await fetch('/api/v1/kpis/plant');
      if (!res.ok) return;
      const json = await res.json();
      const d = json.data;

      document.getElementById('val-total-power').textContent = (d.active_power_total_kw || 0).toFixed(1);
      document.getElementById('val-daily-energy').textContent = (d.daily_energy_consumption_kwh || 0).toFixed(1);
      document.getElementById('val-daily-cost').textContent = `$${(d.daily_energy_cost_usd || 0).toFixed(2)} USD/día`;
      document.getElementById('val-global-pf').textContent = (d.average_power_factor || 0.88).toFixed(2);
      document.getElementById('val-active-anomalies').textContent = d.active_anomalies_count || 0;
      document.getElementById('val-open-alerts').textContent = d.open_alerts_count || 0;
      document.getElementById('top-alert-count').textContent = d.open_alerts_count || 0;
    } catch (e) {
      // Server not reachable or booting
    }
  }

  async fetchRealtimeTelemetry() {
    try {
      const res = await fetch(`/api/v1/equipment/${this.targetEquipmentId}/realtime`);
      if (!res.ok) return;
      const json = await res.json();
      const d = json.data;
      if (!d) return;

      // Update Phase Currents
      const c1 = d.current_l1 || 0;
      const c2 = d.current_l2 || 0;
      const c3 = d.current_l3 || 0;
      const cAvg = ((c1 + c2 + c3) / 3).toFixed(1);

      document.getElementById('val-cur-l1').textContent = `${c1.toFixed(1)} A`;
      document.getElementById('val-cur-l2').textContent = `${c2.toFixed(1)} A`;
      document.getElementById('val-cur-l3').textContent = `${c3.toFixed(1)} A`;
      document.getElementById('val-cur-avg').textContent = `${cAvg} A`;

      const maxFLA = 140.0;
      document.getElementById('bar-cur-l1').style.width = `${Math.min(100, (c1 / maxFLA) * 100)}%`;
      document.getElementById('bar-cur-l2').style.width = `${Math.min(100, (c2 / maxFLA) * 100)}%`;
      document.getElementById('bar-cur-l3').style.width = `${Math.min(100, (c3 / maxFLA) * 100)}%`;

      const unb = d.current_unbalance_pct || 0;
      const nemaBadge = document.getElementById('nema-unbalance-badge');
      nemaBadge.textContent = `NEMA: ${unb.toFixed(1)}%`;
      nemaBadge.className = unb >= 10 ? 'badge-sub danger-text' : (unb >= 5 ? 'badge-sub warning-text' : 'badge-sub');

      // Update Voltages
      document.getElementById('val-volt-l1').textContent = (d.voltage_l1 || 0).toFixed(1);
      document.getElementById('val-volt-l2').textContent = (d.voltage_l2 || 0).toFixed(1);
      document.getElementById('val-volt-l3').textContent = (d.voltage_l3 || 0).toFixed(1);
      document.getElementById('val-freq').textContent = `${(d.frequency_hz || 60).toFixed(2)} Hz`;

      // Update Power Factor
      const pf = d.power_factor || 0.88;
      document.getElementById('val-pf').textContent = pf.toFixed(2);
      document.getElementById('val-active-kw').textContent = `${(d.active_power_kw || 0).toFixed(1)} kW`;
      document.getElementById('val-reactive-kvar').textContent = `${(d.reactive_power_kvar || 0).toFixed(1)} kVAR`;

      const pfCircle = document.getElementById('pf-dial-circle');
      if (pf < 0.75) {
        pfCircle.style.borderColor = 'var(--color-crimson)';
        pfCircle.style.boxShadow = '0 0 15px var(--color-crimson-glow)';
        document.getElementById('pf-penalty-badge').textContent = 'Penalización Activa!';
        document.getElementById('pf-penalty-badge').className = 'badge-sub danger-text';
      } else if (pf < 0.85) {
        pfCircle.style.borderColor = 'var(--color-amber)';
        pfCircle.style.boxShadow = '0 0 15px var(--color-amber-glow)';
        document.getElementById('pf-penalty-badge').textContent = 'Advertencia FP';
        document.getElementById('pf-penalty-badge').className = 'badge-sub warning-text';
      } else {
        pfCircle.style.borderColor = 'var(--color-emerald)';
        pfCircle.style.boxShadow = '0 0 15px var(--color-emerald-glow)';
        document.getElementById('pf-penalty-badge').textContent = 'Sin Penalización';
        document.getElementById('pf-penalty-badge').className = 'badge-sub';
      }

      // Update Thermal & Vibration
      const temp = d.temperature_c || 65;
      document.getElementById('val-temp').textContent = `${temp.toFixed(1)} °C`;
      document.getElementById('bar-temp').style.width = `${Math.min(100, (temp / 130) * 100)}%`;

      const vib = d.vibration_rms_mms || 1.4;
      document.getElementById('val-vib').textContent = `${vib.toFixed(2)} mm/s`;
      document.getElementById('bar-vib').style.width = `${Math.min(100, (vib / 8.0) * 100)}%`;

      const vibBadge = document.getElementById('iso-vib-badge');
      if (vib >= 4.5) {
        vibBadge.textContent = 'ISO Zona D (Peligro)';
        vibBadge.className = 'badge-sub danger-text';
      } else if (vib >= 2.8) {
        vibBadge.textContent = 'ISO Zona C (Alerta)';
        vibBadge.className = 'badge-sub warning-text';
      } else {
        vibBadge.textContent = 'ISO Zona A (Bueno)';
        vibBadge.className = 'badge-sub';
      }

      // Update State Badge
      const stateBadge = document.getElementById('live-state-badge');
      const state = d.operating_state || 'OPERACIONAL';
      stateBadge.textContent = state;
      if (state.includes('OVERLOAD') || state.includes('FAULT') || state.includes('TRIP')) {
        stateBadge.className = 'badge badge-danger';
      } else if (state.includes('UNBALANCED') || state.includes('SAG')) {
        stateBadge.className = 'badge badge-warning';
      } else {
        stateBadge.className = 'badge badge-normal';
      }

      // Append point to Chart
      if (!this.isChartPaused && this.trendChart) {
        const timeLabel = new Date().toTimeString().substring(0, 8);
        this.chartDataBuffer.labels.push(timeLabel);
        this.chartDataBuffer.power.push(d.active_power_kw || 0);
        this.chartDataBuffer.current.push(cAvg);

        if (this.chartDataBuffer.labels.length > 40) {
          this.chartDataBuffer.labels.shift();
          this.chartDataBuffer.power.shift();
          this.chartDataBuffer.current.shift();
        }

        this.trendChart.data.labels = this.chartDataBuffer.labels;
        this.trendChart.data.datasets[0].data = this.chartDataBuffer.power;
        this.trendChart.data.datasets[1].data = this.chartDataBuffer.current;
        this.trendChart.update();
      }
    } catch (e) {
      // Ingestion silent
    }
  }

  async fetchFleet() {
    try {
      const res = await fetch('/api/v1/equipment');
      if (!res.ok) return;
      const json = await res.json();
      const items = json.data || [];
      const container = document.getElementById('fleet-container');
      if (!container) return;

      container.innerHTML = items.map(eq => `
        <div class="fleet-card" onclick="app.selectEquipment('${eq.id}', '${eq.asset_code}')">
          <div class="fleet-head">
            <div>
              <span class="fleet-code">${eq.asset_code}</span>
              <h4 class="fleet-name">${eq.name}</h4>
            </div>
            <span class="badge ${eq.operating_status === 'OPERATIONAL' ? 'badge-normal' : (eq.operating_status === 'WARNING' ? 'badge-warning' : 'badge-danger')}">
              ${eq.operating_status}
            </span>
          </div>
          <div class="fleet-stats">
            <div class="stat-item">
              <span>Potencia Activa</span>
              <strong>${(eq.current_active_power_kw || (eq.rated_power_kw * 0.8)).toFixed(1)} kW</strong>
            </div>
            <div class="stat-item">
              <span>Factor Potencia</span>
              <strong>${(eq.current_power_factor || 0.88).toFixed(2)}</strong>
            </div>
            <div class="stat-item">
              <span>Temp. Carcasa</span>
              <strong>${(eq.current_temperature_c || 68.0).toFixed(1)} °C</strong>
            </div>
            <div class="stat-item">
              <span>Alarmas Activas</span>
              <strong class="${eq.active_alerts_count > 0 ? 'danger-text' : ''}">${eq.active_alerts_count || 0}</strong>
            </div>
          </div>
          <span class="kpi-foot">Ubicación: ${eq.location}</span>
        </div>
      `).join('');
    } catch (e) {}
  }

  async fetchAnomalies() {
    try {
      const typeFilter = document.getElementById('filter-anomaly-type')?.value || '';
      const url = typeFilter ? `/api/v1/anomalies?anomaly_type=${typeFilter}` : '/api/v1/anomalies';
      const res = await fetch(url);
      if (!res.ok) return;
      const json = await res.json();
      const items = json.data?.items || [];
      const tbody = document.getElementById('tbody-anomalies');
      if (!tbody) return;

      if (items.length === 0) {
        tbody.innerHTML = `<tr><td colspan="9" style="text-align:center; color: var(--text-dim); padding: 30px;">No se registran anomalías en la ventana actual. Sistema operando bajo parámetros normales.</td></tr>`;
        return;
      }

      tbody.innerHTML = items.map(a => `
        <tr>
          <td style="font-family: var(--font-mono); font-size: 0.78rem;">${new Date(a.detected_at).toLocaleTimeString()}</td>
          <td><span class="badge-sub">MTR-305</span></td>
          <td><strong>${a.anomaly_type}</strong></td>
          <td>
            <span class="badge ${a.severity === 'CRITICAL' ? 'badge-danger' : (a.severity === 'HIGH' ? 'badge-warning' : 'badge-normal')}">
              ${a.severity}
            </span>
          </td>
          <td style="font-family: var(--font-mono); font-size: 0.75rem;">${a.algorithm_used}</td>
          <td style="font-family: var(--font-mono); color: var(--color-cyan);">${a.observed_value}</td>
          <td style="font-family: var(--font-mono); color: var(--text-muted);">${a.expected_value || '—'}</td>
          <td>
            <span style="font-family: var(--font-mono); font-size: 0.8rem;">${(a.confidence_score * 100).toFixed(0)}%</span>
          </td>
          <td>
            <span class="badge badge-outline">${a.status}</span>
          </td>
        </tr>
      `).join('');
    } catch (e) {}
  }

  async fetchAlerts() {
    try {
      const res = await fetch('/api/v1/alerts');
      if (!res.ok) return;
      const json = await res.json();
      const items = json.data?.items || [];
      const tbody = document.getElementById('tbody-alerts');
      if (!tbody) return;

      if (items.length === 0) {
        tbody.innerHTML = `<tr><td colspan="7" style="text-align:center; color: var(--text-dim); padding: 30px;">No hay alarmas activas. Todas las condiciones están resueltas.</td></tr>`;
        return;
      }

      tbody.innerHTML = items.map(al => `
        <tr>
          <td style="font-family: var(--font-mono); font-size: 0.78rem;">${new Date(al.last_triggered_at).toLocaleTimeString()}</td>
          <td><span class="badge-sub">MTR-305</span></td>
          <td>
            <strong>${al.title}</strong>
            <div style="font-size: 0.75rem; color: var(--text-muted); margin-top: 2px;">${al.message}</div>
          </td>
          <td>
            <span class="badge ${al.severity === 'CRITICAL' ? 'badge-danger' : 'badge-warning'}">${al.severity}</span>
          </td>
          <td style="text-align: center; font-family: var(--font-mono); font-weight: 700; color: var(--color-amber);">
            ${al.occurrence_count}
          </td>
          <td>
            <span class="badge ${al.status === 'OPEN' ? 'badge-danger' : (al.status === 'ACKNOWLEDGED' ? 'badge-warning' : 'badge-normal')}">
              ${al.status}
            </span>
          </td>
          <td>
            ${al.status === 'OPEN' ? `<button class="btn-sm btn-outline" onclick="app.acknowledgeAlert('${al.id}')">Reconocer (ACK)</button>` : ''}
            ${al.status !== 'RESOLVED' ? `<button class="btn-sm btn-primary" onclick="app.resolveAlert('${al.id}')" style="margin-left: 6px;">Resolver</button>` : '<span style="color: var(--color-emerald); font-size: 0.75rem;">Resuelta</span>'}
          </td>
        </tr>
      `).join('');
    } catch (e) {}
  }

  async fetchRecommendations() {
    try {
      const res = await fetch('/api/v1/maintenance');
      if (!res.ok) return;
      const json = await res.json();
      const items = json.data || [];
      const container = document.getElementById('maint-container');
      if (!container) return;

      if (items.length === 0) {
        container.innerHTML = `<p style="color: var(--text-dim); padding: 20px;">No hay recomendaciones pendientes. Parámetros en rango óptimo.</p>`;
        return;
      }

      container.innerHTML = items.map(r => `
        <div class="rec-card">
          <div style="display: flex; justify-content: space-between; margin-bottom: 8px;">
            <span class="badge ${r.priority === 'IMMEDIATE' || r.priority === 'HIGH' ? 'badge-danger' : 'badge-warning'}">Prioridad: ${r.priority}</span>
            <span class="badge badge-outline">${r.status}</span>
          </div>
          <h4 class="rec-title">${r.title}</h4>
          <p class="rec-rationale">${r.technical_rationale}</p>
          <div class="rec-actions">${r.suggested_actions}</div>
          <div class="rec-loss-badge">
            <span>Desperdicio Estimado: ${r.estimated_monthly_kwh_waste || 0} kWh/mes</span>
            <span>Impacto Financiero: $${r.estimated_monthly_cost_usd || 0} USD/mes</span>
          </div>
        </div>
      `).join('');
    } catch (e) {}
  }

  async fetchSimulationStatus() {
    try {
      const res = await fetch('/api/v1/simulation/status');
      if (!res.ok) return;
      const json = await res.json();
      const d = json.data;

      const activeScen = d.active_scenario || 'NORMAL_OPERATION';
      document.getElementById('sim-active-scenario').textContent = activeScen;
      document.getElementById('sim-target-code').textContent = d.target_asset_code || 'MTR-305';
      document.getElementById('sim-remaining-sec').textContent = `${(d.remaining_seconds || 0).toFixed(0)}s`;
      document.getElementById('sim-samples-count').textContent = d.total_samples_generated || 0;

      const banner = document.getElementById('active-scenario-banner');
      const bannerText = document.getElementById('active-scenario-text');

      if (activeScen !== 'NORMAL_OPERATION' && d.remaining_seconds > 0) {
        banner.classList.remove('hidden');
        bannerText.textContent = `Escenario Activo: ${activeScen} (${d.remaining_seconds.toFixed(0)}s restantes)`;
      } else {
        banner.classList.add('hidden');
      }
    } catch (e) {}
  }

  // ── Actions ─────────────────────────────────────────────────────────────────

  async triggerScenario(scenarioId) {
    try {
      const res = await fetch('/api/v1/simulation/trigger', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          scenario_id: scenarioId,
          duration_seconds: 60,
          severity_multiplier: 1.2
        })
      });
      if (res.ok) {
        await this.fetchSimulationStatus();
        // Switch to live view immediately to show the reaction
        const liveTab = document.querySelector('[data-target="view-live"]');
        if (liveTab) liveTab.click();
      }
    } catch (e) {
      alert(`Error al activar escenario: ${e.message}`);
    }
  }

  async resetSimulation() {
    try {
      await fetch('/api/v1/simulation/reset', { method: 'POST' });
      await this.fetchSimulationStatus();
    } catch (e) {}
  }

  async acknowledgeAlert(alertId) {
    try {
      await fetch(`/api/v1/alerts/${alertId}/acknowledge`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ comment: 'Verificado por operador de turno' })
      });
      await this.fetchAlerts();
      await this.fetchPlantKPIs();
    } catch (e) {}
  }

  async resolveAlert(alertId) {
    const comment = prompt('Ingrese notas de resolución o causa raíz:', 'Condición subsanada tras inspección');
    if (!comment) return;

    try {
      await fetch(`/api/v1/alerts/${alertId}/resolve`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ resolution_comment: comment })
      });
      await this.fetchAlerts();
      await this.fetchPlantKPIs();
    } catch (e) {}
  }

  selectEquipment(equipId, assetCode) {
    this.targetEquipmentId = equipId;
    this.targetAssetCode = assetCode;
    const liveTab = document.querySelector('[data-target="view-live"]');
    if (liveTab) liveTab.click();
  }
}

// Instantiate globally on page load
let app;
window.addEventListener('DOMContentLoaded', () => {
  app = new IndustrialApp();
  window.app = app;
});
