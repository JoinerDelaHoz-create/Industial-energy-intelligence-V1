"""
IEIP API v1 — Maintenance Recommendations Endpoints
"""

from __future__ import annotations

import uuid
from datetime import datetime, timezone

from fastapi import APIRouter, Depends
from sqlalchemy.ext.asyncio import AsyncSession

from app.core.exceptions import NotFoundError
from app.dependencies import get_db, get_optional_user
from app.models.maintenance import RecommendationStatus
from app.models.user import User
from app.repositories.maintenance import MaintenanceRepository
from app.schemas.common import APIResponse
from app.schemas.maintenance import (
    MaintenanceRecommendationResponse,
    MaintenanceRecommendationUpdate,
)

router = APIRouter(prefix="/maintenance", tags=["Maintenance Recommendations"])


@router.get("", response_model=APIResponse[list[MaintenanceRecommendationResponse]])
async def list_recommendations(
    equipment_id: uuid.UUID | None = None,
    status: RecommendationStatus | None = None,
    db: AsyncSession = Depends(get_db),
    _user: User | None = Depends(get_optional_user),
):
    """Retrieve condition-based maintenance engineering recommendations."""
    repo = MaintenanceRepository(db)
    if equipment_id:
        recs = await repo.list_for_equipment(equipment_id, status=status)
    else:
        recs = await repo.list_all_active()
    return APIResponse(data=[MaintenanceRecommendationResponse.model_validate(r) for r in recs])


@router.patch("/{rec_id}", response_model=APIResponse[MaintenanceRecommendationResponse])
async def update_recommendation(
    rec_id: uuid.UUID,
    payload: MaintenanceRecommendationUpdate,
    db: AsyncSession = Depends(get_db),
    user: User | None = Depends(get_optional_user),
):
    """Update status or priority of maintenance recommendation."""
    repo = MaintenanceRepository(db)
    rec = await repo.get_by_id(rec_id)
    if not rec:
        raise NotFoundError("Maintenance recommendation not found")

    if payload.status:
        rec.status = payload.status
        if payload.status == RecommendationStatus.IMPLEMENTED:
            rec.implemented_at = datetime.now(timezone.utc)
            rec.implemented_by_id = user.id if user else None
    if payload.priority:
        rec.priority = payload.priority

    await db.commit()
    return APIResponse(message="Recommendation updated", data=MaintenanceRecommendationResponse.model_validate(rec))
