"""
IEIP Backend — Operational Event ORM Model

Immutable event ledger logging equipment starts, stops, trips, threshold updates,
operator overrides, and simulated fault injections for full chronological traceability.
"""

from __future__ import annotations

import enum
import uuid
from datetime import datetime
from typing import Any

from sqlalchemy import (
    DateTime,
    Enum as SAEnum,
    ForeignKey,
    Index,
    String,
    Text,
)
from sqlalchemy.dialects.postgresql import JSONB, UUID
from sqlalchemy.orm import Mapped, mapped_column

from app.core.database import Base
from app.models.mixins import TimestampMixin, UUIDMixin


class EventCategory(str, enum.Enum):
    """Broad category of operational event."""

    EQUIPMENT_STATE = "EQUIPMENT_STATE"
    FAULT_TRIP = "FAULT_TRIP"
    OPERATOR_ACTION = "OPERATOR_ACTION"
    SIMULATION_INJECTION = "SIMULATION_INJECTION"
    MAINTENANCE = "MAINTENANCE"
    SYSTEM = "SYSTEM"


class OperationalEvent(UUIDMixin, TimestampMixin, Base):
    """Chronological event record in plant historian."""

    __tablename__ = "operational_events"

    equipment_id: Mapped[uuid.UUID | None] = mapped_column(
        UUID(as_uuid=True),
        ForeignKey("equipment.id", ondelete="CASCADE"),
        nullable=True,
        index=True,
    )
    user_id: Mapped[uuid.UUID | None] = mapped_column(
        UUID(as_uuid=True),
        ForeignKey("users.id", ondelete="SET NULL"),
        nullable=True,
        index=True,
    )

    event_time: Mapped[datetime] = mapped_column(
        DateTime(timezone=True),
        nullable=False,
        index=True,
        comment="Timestamp when the event occurred in the physical/virtual plant",
    )
    category: Mapped[EventCategory] = mapped_column(
        SAEnum(EventCategory, name="event_category_enum"),
        nullable=False,
        index=True,
    )
    event_name: Mapped[str] = mapped_column(
        String(150),
        nullable=False,
        comment="Concise event identifier, e.g. MOTOR_OVERLOAD_TRIP, SCENARIO_STARTED",
    )
    description: Mapped[str] = mapped_column(Text, nullable=False)
    source: Mapped[str] = mapped_column(
        String(100),
        nullable=False,
        default="SYSTEM",
        comment="Entity that raised the event: SYSTEM, SIMULATOR, USER, SCADA",
    )
    payload: Mapped[dict[str, Any] | None] = mapped_column(
        JSONB,
        nullable=True,
        comment="Arbitrary contextual parameters associated with event",
    )

    __table_args__ = (
        Index("idx_event_time_cat", "event_time", "category"),
    )

    def __repr__(self) -> str:
        return f"<OperationalEvent {self.event_name} @ {self.event_time}>"
