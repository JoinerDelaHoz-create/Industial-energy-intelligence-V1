"""
IEIP Backend — HTTP Middlewares

Provides request tracing (X-Request-ID), execution timing (X-Process-Time-Ms),
and structured request/response access logging.
"""

from __future__ import annotations

import time
import uuid
from typing import Callable

from starlette.middleware.base import BaseHTTPMiddleware
from starlette.requests import Request
from starlette.responses import Response

from app.core.logging import get_logger

logger = get_logger("ieip.http")


class RequestLoggingMiddleware(BaseHTTPMiddleware):
    """Logs incoming HTTP requests and response performance metrics."""

    async def dispatch(self, request: Request, call_next: Callable) -> Response:
        request_id = request.headers.get("X-Request-ID", str(uuid.uuid4()))
        start_time = time.perf_counter()

        response = await call_next(request)

        duration_ms = round((time.perf_counter() - start_time) * 1000.0, 2)
        response.headers["X-Request-ID"] = request_id
        response.headers["X-Process-Time-Ms"] = str(duration_ms)

        # Log at INFO level for non-static endpoints
        path = request.url.path
        if not path.startswith(("/docs", "/redoc", "/openapi.json", "/static")):
            logger.info(
                f"{request.method} {path} -> {response.status_code} ({duration_ms}ms)",
                method=request.method,
                path=path,
                status_code=response.status_code,
                duration_ms=duration_ms,
                request_id=request_id,
            )

        return response
