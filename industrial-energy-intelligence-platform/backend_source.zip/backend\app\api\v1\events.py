"""
IEIP API v1 — Operational Events Endpoints
"""

from __future__ import annotations

import uuid
from datetime import datetime

from fastapi import APIRouter, Depends, Query, status
from sqlalchemy.ext.asyncio import AsyncSession

from app.dependencies import get_current_user, get_db, get_optional_user
from app.models.event import EventCategory, OperationalEvent
from app.models.user import User
from app.repositories.event import EventRepository
from app.schemas.common import APIResponse, PaginatedResponse
from app.schemas.event import OperationalEventCreate, OperationalEventResponse

router = APIRouter(prefix="/events", tags=["Operational Events"])


@router.get("", response_model=APIResponse[PaginatedResponse[OperationalEventResponse]])
async def list_events(
    equipment_id: uuid.UUID | None = None,
    category: EventCategory | None = None,
    source: str | None = None,
    start_time: datetime | None = None,
    end_time: datetime | None = None,
    page: int = Query(1, ge=1),
    page_size: int = Query(50, ge=1, le=500),
    db: AsyncSession = Depends(get_db),
    _user: User | None = Depends(get_optional_user),
):
    """Retrieve chronological historian events with filtering."""
    repo = EventRepository(db)
    skip = (page - 1) * page_size
    items, total = await repo.list_filtered(
        equipment_id=equipment_id,
        category=category,
        source=source,
        start_time=start_time,
        end_time=end_time,
        skip=skip,
        limit=page_size,
    )
    total_pages = (total + page_size - 1) // page_size if total > 0 else 0

    return APIResponse(
        data=PaginatedResponse(
            items=[OperationalEventResponse.model_validate(e) for e in items],
            total=total,
            page=page,
            page_size=page_size,
            total_pages=total_pages,
        )
    )


@router.post("", response_model=APIResponse[OperationalEventResponse], status_code=status.HTTP_201_CREATED)
async def create_event(
    payload: OperationalEventCreate,
    db: AsyncSession = Depends(get_db),
    user: User | None = Depends(get_optional_user),
):
    """Record an operational event in the plant historian."""
    repo = EventRepository(db)
    event = OperationalEvent(
        equipment_id=payload.equipment_id,
        user_id=user.id if user else None,
        event_time=payload.event_time,
        category=payload.category,
        event_name=payload.event_name,
        description=payload.description,
        source=payload.source,
        payload=payload.payload,
    )
    await repo.create(event)
    await db.commit()
    return APIResponse(message="Event recorded", data=OperationalEventResponse.model_validate(event))
