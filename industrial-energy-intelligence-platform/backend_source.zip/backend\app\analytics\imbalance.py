"""
IEIP Analytics — Phase Imbalance & NEMA Derating Analyzer

Evaluates three-phase voltage and current unbalance according to NEMA MG-1
and IEEE 1459 standards. Calculates thermal derating penalty.
"""

from __future__ import annotations

from typing import Any
from app.analytics.threshold import AnomalyCandidate
from app.models.anomaly import AnomalySeverity, AnomalyType


class PhaseImbalanceDetector:
    """NEMA MG-1 / IEEE Phase Imbalance and Derating Evaluator."""

    def evaluate(self, telemetry: dict[str, Any], equipment_specs: dict[str, Any]) -> list[AnomalyCandidate]:
        candidates: list[AnomalyCandidate] = []

        i1 = telemetry.get("current_l1")
        i2 = telemetry.get("current_l2")
        i3 = telemetry.get("current_l3")

        if i1 is None or i2 is None or i3 is None:
            return candidates

        i_avg = (i1 + i2 + i3) / 3.0
        # If motor is de-energized or draw is trivial, skip
        if i_avg < 2.0:
            return candidates

        # Check for single-phasing (loss of a phase)
        min_current = min(i1, i2, i3)
        if min_current < 1.0 and i_avg > 15.0:
            candidates.append(
                AnomalyCandidate(
                    anomaly_type=AnomalyType.PHASE_IMBALANCE,
                    severity=AnomalySeverity.CRITICAL,
                    algorithm="NEMA_SINGLE_PHASING",
                    metric_name="current_unbalance_pct",
                    observed_value=100.0,
                    expected_value=0.0,
                    threshold_value=10.0,
                    deviation_pct=100.0,
                    confidence_score=0.99,
                    description="Pérdida inminente de fase (monofasismo). Una de las fases no registra corriente mientras las otras soportan sobrecarga.",
                    context={"current_l1": i1, "current_l2": i2, "current_l3": i3},
                )
            )
            return candidates

        # NEMA Current Unbalance Percentage
        max_dev = max(abs(i1 - i_avg), abs(i2 - i_avg), abs(i3 - i_avg))
        current_unbalance = (max_dev / i_avg) * 100.0

        if current_unbalance >= 10.0:
            # Over 10% unbalance induces extreme rotor eddy current heating
            derating_factor = round(max(0.70, 1.0 - (current_unbalance * 0.02)), 2)
            candidates.append(
                AnomalyCandidate(
                    anomaly_type=AnomalyType.PHASE_IMBALANCE,
                    severity=AnomalySeverity.CRITICAL if current_unbalance >= 15.0 else AnomalySeverity.HIGH,
                    algorithm="NEMA_MG1_CURRENT_UNBALANCE",
                    metric_name="current_unbalance_pct",
                    observed_value=round(current_unbalance, 2),
                    expected_value=2.0,
                    threshold_value=10.0,
                    deviation_pct=round(current_unbalance, 1),
                    confidence_score=0.96,
                    description=(
                        f"Desbalance severo de corrientes NEMA ({current_unbalance:.1f}%). "
                        f"Factor de desclasificación estimado: {derating_factor}. Riesgo de fatiga térmica en devanados."
                    ),
                    context={
                        "current_l1": i1,
                        "current_l2": i2,
                        "current_l3": i3,
                        "derating_factor": derating_factor,
                    },
                )
            )
        elif current_unbalance >= 5.0:
            candidates.append(
                AnomalyCandidate(
                    anomaly_type=AnomalyType.PHASE_IMBALANCE,
                    severity=AnomalySeverity.MEDIUM,
                    algorithm="NEMA_MG1_CURRENT_UNBALANCE",
                    metric_name="current_unbalance_pct",
                    observed_value=round(current_unbalance, 2),
                    expected_value=2.0,
                    threshold_value=5.0,
                    deviation_pct=round(current_unbalance, 1),
                    confidence_score=0.90,
                    description=f"Desbalance moderado de corrientes ({current_unbalance:.1f}%). Supera recomendación IEEE (<5%).",
                    context={"current_l1": i1, "current_l2": i2, "current_l3": i3},
                )
            )

        return candidates
