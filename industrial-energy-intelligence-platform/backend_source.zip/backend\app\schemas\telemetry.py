"""
IEIP Backend — Telemetry Schemas
"""

from __future__ import annotations

import uuid
from datetime import datetime
from pydantic import BaseModel, ConfigDict, Field


class TelemetryIngest(BaseModel):
    """Payload incoming from Edge/MQTT/Simulator/Modbus."""

    time: datetime = Field(default_factory=datetime.utcnow)
    measurement_point_id: uuid.UUID
    equipment_id: uuid.UUID

    # Three-phase voltages (V)
    voltage_l1: float | None = None
    voltage_l2: float | None = None
    voltage_l3: float | None = None
    voltage_avg: float | None = None

    # Three-phase currents (A)
    current_l1: float | None = None
    current_l2: float | None = None
    current_l3: float | None = None
    current_avg: float | None = None

    # Power & Energy
    active_power_kw: float | None = None
    reactive_power_kvar: float | None = None
    apparent_power_kva: float | None = None
    power_factor: float | None = None
    frequency_hz: float | None = None
    energy_kwh: float | None = None

    # Power Quality
    current_unbalance_pct: float | None = None
    voltage_unbalance_pct: float | None = None
    thd_current_pct: float | None = None
    thd_voltage_pct: float | None = None

    # Mechanical / Process
    temperature_c: float | None = None
    vibration_rms_mms: float | None = None
    operating_state: str | None = "RUNNING"
    load_pct: float | None = None

    # Metadata
    is_simulated: bool = True
    quality_code: int = 192


class TelemetryResponse(TelemetryIngest):
    model_config = ConfigDict(from_attributes=True)


class RealTimeSnapshot(BaseModel):
    """Latest reading snapshot for real-time dashboard dials and live gauges."""

    equipment_id: uuid.UUID
    asset_code: str
    timestamp: datetime
    active_power_kw: float
    reactive_power_kvar: float
    power_factor: float
    current_l1: float
    current_l2: float
    current_l3: float
    voltage_l1: float
    voltage_l2: float
    voltage_l3: float
    frequency_hz: float
    current_unbalance_pct: float
    temperature_c: float
    vibration_rms_mms: float
    operating_state: str
    load_pct: float
    is_simulated: bool


class AggregationBucket(BaseModel):
    """Aggregated time-bucket response (1m, 5m, 1h, 1d) from TimescaleDB."""

    bucket: datetime
    avg_power_kw: float | None = None
    max_power_kw: float | None = None
    min_power_kw: float | None = None
    total_energy_kwh: float | None = None
    avg_power_factor: float | None = None
    avg_current: float | None = None
    max_current: float | None = None
    avg_temperature: float | None = None
    max_vibration: float | None = None
    unbalance_max_pct: float | None = None
