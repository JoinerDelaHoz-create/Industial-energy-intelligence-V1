"""
IEIP Repositories — Alert Repository
"""

from __future__ import annotations

import uuid
from datetime import datetime
from typing import Sequence

from sqlalchemy import desc, func, select
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy.orm import selectinload

from app.models.alert import Alert, AlertStatus
from app.models.anomaly import AnomalySeverity
from app.repositories.base import BaseRepository


class AlertRepository(BaseRepository[Alert]):
    """Repository managing actionable operator alerts."""

    def __init__(self, session: AsyncSession) -> None:
        super().__init__(Alert, session)

    async def list_filtered(
        self,
        equipment_id: uuid.UUID | None = None,
        severity: AnomalySeverity | None = None,
        status: AlertStatus | None = None,
        start_time: datetime | None = None,
        end_time: datetime | None = None,
        skip: int = 0,
        limit: int = 50,
    ) -> tuple[Sequence[Alert], int]:
        stmt = select(Alert).options(
            selectinload(Alert.equipment),
            selectinload(Alert.acknowledged_by),
            selectinload(Alert.resolved_by),
        )
        count_stmt = select(func.count()).select_from(Alert)

        if equipment_id:
            stmt = stmt.where(Alert.equipment_id == equipment_id)
            count_stmt = count_stmt.where(Alert.equipment_id == equipment_id)
        if severity:
            stmt = stmt.where(Alert.severity == severity)
            count_stmt = count_stmt.where(Alert.severity == severity)
        if status:
            stmt = stmt.where(Alert.status == status)
            count_stmt = count_stmt.where(Alert.status == status)
        if start_time:
            stmt = stmt.where(Alert.last_triggered_at >= start_time)
            count_stmt = count_stmt.where(Alert.last_triggered_at >= start_time)
        if end_time:
            stmt = stmt.where(Alert.last_triggered_at <= end_time)
            count_stmt = count_stmt.where(Alert.last_triggered_at <= end_time)

        stmt = stmt.order_by(desc(Alert.last_triggered_at)).offset(skip).limit(limit)

        total_res = await self.session.execute(count_stmt)
        total = total_res.scalar() or 0

        res = await self.session.execute(stmt)
        return res.scalars().all(), total
