"""
IEIP API v1 — Anomalies Endpoints
"""

from __future__ import annotations

import uuid
from datetime import datetime

from fastapi import APIRouter, Depends, Query
from sqlalchemy.ext.asyncio import AsyncSession

from app.core.exceptions import NotFoundError
from app.dependencies import get_db, get_optional_user
from app.models.anomaly import AnomalySeverity, AnomalyStatus, AnomalyType
from app.models.user import User
from app.repositories.anomaly import AnomalyRepository
from app.schemas.anomaly import AnomalyResponse, AnomalyUpdate
from app.schemas.common import APIResponse, PaginatedResponse

router = APIRouter(prefix="/anomalies", tags=["Anomaly Detection Center"])


@router.get("", response_model=APIResponse[PaginatedResponse[AnomalyResponse]])
async def list_anomalies(
    equipment_id: uuid.UUID | None = None,
    anomaly_type: AnomalyType | None = None,
    severity: AnomalySeverity | None = None,
    status: AnomalyStatus | None = None,
    start_time: datetime | None = None,
    end_time: datetime | None = None,
    page: int = Query(1, ge=1),
    page_size: int = Query(50, ge=1, le=500),
    db: AsyncSession = Depends(get_db),
    _user: User | None = Depends(get_optional_user),
):
    """List detected anomalies with quantitative evidence, filters and pagination."""
    repo = AnomalyRepository(db)
    skip = (page - 1) * page_size
    items, total = await repo.list_filtered(
        equipment_id=equipment_id,
        anomaly_type=anomaly_type,
        severity=severity,
        status=status,
        start_time=start_time,
        end_time=end_time,
        skip=skip,
        limit=page_size,
    )

    total_pages = (total + page_size - 1) // page_size if total > 0 else 0

    return APIResponse(
        data=PaginatedResponse(
            items=[AnomalyResponse.model_validate(a) for a in items],
            total=total,
            page=page,
            page_size=page_size,
            total_pages=total_pages,
        )
    )


@router.get("/{anomaly_id}", response_model=APIResponse[AnomalyResponse])
async def get_anomaly(
    anomaly_id: uuid.UUID,
    db: AsyncSession = Depends(get_db),
    _user: User | None = Depends(get_optional_user),
):
    """Retrieve full algorithmic evidence and telemetry snapshot for an anomaly."""
    repo = AnomalyRepository(db)
    anomaly = await repo.get_by_id(anomaly_id)
    if not anomaly:
        raise NotFoundError("Anomaly not found")
    return APIResponse(data=AnomalyResponse.model_validate(anomaly))


@router.patch("/{anomaly_id}", response_model=APIResponse[AnomalyResponse])
async def update_anomaly(
    anomaly_id: uuid.UUID,
    payload: AnomalyUpdate,
    db: AsyncSession = Depends(get_db),
    _user: User | None = Depends(get_optional_user),
):
    """Update lifecycle status or resolution notes of an anomaly."""
    repo = AnomalyRepository(db)
    anomaly = await repo.get_by_id(anomaly_id)
    if not anomaly:
        raise NotFoundError("Anomaly not found")

    if payload.status:
        anomaly.status = payload.status
        if payload.status == AnomalyStatus.RESOLVED:
            anomaly.resolved_at = datetime.utcnow()
    if payload.resolution_notes:
        anomaly.resolution_notes = payload.resolution_notes

    await db.commit()
    return APIResponse(message="Anomaly updated", data=AnomalyResponse.model_validate(anomaly))
