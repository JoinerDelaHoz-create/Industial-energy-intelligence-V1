"""
IEIP Backend — Operational Alert ORM Model

Represents human-actionable notifications dispatched to plant operators and engineers.
Implements deduplication logic and strict lifecycle state machine (OPEN -> ACK -> RESOLVED).
"""

from __future__ import annotations

import enum
import uuid
from datetime import datetime
from typing import TYPE_CHECKING

from sqlalchemy import (
    DateTime,
    Enum as SAEnum,
    ForeignKey,
    Index,
    Integer,
    String,
    Text,
)
from sqlalchemy.dialects.postgresql import UUID
from sqlalchemy.orm import Mapped, mapped_column, relationship

from app.core.database import Base
from app.models.anomaly import AnomalySeverity
from app.models.mixins import TimestampMixin, UUIDMixin

if TYPE_CHECKING:
    from app.models.anomaly import Anomaly
    from app.models.equipment import Equipment
    from app.models.user import User


class AlertStatus(str, enum.Enum):
    """Lifecycle state of an operational alert."""

    OPEN = "OPEN"
    ACKNOWLEDGED = "ACKNOWLEDGED"
    RESOLVED = "RESOLVED"
    SUPPRESSED = "SUPPRESSED"


class Alert(UUIDMixin, TimestampMixin, Base):
    """Actionable notification for plant staff with deduplication and audit trail."""

    __tablename__ = "alerts"

    equipment_id: Mapped[uuid.UUID] = mapped_column(
        UUID(as_uuid=True),
        ForeignKey("equipment.id", ondelete="CASCADE"),
        nullable=False,
        index=True,
    )
    anomaly_id: Mapped[uuid.UUID | None] = mapped_column(
        UUID(as_uuid=True),
        ForeignKey("anomalies.id", ondelete="SET NULL"),
        nullable=True,
        index=True,
    )

    # ── Deduplication Key ───────────────────────────────────────────────────────
    dedup_key: Mapped[str] = mapped_column(
        String(255),
        nullable=False,
        index=True,
        comment="Hash of equipment_id + anomaly_type for aggregation within cooldown window",
    )

    # ── Core Info ───────────────────────────────────────────────────────────────
    title: Mapped[str] = mapped_column(String(200), nullable=False)
    message: Mapped[str] = mapped_column(Text, nullable=False)
    severity: Mapped[AnomalySeverity] = mapped_column(
        SAEnum(AnomalySeverity, name="alert_severity_enum"),
        nullable=False,
        index=True,
    )
    status: Mapped[AlertStatus] = mapped_column(
        SAEnum(AlertStatus, name="alert_status_enum"),
        nullable=False,
        default=AlertStatus.OPEN,
        server_default=AlertStatus.OPEN.value,
        index=True,
    )
    occurrence_count: Mapped[int] = mapped_column(
        Integer,
        nullable=False,
        default=1,
        comment="Number of times condition repeated within deduplication window",
    )

    # ── Timestamps & Personnel Audit Trail ──────────────────────────────────────
    first_triggered_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True),
        nullable=False,
        index=True,
    )
    last_triggered_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True),
        nullable=False,
    )

    acknowledged_at: Mapped[datetime | None] = mapped_column(
        DateTime(timezone=True),
        nullable=True,
    )
    acknowledged_by_id: Mapped[uuid.UUID | None] = mapped_column(
        UUID(as_uuid=True),
        ForeignKey("users.id", ondelete="SET NULL"),
        nullable=True,
    )

    resolved_at: Mapped[datetime | None] = mapped_column(
        DateTime(timezone=True),
        nullable=True,
    )
    resolved_by_id: Mapped[uuid.UUID | None] = mapped_column(
        UUID(as_uuid=True),
        ForeignKey("users.id", ondelete="SET NULL"),
        nullable=True,
    )
    resolution_comment: Mapped[str | None] = mapped_column(Text, nullable=True)

    # ── Relationships ────────────────────────────────────────────────────────────
    equipment: Mapped["Equipment"] = relationship("Equipment")
    anomaly: Mapped["Anomaly | None"] = relationship("Anomaly")
    acknowledged_by: Mapped["User | None"] = relationship(
        "User", foreign_keys=[acknowledged_by_id]
    )
    resolved_by: Mapped["User | None"] = relationship(
        "User", foreign_keys=[resolved_by_id]
    )

    __table_args__ = (
        Index("idx_alert_status_severity", "status", "severity"),
        Index("idx_alert_equip_status", "equipment_id", "status"),
    )

    def __repr__(self) -> str:
        return f"<Alert '{self.title}' [{self.status.value}] count={self.occurrence_count}>"
