"""
IEIP Simulation — Industrial Operational & Fault Scenarios

Defines standard industrial operating conditions and failure modes for testing
and demonstrating the analytics, anomaly detection, and alert engine.
"""

from __future__ import annotations

from typing import Callable
from app.simulation.motor_model import InductionMotorTwin


class SimulationScenario:
    """Encapsulates state mutations applied to the motor digital twin."""

    def __init__(
        self,
        scenario_id: str,
        name: str,
        category: str,
        description: str,
        apply_fn: Callable[[InductionMotorTwin, float], None],
        expected_anomaly: str,
    ) -> None:
        self.scenario_id = scenario_id
        self.name = name
        self.category = category
        self.description = description
        self.apply_fn = apply_fn
        self.expected_anomaly = expected_anomaly


def _apply_normal(motor: InductionMotorTwin, severity: float) -> None:
    motor.is_running = True
    motor.operating_state = "RUNNING"
    motor.load_factor = 0.80
    motor.voltage_unbalance_factors = [1.0, 1.0, 1.0]
    motor.current_unbalance_factors = [1.0, 1.0, 1.0]
    motor.baseline_vibration_mms = 1.4
    motor.extra_vibration_mms = 0.0
    motor.thd_current_pct = 3.2
    motor.thd_voltage_pct = 1.8


def _apply_overcurrent(motor: InductionMotorTwin, severity: float) -> None:
    motor.is_running = True
    motor.operating_state = "OVERLOADED"
    # Overload by 125% * severity factor
    motor.load_factor = min(1.45, 1.25 * severity)
    motor.extra_vibration_mms = 0.8


def _apply_phase_imbalance(motor: InductionMotorTwin, severity: float) -> None:
    motor.is_running = True
    motor.operating_state = "UNBALANCED"
    # Phase L1 draws much higher current due to unequal feeder impedance or loose lug
    delta = 0.18 * severity
    motor.current_unbalance_factors = [1.0 + delta, 1.0 - (delta / 2), 1.0 - (delta / 2)]
    # Slight voltage unbalance induces strong current unbalance
    motor.voltage_unbalance_factors = [1.0 + (delta * 0.2), 1.0 - (delta * 0.1), 1.0 - (delta * 0.1)]


def _apply_low_power_factor(motor: InductionMotorTwin, severity: float) -> None:
    motor.is_running = True
    motor.operating_state = "LIGHT_LOAD"
    # Motor idling at 20% load => very low power factor (0.55 - 0.65)
    motor.load_factor = max(0.15, 0.22 / severity)


def _apply_voltage_sag(motor: InductionMotorTwin, severity: float) -> None:
    motor.is_running = True
    motor.operating_state = "VOLTAGE_SAG"
    # Voltage drops by 18%
    drop = 0.82 / severity
    motor.voltage_unbalance_factors = [drop, drop, drop]


def _apply_voltage_swell(motor: InductionMotorTwin, severity: float) -> None:
    motor.is_running = True
    motor.operating_state = "VOLTAGE_SWELL"
    # Voltage surges by 12%
    surge = 1.12 * severity
    motor.voltage_unbalance_factors = [surge, surge, surge]


def _apply_thermal_runaway(motor: InductionMotorTwin, severity: float) -> None:
    motor.is_running = True
    motor.operating_state = "OVERHEATING"
    motor.current_temperature_c = min(130.0, motor.current_temperature_c + (2.5 * severity))


def _apply_bearing_vibration(motor: InductionMotorTwin, severity: float) -> None:
    motor.is_running = True
    motor.operating_state = "VIBRATION_FAULT"
    # Mechanical defect: ISO 10816-3 critical zone > 4.5 mm/s
    motor.extra_vibration_mms = 4.2 * severity


def _apply_off_hours_consumption(motor: InductionMotorTwin, severity: float) -> None:
    motor.is_running = True
    motor.operating_state = "OFF_HOURS_RUN"
    motor.load_factor = 0.40  # Idling during unstaffed weekend


def _apply_harmonic_distortion(motor: InductionMotorTwin, severity: float) -> None:
    motor.is_running = True
    motor.operating_state = "HARMONIC_DISTORTION"
    motor.thd_current_pct = 15.5 * severity
    motor.thd_voltage_pct = 8.2 * severity


def _apply_unexpected_stop(motor: InductionMotorTwin, severity: float) -> None:
    motor.is_running = False
    motor.operating_state = "TRIPPED"


def _apply_sensor_drift(motor: InductionMotorTwin, severity: float) -> None:
    motor.is_running = True
    motor.operating_state = "SENSOR_DRIFT"
    motor.current_unbalance_factors = [1.25 * severity, 1.0, 1.0]


SCENARIO_CATALOG: dict[str, SimulationScenario] = {
    "NORMAL_OPERATION": SimulationScenario(
        scenario_id="NORMAL_OPERATION",
        name="Operación Nominal Normal",
        category="BASELINE",
        description="Equipo operando a 80% de carga nominal, voltajes balanceados, factor de potencia óptimo.",
        apply_fn=_apply_normal,
        expected_anomaly="NONE",
    ),
    "OVERCURRENT": SimulationScenario(
        scenario_id="OVERCURRENT",
        name="Sobrecarga Mecánica / Sobrecorriente",
        category="ELECTRICAL",
        description="Sobrecarga mecánica en eje provocando corrientes por encima de corriente nominal (FLA).",
        apply_fn=_apply_overcurrent,
        expected_anomaly="OVERCURRENT",
    ),
    "PHASE_IMBALANCE": SimulationScenario(
        scenario_id="PHASE_IMBALANCE",
        name="Desbalance Severo de Fases (NEMA)",
        category="POWER_QUALITY",
        description="Desbalance de corrientes > 10% provocado por conexiones flojas o alimentador desequilibrado.",
        apply_fn=_apply_phase_imbalance,
        expected_anomaly="PHASE_IMBALANCE",
    ),
    "LOW_POWER_FACTOR": SimulationScenario(
        scenario_id="LOW_POWER_FACTOR",
        name="Bajo Factor de Potencia por Baja Carga",
        category="ENERGY_EFFICIENCY",
        description="Operación a baja carga (22%) con factor de potencia penalizable por empresa distribuidora (< 0.70).",
        apply_fn=_apply_low_power_factor,
        expected_anomaly="LOW_POWER_FACTOR",
    ),
    "VOLTAGE_SAG": SimulationScenario(
        scenario_id="VOLTAGE_SAG",
        name="Hueco de Tensión (Voltage Sag)",
        category="POWER_QUALITY",
        description="Caída momentánea de tensión de red al 82% con incremento reactivo de corriente.",
        apply_fn=_apply_voltage_sag,
        expected_anomaly="UNDERVOLTAGE",
    ),
    "VOLTAGE_SWELL": SimulationScenario(
        scenario_id="VOLTAGE_SWELL",
        name="Sobretensión de Red (Voltage Swell)",
        category="POWER_QUALITY",
        description="Elevación sostenida de tensión de barra (+12%) provocando saturación magnética de núcleo.",
        apply_fn=_apply_voltage_swell,
        expected_anomaly="OVERVOLTAGE",
    ),
    "THERMAL_RUNAWAY": SimulationScenario(
        scenario_id="THERMAL_RUNAWAY",
        name="Sobrecarga Térmica / Falla de Enfriamiento",
        category="THERMAL",
        description="Aletas de refrigeración bloqueadas elevando temperatura por encima de límites de aislamiento Clase B.",
        apply_fn=_apply_thermal_runaway,
        expected_anomaly="THERMAL_OVERLOAD",
    ),
    "BEARING_VIBRATION": SimulationScenario(
        scenario_id="BEARING_VIBRATION",
        name="Degradación de Rodamientos / Vibración Excesiva",
        category="MECHANICAL",
        description="Desgaste de pista externa en rodamiento con vibración RMS superior a norma ISO 10816-3 (> 4.5 mm/s).",
        apply_fn=_apply_bearing_vibration,
        expected_anomaly="EXCESSIVE_VIBRATION",
    ),
    "OFF_HOURS_CONSUMPTION": SimulationScenario(
        scenario_id="OFF_HOURS_CONSUMPTION",
        name="Consumo Fantasma Fuera de Turno",
        category="ENERGY_EFFICIENCY",
        description="Equipo operando innecesariamente en horario no productivo / turno nocturno sin carga real.",
        apply_fn=_apply_off_hours_consumption,
        expected_anomaly="OFF_HOURS_CONSUMPTION",
    ),
    "HARMONIC_DISTORTION": SimulationScenario(
        scenario_id="HARMONIC_DISTORTION",
        name="Distorsión Armónica Elevada (THD)",
        category="POWER_QUALITY",
        description="Polución armónica generada por cargas no lineales vecinas (THD-I > 15%, THD-V > 8%).",
        apply_fn=_apply_harmonic_distortion,
        expected_anomaly="HARMONIC_DISTORTION",
    ),
    "UNEXPECTED_STOP": SimulationScenario(
        scenario_id="UNEXPECTED_STOP",
        name="Disparo Intempestivo / Parada No Programada",
        category="OPERATIONAL",
        description="Apertura intempestiva del contactor o disparo de relé térmico durante proceso continuo.",
        apply_fn=_apply_unexpected_stop,
        expected_anomaly="UNEXPECTED_STOP",
    ),
    "SENSOR_DRIFT": SimulationScenario(
        scenario_id="SENSOR_DRIFT",
        name="Descalibración / Deriva de Sensor de Corriente",
        category="INSTRUMENTATION",
        description="Desviación artificial en transformador de corriente fase L1 requiriendo validación metrológica.",
        apply_fn=_apply_sensor_drift,
        expected_anomaly="SENSOR_DRIFT",
    ),
}
