"""
IEIP Backend — Measurement Point Schemas
"""

from __future__ import annotations

import uuid
from datetime import datetime
from pydantic import BaseModel, ConfigDict, Field

from app.models.measurement_point import MeasurementCategory, ProtocolType


class MeasurementPointBase(BaseModel):
    point_code: str = Field(min_length=2, max_length=50)
    name: str = Field(min_length=2, max_length=200)
    category: MeasurementCategory = MeasurementCategory.ELECTRICAL
    protocol: ProtocolType = ProtocolType.SIMULATED
    mqtt_topic: str | None = None
    modbus_slave_id: int | None = None
    modbus_register_address: int | None = None
    sampling_interval_sec: float = Field(default=1.0, gt=0)
    is_active: bool = True
    description: str | None = None


class MeasurementPointCreate(MeasurementPointBase):
    equipment_id: uuid.UUID


class MeasurementPointUpdate(BaseModel):
    name: str | None = None
    category: MeasurementCategory | None = None
    protocol: ProtocolType | None = None
    mqtt_topic: str | None = None
    modbus_slave_id: int | None = None
    modbus_register_address: int | None = None
    sampling_interval_sec: float | None = None
    is_active: bool | None = None
    description: str | None = None


class MeasurementPointResponse(MeasurementPointBase):
    model_config = ConfigDict(from_attributes=True)

    id: uuid.UUID
    equipment_id: uuid.UUID
    created_at: datetime
    updated_at: datetime
