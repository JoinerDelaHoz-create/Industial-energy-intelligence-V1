"""
IEIP Backend — FastAPI Dependencies

Provides database session injection, JWT authentication, and RBAC authorization.
"""

from __future__ import annotations

import uuid
from typing import AsyncGenerator, Callable

from fastapi import Depends, Header, HTTPException, status
from fastapi.security import OAuth2PasswordBearer
from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession

from app.core.database import get_db_session
from app.core.exceptions import AuthenticationError, AuthorizationError, NotFoundError
from app.core.security import decode_token
from app.models.user import User, UserRole

oauth2_scheme = OAuth2PasswordBearer(tokenUrl="/api/v1/auth/login", auto_error=False)


async def get_db() -> AsyncGenerator[AsyncSession, None]:
    """Dependency that yields an asynchronous database session."""
    async for session in get_db_session():
        yield session


async def get_current_user(
    token: str | None = Depends(oauth2_scheme),
    db: AsyncSession = Depends(get_db),
) -> User:
    """Extract and validate the currently authenticated user from Bearer JWT."""
    if not token:
        raise AuthenticationError("Authentication token is missing")

    payload = decode_token(token)
    if not payload or not payload.get("sub"):
        raise AuthenticationError("Invalid or expired authentication token")

    try:
        user_id = uuid.UUID(payload["sub"])
    except (ValueError, TypeError):
        raise AuthenticationError("Invalid subject claim in token")

    stmt = select(User).where(User.id == user_id)
    result = await db.execute(stmt)
    user = result.scalar_one_or_none()

    if not user:
        raise NotFoundError("User account not found")

    if not user.is_active:
        raise AuthenticationError("User account is inactive or disabled")

    return user


async def get_optional_user(
    token: str | None = Depends(oauth2_scheme),
    db: AsyncSession = Depends(get_db),
) -> User | None:
    """Optional user authentication dependency (useful for public/demo endpoints)."""
    if not token:
        return None
    try:
        return await get_current_user(token=token, db=db)
    except HTTPException:
        return None


def require_role(*allowed_roles: UserRole) -> Callable[[User], User]:
    """Dependency factory ensuring the current user possesses one of the allowed roles."""

    def role_checker(current_user: User = Depends(get_current_user)) -> User:
        if current_user.is_superuser:
            return current_user
        if current_user.role not in allowed_roles:
            raise AuthorizationError(
                f"Action requires one of roles: {[r.value for r in allowed_roles]}"
            )
        return current_user

    return role_checker
