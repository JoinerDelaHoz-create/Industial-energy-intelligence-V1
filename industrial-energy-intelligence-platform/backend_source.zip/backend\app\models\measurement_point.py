"""
IEIP Backend — Measurement Point ORM Model

Represents a specific physical or virtual sensor / measurement location
attached to an industrial asset (e.g. main incoming feeder meter, vibration probe,
bearing temperature RTD, current transformer).
"""

from __future__ import annotations

import enum
import uuid
from typing import TYPE_CHECKING

from sqlalchemy import (
    Boolean,
    Enum as SAEnum,
    Float,
    ForeignKey,
    Integer,
    String,
    Text,
)
from sqlalchemy.dialects.postgresql import UUID
from sqlalchemy.orm import Mapped, mapped_column, relationship

from app.core.database import Base
from app.models.mixins import TimestampMixin, UUIDMixin

if TYPE_CHECKING:
    from app.models.equipment import Equipment


class MeasurementCategory(str, enum.Enum):
    """Classification of measurement telemetry."""

    ELECTRICAL = "ELECTRICAL"
    TEMPERATURE = "TEMPERATURE"
    VIBRATION = "VIBRATION"
    PRESSURE = "PRESSURE"
    FLOW = "FLOW"
    OPERATIONAL = "OPERATIONAL"


class ProtocolType(str, enum.Enum):
    """Communication protocol used by the data source."""

    SIMULATED = "SIMULATED"
    MQTT = "MQTT"
    MODBUS_TCP = "MODBUS_TCP"
    MODBUS_RTU = "MODBUS_RTU"
    OPC_UA = "OPC_UA"


class MeasurementPoint(UUIDMixin, TimestampMixin, Base):
    """Sensor or instrument measuring physical variables on an equipment."""

    __tablename__ = "measurement_points"

    equipment_id: Mapped[uuid.UUID] = mapped_column(
        UUID(as_uuid=True),
        ForeignKey("equipment.id", ondelete="CASCADE"),
        nullable=False,
        index=True,
    )
    point_code: Mapped[str] = mapped_column(
        String(50),
        unique=True,
        nullable=False,
        index=True,
        comment="Unique identifier for the channel e.g. MP-MTR305-PWR",
    )
    name: Mapped[str] = mapped_column(
        String(200),
        nullable=False,
        comment="Descriptive name e.g. Motor 305 Power & Current Meter",
    )
    category: Mapped[MeasurementCategory] = mapped_column(
        SAEnum(MeasurementCategory, name="measurement_category_enum"),
        nullable=False,
        default=MeasurementCategory.ELECTRICAL,
    )
    protocol: Mapped[ProtocolType] = mapped_column(
        SAEnum(ProtocolType, name="protocol_type_enum"),
        nullable=False,
        default=ProtocolType.SIMULATED,
    )

    # ── Protocol Configuration ──────────────────────────────────────────────────
    mqtt_topic: Mapped[str | None] = mapped_column(
        String(255),
        nullable=True,
        comment="MQTT topic subscription path, e.g. plant/area1/motor305/telemetry",
    )
    modbus_slave_id: Mapped[int | None] = mapped_column(Integer, nullable=True)
    modbus_register_address: Mapped[int | None] = mapped_column(Integer, nullable=True)

    # ── Engineering Units & Limits ──────────────────────────────────────────────
    sampling_interval_sec: Mapped[float] = mapped_column(
        Float,
        nullable=False,
        default=1.0,
        comment="Expected sampling rate in seconds",
    )
    is_active: Mapped[bool] = mapped_column(
        Boolean,
        nullable=False,
        default=True,
        server_default="true",
    )
    description: Mapped[str | None] = mapped_column(Text, nullable=True)

    # ── Relationship ────────────────────────────────────────────────────────────
    equipment: Mapped["Equipment"] = relationship(
        "Equipment",
        back_populates="measurement_points",
    )

    def __repr__(self) -> str:
        return f"<MeasurementPoint {self.point_code} ({self.category.value})>"
