"""
IEIP Backend — Telemetry Reading ORM Model

Represents time-series measurements stored in TimescaleDB hypertable.
Partitioned on 'time'. Optimized for analytical aggregation and fast range queries.
"""

from __future__ import annotations

import uuid
from datetime import datetime

from sqlalchemy import (
    Boolean,
    DateTime,
    Float,
    ForeignKey,
    Index,
    Integer,
    PrimaryKeyConstraint,
    String,
)
from sqlalchemy.dialects.postgresql import UUID
from sqlalchemy.orm import Mapped, mapped_column

from app.core.database import Base


class TelemetryReading(Base):
    """Time-series sensor reading record.

    TimescaleDB converts this into a hypertable partitioned by time.
    Composite primary key (time, measurement_point_id) guarantees hypertable compatibility.
    """

    __tablename__ = "telemetry_readings"

    # Composite PK required for TimescaleDB hypertable partitioning
    time: Mapped[datetime] = mapped_column(
        DateTime(timezone=True),
        nullable=False,
        primary_key=True,
        index=True,
        comment="Measurement timestamp in UTC",
    )
    measurement_point_id: Mapped[uuid.UUID] = mapped_column(
        UUID(as_uuid=True),
        ForeignKey("measurement_points.id", ondelete="CASCADE"),
        nullable=False,
        primary_key=True,
        index=True,
    )
    equipment_id: Mapped[uuid.UUID] = mapped_column(
        UUID(as_uuid=True),
        ForeignKey("equipment.id", ondelete="CASCADE"),
        nullable=False,
        index=True,
        comment="Denormalised equipment foreign key for ultra-fast asset-level queries",
    )

    # ── Electrical Parameters: Voltages (V) ─────────────────────────────────────
    voltage_l1: Mapped[float | None] = mapped_column(Float, nullable=True)
    voltage_l2: Mapped[float | None] = mapped_column(Float, nullable=True)
    voltage_l3: Mapped[float | None] = mapped_column(Float, nullable=True)
    voltage_avg: Mapped[float | None] = mapped_column(Float, nullable=True)

    # ── Electrical Parameters: Currents (A) ─────────────────────────────────────
    current_l1: Mapped[float | None] = mapped_column(Float, nullable=True)
    current_l2: Mapped[float | None] = mapped_column(Float, nullable=True)
    current_l3: Mapped[float | None] = mapped_column(Float, nullable=True)
    current_avg: Mapped[float | None] = mapped_column(Float, nullable=True)

    # ── Power & Energy ──────────────────────────────────────────────────────────
    active_power_kw: Mapped[float | None] = mapped_column(Float, nullable=True)
    reactive_power_kvar: Mapped[float | None] = mapped_column(Float, nullable=True)
    apparent_power_kva: Mapped[float | None] = mapped_column(Float, nullable=True)
    power_factor: Mapped[float | None] = mapped_column(Float, nullable=True)
    frequency_hz: Mapped[float | None] = mapped_column(Float, nullable=True)
    energy_kwh: Mapped[float | None] = mapped_column(Float, nullable=True)

    # ── Power Quality & Balance ─────────────────────────────────────────────────
    current_unbalance_pct: Mapped[float | None] = mapped_column(Float, nullable=True)
    voltage_unbalance_pct: Mapped[float | None] = mapped_column(Float, nullable=True)
    thd_current_pct: Mapped[float | None] = mapped_column(Float, nullable=True)
    thd_voltage_pct: Mapped[float | None] = mapped_column(Float, nullable=True)

    # ── Operational & Physical Telemetry ────────────────────────────────────────
    temperature_c: Mapped[float | None] = mapped_column(Float, nullable=True)
    vibration_rms_mms: Mapped[float | None] = mapped_column(Float, nullable=True)
    operating_state: Mapped[str | None] = mapped_column(String(30), nullable=True)
    load_pct: Mapped[float | None] = mapped_column(Float, nullable=True)

    # ── Quality & Provenance ────────────────────────────────────────────────────
    is_simulated: Mapped[bool] = mapped_column(
        Boolean,
        nullable=False,
        default=True,
        server_default="true",
        comment="Explicitly tracks if this datapoint was produced by the digital twin",
    )
    quality_code: Mapped[int] = mapped_column(
        Integer,
        nullable=False,
        default=192,
        comment="OPC DA / Industrial quality code (192 = Good, 64 = Uncertain, 0 = Bad)",
    )

    __table_args__ = (
        PrimaryKeyConstraint("time", "measurement_point_id"),
        Index("idx_telemetry_equip_time", "equipment_id", "time"),
    )

    def __repr__(self) -> str:
        return f"<TelemetryReading {self.time} equip={self.equipment_id} P={self.active_power_kw}kW>"
