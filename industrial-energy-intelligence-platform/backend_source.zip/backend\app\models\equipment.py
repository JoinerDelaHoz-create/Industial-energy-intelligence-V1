"""
IEIP Backend — Equipment ORM Model

Represents an industrial asset (motor, pump, compressor, etc.).

IMPORTANT: This model represents DEMONSTRATION EQUIPMENT only.
           All data in the demo database is clearly marked as SIMULATED.
"""

from __future__ import annotations

import enum
import uuid
from datetime import date, datetime

from sqlalchemy import (
    Boolean,
    Date,
    Enum as SAEnum,
    Float,
    Integer,
    String,
    Text,
)
from sqlalchemy.orm import Mapped, mapped_column, relationship

from app.core.database import Base
from app.models.mixins import TimestampMixin, UUIDMixin


class EquipmentType(str, enum.Enum):
    """Industrial equipment categories."""

    MOTOR = "MOTOR"
    PUMP = "PUMP"
    COMPRESSOR = "COMPRESSOR"
    FAN = "FAN"
    CONVEYOR = "CONVEYOR"
    GENERATOR = "GENERATOR"
    OTHER = "OTHER"


class OperatingStatus(str, enum.Enum):
    """Real-time operational status of an equipment."""

    OPERATIONAL = "OPERATIONAL"
    WARNING = "WARNING"
    CRITICAL = "CRITICAL"
    OFFLINE = "OFFLINE"
    MAINTENANCE = "MAINTENANCE"


class Equipment(UUIDMixin, TimestampMixin, Base):
    """Industrial equipment / asset master record.

    Separates master data (this model) from telemetry data
    (TelemetryReading model stored in hypertable).
    """

    __tablename__ = "equipment"

    # ── Identity ────────────────────────────────────────────────────────────────
    asset_code: Mapped[str] = mapped_column(
        String(50), unique=True, nullable=False, index=True,
        comment="Human-readable asset identifier, e.g. MTR-305",
    )
    name: Mapped[str] = mapped_column(
        String(200), nullable=False,
        comment="Descriptive name of the equipment",
    )
    description: Mapped[str | None] = mapped_column(Text, nullable=True)

    # ── Classification ──────────────────────────────────────────────────────────
    equipment_type: Mapped[EquipmentType] = mapped_column(
        SAEnum(EquipmentType, name="equipment_type_enum"),
        nullable=False,
    )

    # ── Manufacturer / Nameplate ────────────────────────────────────────────────
    manufacturer: Mapped[str | None] = mapped_column(String(100), nullable=True)
    model: Mapped[str | None] = mapped_column(String(100), nullable=True)
    serial_number: Mapped[str | None] = mapped_column(
        String(100), nullable=True,
        comment="Never fabricate serial numbers. Use null if unknown.",
    )

    # ── Location ────────────────────────────────────────────────────────────────
    location: Mapped[str] = mapped_column(
        String(200), nullable=False,
        comment="Physical location within the plant",
    )
    site_id: Mapped[str] = mapped_column(
        String(100), nullable=False, index=True,
        comment="Site / plant identifier, e.g. planta-caribe",
    )

    # ── Electrical Nameplate Data ───────────────────────────────────────────────
    rated_power_kw: Mapped[float | None] = mapped_column(
        Float, nullable=True,
        comment="Rated power in kW (nameplate value)",
    )
    rated_voltage: Mapped[float | None] = mapped_column(
        Float, nullable=True,
        comment="Rated voltage in V",
    )
    rated_current: Mapped[float | None] = mapped_column(
        Float, nullable=True,
        comment="Rated current in A (FLA — Full Load Amps)",
    )
    phases: Mapped[int | None] = mapped_column(
        Integer, nullable=True,
        comment="Number of phases: 1 or 3",
    )
    frequency_hz: Mapped[float | None] = mapped_column(
        Float, nullable=True,
        comment="Nominal frequency in Hz",
    )
    nominal_power_factor: Mapped[float | None] = mapped_column(
        Float, nullable=True,
        comment="Nominal power factor (0.0–1.0) from nameplate",
    )

    # ── Status ──────────────────────────────────────────────────────────────────
    operating_status: Mapped[OperatingStatus] = mapped_column(
        SAEnum(OperatingStatus, name="operating_status_enum"),
        nullable=False,
        default=OperatingStatus.OPERATIONAL,
        server_default=OperatingStatus.OPERATIONAL.value,
    )
    is_monitored: Mapped[bool] = mapped_column(
        Boolean, nullable=False, default=True, server_default="true",
    )

    # ── Installation ────────────────────────────────────────────────────────────
    installation_date: Mapped[date | None] = mapped_column(Date, nullable=True)

    # ── Relationships ────────────────────────────────────────────────────────────
    measurement_points: Mapped[list["MeasurementPoint"]] = relationship(  # noqa: F821
        "MeasurementPoint",
        back_populates="equipment",
        cascade="all, delete-orphan",
        lazy="selectin",
    )

    def __repr__(self) -> str:
        return f"<Equipment {self.asset_code} ({self.equipment_type.value})>"
