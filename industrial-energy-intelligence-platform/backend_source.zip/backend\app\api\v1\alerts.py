"""
IEIP API v1 — Alerts Management Endpoints
"""

from __future__ import annotations

import uuid
from datetime import datetime

from fastapi import APIRouter, Depends, Query
from sqlalchemy.ext.asyncio import AsyncSession

from app.dependencies import get_current_user, get_db, get_optional_user
from app.models.alert import AlertStatus
from app.models.anomaly import AnomalySeverity
from app.models.user import User
from app.repositories.alert import AlertRepository
from app.schemas.alert import AlertAcknowledge, AlertResolve, AlertResponse
from app.schemas.common import APIResponse, PaginatedResponse
from app.services.alert import AlertService

router = APIRouter(prefix="/alerts", tags=["Operational Alerts"])


@router.get("", response_model=APIResponse[PaginatedResponse[AlertResponse]])
async def list_alerts(
    equipment_id: uuid.UUID | None = None,
    severity: AnomalySeverity | None = None,
    status: AlertStatus | None = None,
    start_time: datetime | None = None,
    end_time: datetime | None = None,
    page: int = Query(1, ge=1),
    page_size: int = Query(50, ge=1, le=500),
    db: AsyncSession = Depends(get_db),
    _user: User | None = Depends(get_optional_user),
):
    """List operational alerts with repetition counters, audit trail, and pagination."""
    repo = AlertRepository(db)
    skip = (page - 1) * page_size
    items, total = await repo.list_filtered(
        equipment_id=equipment_id,
        severity=severity,
        status=status,
        start_time=start_time,
        end_time=end_time,
        skip=skip,
        limit=page_size,
    )
    total_pages = (total + page_size - 1) // page_size if total > 0 else 0

    return APIResponse(
        data=PaginatedResponse(
            items=[AlertResponse.model_validate(a) for a in items],
            total=total,
            page=page,
            page_size=page_size,
            total_pages=total_pages,
        )
    )


@router.post("/{alert_id}/acknowledge", response_model=APIResponse[AlertResponse])
async def acknowledge_alert(
    alert_id: uuid.UUID,
    payload: AlertAcknowledge,
    db: AsyncSession = Depends(get_db),
    user: User | None = Depends(get_optional_user),
):
    """Acknowledge an alert to indicate operator awareness."""
    service = AlertService(db)
    user_id = user.id if user else None
    alert = await service.acknowledge_alert(alert_id, user_id=user_id, comment=payload.comment)
    return APIResponse(message="Alert acknowledged", data=AlertResponse.model_validate(alert))


@router.post("/{alert_id}/resolve", response_model=APIResponse[AlertResponse])
async def resolve_alert(
    alert_id: uuid.UUID,
    payload: AlertResolve,
    db: AsyncSession = Depends(get_db),
    user: User | None = Depends(get_optional_user),
):
    """Mark an alert as resolved with root cause comments and clear deduplication key."""
    service = AlertService(db)
    user_id = user.id if user else None
    alert = await service.resolve_alert(
        alert_id, user_id=user_id, resolution_comment=payload.resolution_comment
    )
    return APIResponse(message="Alert resolved", data=AlertResponse.model_validate(alert))
