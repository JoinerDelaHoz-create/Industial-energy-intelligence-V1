"""
IEIP Backend — Operational Alert Schemas
"""

from __future__ import annotations

import uuid
from datetime import datetime
from pydantic import BaseModel, ConfigDict, Field

from app.models.alert import AlertStatus
from app.models.anomaly import AnomalySeverity


class AlertBase(BaseModel):
    equipment_id: uuid.UUID
    anomaly_id: uuid.UUID | None = None
    dedup_key: str
    title: str = Field(min_length=3, max_length=200)
    message: str
    severity: AnomalySeverity
    status: AlertStatus = AlertStatus.OPEN
    occurrence_count: int = 1
    first_triggered_at: datetime
    last_triggered_at: datetime


class AlertCreate(AlertBase):
    pass


class AlertAcknowledge(BaseModel):
    comment: str | None = None


class AlertResolve(BaseModel):
    resolution_comment: str = Field(min_length=5, description="Root cause or resolution notes")


class AlertResponse(AlertBase):
    model_config = ConfigDict(from_attributes=True)

    id: uuid.UUID
    acknowledged_at: datetime | None = None
    acknowledged_by_id: uuid.UUID | None = None
    resolved_at: datetime | None = None
    resolved_by_id: uuid.UUID | None = None
    resolution_comment: str | None = None
    created_at: datetime
    updated_at: datetime


class AlertFilter(BaseModel):
    equipment_id: uuid.UUID | None = None
    severity: AnomalySeverity | None = None
    status: AlertStatus | None = None
    start_time: datetime | None = None
    end_time: datetime | None = None
