"""
IEIP API v1 — Plant KPIs Endpoints
"""

from __future__ import annotations

from fastapi import APIRouter, Depends, Query
from sqlalchemy.ext.asyncio import AsyncSession

from app.dependencies import get_db, get_optional_user
from app.models.user import User
from app.schemas.common import APIResponse
from app.schemas.kpi import PlantKPIs
from app.services.kpi import KPIService

router = APIRouter(prefix="/kpis", tags=["KPIs & Energy Balance"])


@router.get("/plant", response_model=APIResponse[PlantKPIs])
async def get_plant_kpis(
    site_id: str = Query("planta-caribe"),
    db: AsyncSession = Depends(get_db),
    _user: User | None = Depends(get_optional_user),
):
    """Retrieve plant-wide overview metrics: total active power, energy costs, and status counts."""
    service = KPIService(db)
    kpis = await service.get_plant_kpis(site_id=site_id)
    return APIResponse(data=kpis)
