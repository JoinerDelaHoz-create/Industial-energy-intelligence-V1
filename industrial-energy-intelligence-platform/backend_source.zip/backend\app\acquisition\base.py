"""
IEIP Acquisition — Data Source Abstraction Interface

Defines the abstract contract for all telemetry acquisition sources:
- Simulator (Digital Twin)
- MQTT Broker (Mosquitto/EMQX)
- Modbus TCP/RTU Bridge
- OPC UA Connector
"""

from __future__ import annotations

import abc
import uuid
from dataclasses import dataclass, field
from datetime import datetime
from typing import Any, AsyncGenerator


@dataclass
class RawTelemetryPayload:
    """Standardized physical measurement frame ingested from any source."""

    source_id: str
    equipment_code: str
    measurement_point_code: str
    timestamp: datetime = field(default_factory=datetime.utcnow)

    # Electrical parameters (Three-phase)
    voltage_l1: float | None = None
    voltage_l2: float | None = None
    voltage_l3: float | None = None
    voltage_avg: float | None = None

    current_l1: float | None = None
    current_l2: float | None = None
    current_l3: float | None = None
    current_avg: float | None = None

    active_power_kw: float | None = None
    reactive_power_kvar: float | None = None
    apparent_power_kva: float | None = None
    power_factor: float | None = None
    frequency_hz: float | None = 60.0
    energy_kwh: float | None = None

    current_unbalance_pct: float | None = None
    voltage_unbalance_pct: float | None = None
    thd_current_pct: float | None = None
    thd_voltage_pct: float | None = None

    # Mechanical & thermal
    temperature_c: float | None = None
    vibration_rms_mms: float | None = None
    operating_state: str = "RUNNING"
    load_pct: float | None = None

    # Quality & Provenance
    is_simulated: bool = False
    quality_code: int = 192
    raw_metadata: dict[str, Any] = field(default_factory=dict)


class BaseDataSource(abc.ABC):
    """Abstract base class that all telemetry sources must implement."""

    def __init__(self, source_name: str) -> None:
        self.source_name = source_name
        self._is_connected: bool = False

    @property
    def is_connected(self) -> bool:
        return self._is_connected

    @abc.abstractmethod
    async def connect(self) -> None:
        """Establish connection to data provider / broker / bus."""
        pass

    @abc.abstractmethod
    async def disconnect(self) -> None:
        """Gracefully close connections."""
        pass

    @abc.abstractmethod
    async def stream(self) -> AsyncGenerator[RawTelemetryPayload, None]:
        """Yield telemetry packets asynchronously as they arrive or are generated."""
        yield  # type: ignore
