"""
IEIP Backend — Anomaly Schemas
"""

from __future__ import annotations

import uuid
from datetime import datetime
from typing import Any
from pydantic import BaseModel, ConfigDict, Field

from app.models.anomaly import AnomalySeverity, AnomalyStatus, AnomalyType


class AnomalyBase(BaseModel):
    equipment_id: uuid.UUID
    measurement_point_id: uuid.UUID | None = None
    detected_at: datetime
    anomaly_type: AnomalyType
    severity: AnomalySeverity
    algorithm_used: str
    metric_name: str
    observed_value: float
    expected_value: float | None = None
    threshold_value: float | None = None
    deviation_pct: float | None = None
    confidence_score: float = Field(ge=0.0, le=1.0, default=1.0)
    description: str
    context_snapshot: dict[str, Any] | None = None


class AnomalyCreate(AnomalyBase):
    pass


class AnomalyUpdate(BaseModel):
    status: AnomalyStatus | None = None
    resolution_notes: str | None = None


class AnomalyResponse(AnomalyBase):
    model_config = ConfigDict(from_attributes=True)

    id: uuid.UUID
    status: AnomalyStatus
    resolved_at: datetime | None = None
    resolution_notes: str | None = None
    created_at: datetime
    updated_at: datetime


class AnomalyFilter(BaseModel):
    equipment_id: uuid.UUID | None = None
    anomaly_type: AnomalyType | None = None
    severity: AnomalySeverity | None = None
    status: AnomalyStatus | None = None
    start_time: datetime | None = None
    end_time: datetime | None = None
