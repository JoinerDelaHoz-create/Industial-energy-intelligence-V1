"""
IEIP Services — Equipment Service

Handles equipment fleet management, live telemetry snapshot attachment,
and asset health summaries.
"""

from __future__ import annotations

import uuid
from typing import Sequence

from sqlalchemy import func, select
from sqlalchemy.ext.asyncio import AsyncSession

from app.models.alert import Alert, AlertStatus
from app.models.anomaly import Anomaly, AnomalyStatus
from app.models.equipment import Equipment, OperatingStatus
from app.models.telemetry import TelemetryReading
from app.repositories.equipment import EquipmentRepository
from app.repositories.telemetry import TelemetryRepository
from app.schemas.equipment import EquipmentSummary


class EquipmentService:
    """Business logic for equipment fleet."""

    def __init__(self, session: AsyncSession) -> None:
        self.session = session
        self.equip_repo = EquipmentRepository(session)
        self.telemetry_repo = TelemetryRepository(session)

    async def get_fleet_summaries(self, site_id: str | None = None) -> list[EquipmentSummary]:
        """Produce fleet cards enriched with real-time variables and active alarm counts."""
        equipments = await self.equip_repo.list_fleet(site_id=site_id)
        summaries: list[EquipmentSummary] = []

        for equip in equipments:
            latest = await self.telemetry_repo.get_latest_by_equipment(equip.id)

            # Count active anomalies
            anom_stmt = select(func.count()).select_from(Anomaly).where(
                Anomaly.equipment_id == equip.id,
                Anomaly.status == AnomalyStatus.DETECTED,
            )
            anom_count = (await self.session.execute(anom_stmt)).scalar() or 0

            # Count open alerts
            alert_stmt = select(func.count()).select_from(Alert).where(
                Alert.equipment_id == equip.id,
                Alert.status.in_([AlertStatus.OPEN, AlertStatus.ACKNOWLEDGED]),
            )
            alert_count = (await self.session.execute(alert_stmt)).scalar() or 0

            summaries.append(
                EquipmentSummary(
                    id=equip.id,
                    asset_code=equip.asset_code,
                    name=equip.name,
                    equipment_type=equip.equipment_type,
                    location=equip.location,
                    site_id=equip.site_id,
                    operating_status=equip.operating_status,
                    is_monitored=equip.is_monitored,
                    rated_power_kw=equip.rated_power_kw,
                    current_active_power_kw=latest.active_power_kw if latest else None,
                    current_power_factor=latest.power_factor if latest else None,
                    current_temperature_c=latest.temperature_c if latest else None,
                    active_anomalies_count=anom_count,
                    active_alerts_count=alert_count,
                )
            )

        return summaries
