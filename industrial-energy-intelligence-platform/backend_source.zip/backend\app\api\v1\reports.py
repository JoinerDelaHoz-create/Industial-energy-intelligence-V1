"""
IEIP API v1 — Reporting & Export Endpoints
"""

from __future__ import annotations

import uuid
from datetime import datetime, timedelta, timezone

from fastapi import APIRouter, Depends, Query
from fastapi.responses import Response
from sqlalchemy.ext.asyncio import AsyncSession

from app.dependencies import get_db, get_optional_user
from app.models.user import User
from app.services.report import ReportService

router = APIRouter(prefix="/reports", tags=["Reports & CSV Export"])


@router.get("/telemetry.csv")
async def export_telemetry_csv(
    equipment_id: uuid.UUID,
    hours: int = Query(24, ge=1, le=720),
    db: AsyncSession = Depends(get_db),
    _user: User | None = Depends(get_optional_user),
):
    """Download telemetry readings in RFC 4180 CSV format."""
    service = ReportService(db)
    now = datetime.now(timezone.utc)
    start = now - timedelta(hours=hours)

    csv_data = await service.generate_telemetry_csv(
        equipment_id=equipment_id,
        start_time=start,
        end_time=now,
    )

    filename = f"telemetry_{equipment_id}_{now.strftime('%Y%m%d_%H%M%S')}.csv"
    return Response(
        content=csv_data,
        media_type="text/csv",
        headers={"Content-Disposition": f'attachment; filename="{filename}"'},
    )


@router.get("/anomalies.csv")
async def export_anomalies_csv(
    equipment_id: uuid.UUID | None = None,
    days: int = Query(7, ge=1, le=90),
    db: AsyncSession = Depends(get_db),
    _user: User | None = Depends(get_optional_user),
):
    """Download anomaly logs and evidence in RFC 4180 CSV format."""
    service = ReportService(db)
    now = datetime.now(timezone.utc)
    start = now - timedelta(days=days)

    csv_data = await service.generate_anomalies_csv(
        equipment_id=equipment_id,
        start_time=start,
        end_time=now,
    )

    filename = f"anomalies_{now.strftime('%Y%m%d_%H%M%S')}.csv"
    return Response(
        content=csv_data,
        media_type="text/csv",
        headers={"Content-Disposition": f'attachment; filename="{filename}"'},
    )
