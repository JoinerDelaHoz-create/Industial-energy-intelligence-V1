"""
IEIP Backend — Application Configuration

All configuration is loaded from environment variables.
See .env.example for documentation of each variable.
"""

from __future__ import annotations

from functools import lru_cache
from typing import Literal

from pydantic import Field, field_validator
from pydantic_settings import BaseSettings, SettingsConfigDict


class Settings(BaseSettings):
    """Centralised application configuration loaded from environment variables."""

    model_config = SettingsConfigDict(
        env_file=".env",
        env_file_encoding="utf-8",
        case_sensitive=False,
        extra="ignore",
    )

    # ── Application ────────────────────────────────────────────────────────────
    app_env: Literal["development", "production", "testing"] = "development"
    app_name: str = "IEIP - Industrial Energy & Intelligence Platform"
    app_version: str = "1.0.0"
    debug: bool = False
    log_level: Literal["DEBUG", "INFO", "WARNING", "ERROR", "CRITICAL"] = "INFO"

    # ── Server ─────────────────────────────────────────────────────────────────
    backend_host: str = "0.0.0.0"
    backend_port: int = 8000
    allowed_origins: list[str] = Field(
        default=["http://localhost:5173", "http://localhost:3000"]
    )

    # ── Database ───────────────────────────────────────────────────────────────
    db_host: str = "db"
    db_port: int = 5432
    db_name: str = "ieip_db"
    db_user: str = "ieip_user"
    db_password: str = Field(..., description="Database password — required")
    database_url: str = Field(
        default="", description="Full async database URL (auto-built if empty)"
    )

    @field_validator("database_url", mode="before")
    @classmethod
    def build_database_url(cls, v: str, info: object) -> str:  # noqa: ANN001
        """Auto-build async database URL from components if not explicitly provided."""
        if v:
            return v
        data = info.data if hasattr(info, "data") else {}
        host = data.get("db_host", "db")
        port = data.get("db_port", 5432)
        name = data.get("db_name", "ieip_db")
        user = data.get("db_user", "ieip_user")
        password = data.get("db_password", "")
        return f"postgresql+asyncpg://{user}:{password}@{host}:{port}/{name}"

    # ── Security / JWT ─────────────────────────────────────────────────────────
    secret_key: str = Field(..., description="JWT signing secret — required")
    algorithm: str = "HS256"
    access_token_expire_minutes: int = 30
    refresh_token_expire_days: int = 7

    # ── MQTT ───────────────────────────────────────────────────────────────────
    mqtt_broker_host: str = "mqtt"
    mqtt_broker_port: int = 1883
    mqtt_client_id: str = "ieip-backend"
    mqtt_username: str = "ieip_mqtt"
    mqtt_password: str = ""
    mqtt_reconnect_delay_seconds: int = 5
    mqtt_max_reconnect_delay_seconds: int = 60

    # ── Simulator ──────────────────────────────────────────────────────────────
    simulator_enabled: bool = True
    simulator_default_interval_seconds: float = 5.0
    simulator_site_id: str = "planta-caribe"

    # ── Energy Cost ────────────────────────────────────────────────────────────
    # DEMO TARIFF — This is a configurable demonstration value.
    # It does NOT represent any real utility rate or tariff.
    energy_cost_per_kwh: float = 0.12
    energy_currency: str = "USD"

    # ── Operating Hours ────────────────────────────────────────────────────────
    operating_hours_start: str = "06:00"
    operating_hours_end: str = "18:00"
    operating_days: list[int] = Field(default=[1, 2, 3, 4, 5])

    # ── CMMS Integration (Phase 6 — future) ────────────────────────────────────
    cmms_api_url: str = "http://localhost:9000/api"
    cmms_api_key: str = ""
    cmms_integration_enabled: bool = False

    @property
    def is_development(self) -> bool:
        """Return True when running in development mode."""
        return self.app_env == "development"

    @property
    def is_production(self) -> bool:
        """Return True when running in production mode."""
        return self.app_env == "production"


@lru_cache
def get_settings() -> Settings:
    """Return cached Settings instance.

    Using @lru_cache ensures settings are loaded once and reused across
    the application, avoiding repeated .env file reads.
    """
    return Settings()  # type: ignore[call-arg]


# Module-level singleton for convenience imports
settings = get_settings()
