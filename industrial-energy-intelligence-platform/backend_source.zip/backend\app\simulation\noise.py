"""
IEIP Simulation — Industrial Sensor Noise Model

Real industrial electrical and vibration signals do not exhibit pure white Gaussian noise.
They exhibit colored, autoregressive AR(1) temporal correlations caused by grid inertia,
mechanical resonance, and ambient thermal drift.
"""

from __future__ import annotations

import math
import random


class IndustrialNoiseGenerator:
    """Generates realistic correlated noise using an Autoregressive AR(1) process."""

    def __init__(
        self,
        mean: float = 0.0,
        std_dev: float = 1.0,
        phi: float = 0.75,
        min_clip: float | None = None,
        max_clip: float | None = None,
    ) -> None:
        """
        Args:
            mean: Target long-term mean.
            std_dev: Standard deviation of the noise process.
            phi: Autoregressive coefficient (0 = white noise, 0.9 = strongly correlated drift).
            min_clip: Optional lower hard clamp.
            max_clip: Optional upper hard clamp.
        """
        self.mean = mean
        self.std_dev = std_dev
        self.phi = phi
        self.min_clip = min_clip
        self.max_clip = max_clip
        self._current_val = mean

    def next_value(self) -> float:
        """Step the AR(1) sequence and return next sampled value."""
        # AR(1) equation: X[t] = mean + phi * (X[t-1] - mean) + epsilon * sqrt(1 - phi^2)
        white_noise = random.gauss(0, self.std_dev)
        innovation = white_noise * math.sqrt(max(0.001, 1.0 - self.phi**2))
        self._current_val = self.mean + self.phi * (self._current_val - self.mean) + innovation

        if self.min_clip is not None:
            self._current_val = max(self.min_clip, self._current_val)
        if self.max_clip is not None:
            self._current_val = min(self.max_clip, self._current_val)

        return self._current_val
