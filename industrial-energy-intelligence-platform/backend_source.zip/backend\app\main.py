"""
IEIP Backend — Main FastAPI Application & Lifespan Orchestrator

Industrial Energy & Intelligence Platform (IEIP)
"""

from __future__ import annotations

import asyncio
from contextlib import asynccontextmanager
from pathlib import Path
from typing import AsyncGenerator

from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import FileResponse
from fastapi.staticfiles import StaticFiles
from starlette.middleware.base import BaseHTTPMiddleware

from app.acquisition.base import RawTelemetryPayload
from app.acquisition.manager import AcquisitionManager
from app.api.v1.api_router import api_router
from app.config import get_settings
from app.core.database import create_all_tables, dispose_engine
from app.core.exceptions import register_exception_handlers
from app.core.logging import get_logger, setup_logging
from app.core.middleware import RequestLoggingMiddleware
from app.telemetry.ingestion import IngestionPipelineService

settings = get_settings()
setup_logging(log_level=settings.LOG_LEVEL, json_logs=settings.LOG_JSON_FORMAT)
logger = get_logger("ieip.main")


@asynccontextmanager
async def lifespan(app: FastAPI) -> AsyncGenerator[None, None]:
    """Application lifespan managing database tables, background acquisition, and cleanup."""
    logger.info("Starting IEIP Backend Application...", version=settings.PROJECT_VERSION)

    # 1. Initialize DB schema (creates tables if not using migrations)
    try:
        await create_all_tables()
        logger.info("Database schema validated")
    except Exception as err:
        logger.warning(f"Could not connect to database on startup ({err}). Will retry in background.")

    # 2. Wire Acquisition Manager to Ingestion Pipeline
    ingestion_service = IngestionPipelineService.get_instance()
    acquisition_mgr = AcquisitionManager.get_instance()

    async def _on_raw_payload(payload: RawTelemetryPayload) -> None:
        await ingestion_service.ingest_payload(payload)

    acquisition_mgr.add_listener(_on_raw_payload)

    # 3. Start Acquisition Manager (launches digital twin simulation & MQTT subscribers)
    try:
        await acquisition_mgr.start()
        logger.info("Acquisition manager background loop activated")
    except Exception as err:
        logger.error(f"Failed to start acquisition manager: {err}")

    yield

    # 4. Graceful Shutdown
    logger.info("Shutting down IEIP Backend Application...")
    await acquisition_mgr.stop()
    await dispose_engine()
    logger.info("IEIP Backend shutdown complete")


def create_app() -> FastAPI:
    """FastAPI application factory."""
    app = FastAPI(
        title=settings.PROJECT_NAME,
        version=settings.PROJECT_VERSION,
        description="Industrial Energy & Intelligence Platform — IoT Telemetry, Anomaly Detection & Asset Health",
        lifespan=lifespan,
        docs_url="/docs",
        redoc_url="/redoc",
        openapi_url="/openapi.json",
    )

    # Middlewares
    app.add_middleware(
        CORSMiddleware,
        allow_origins=settings.CORS_ORIGINS,
        allow_credentials=True,
        allow_methods=["*"],
        allow_headers=["*"],
    )
    app.add_middleware(RequestLoggingMiddleware)

    # Exception Handlers
    register_exception_handlers(app)

    # API Routers
    app.include_router(api_router, prefix=settings.API_V1_PREFIX)

    # Static UI Files Mounting
    static_dir = Path(__file__).resolve().parent / "static"
    if static_dir.exists():
        app.mount("/static", StaticFiles(directory=str(static_dir)), name="static")

    # Health & Meta endpoints
    @app.get("/health", tags=["Health"])
    async def health_check():
        return {
            "status": "healthy",
            "service": settings.PROJECT_NAME,
            "version": settings.PROJECT_VERSION,
            "environment": settings.ENVIRONMENT,
        }

    @app.get("/", tags=["UI"])
    async def root():
        index_file = static_dir / "index.html"
        if index_file.exists():
            return FileResponse(str(index_file))
        return {
            "message": "IEIP — Industrial Energy & Intelligence Platform API",
            "version": settings.PROJECT_VERSION,
            "docs": "/docs",
            "api_v1": settings.API_V1_PREFIX,
        }

    return app


app = create_app()
