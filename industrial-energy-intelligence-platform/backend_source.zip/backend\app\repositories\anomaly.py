"""
IEIP Repositories — Anomaly Repository
"""

from __future__ import annotations

import uuid
from datetime import datetime
from typing import Sequence

from sqlalchemy import desc, func, select
from sqlalchemy.ext.asyncio import AsyncSession

from app.models.anomaly import Anomaly, AnomalySeverity, AnomalyStatus, AnomalyType
from app.repositories.base import BaseRepository


class AnomalyRepository(BaseRepository[Anomaly]):
    """Repository managing detected industrial anomalies."""

    def __init__(self, session: AsyncSession) -> None:
        super().__init__(Anomaly, session)

    async def list_filtered(
        self,
        equipment_id: uuid.UUID | None = None,
        anomaly_type: AnomalyType | None = None,
        severity: AnomalySeverity | None = None,
        status: AnomalyStatus | None = None,
        start_time: datetime | None = None,
        end_time: datetime | None = None,
        skip: int = 0,
        limit: int = 50,
    ) -> tuple[Sequence[Anomaly], int]:
        stmt = select(Anomaly)
        count_stmt = select(func.count()).select_from(Anomaly)

        if equipment_id:
            stmt = stmt.where(Anomaly.equipment_id == equipment_id)
            count_stmt = count_stmt.where(Anomaly.equipment_id == equipment_id)
        if anomaly_type:
            stmt = stmt.where(Anomaly.anomaly_type == anomaly_type)
            count_stmt = count_stmt.where(Anomaly.anomaly_type == anomaly_type)
        if severity:
            stmt = stmt.where(Anomaly.severity == severity)
            count_stmt = count_stmt.where(Anomaly.severity == severity)
        if status:
            stmt = stmt.where(Anomaly.status == status)
            count_stmt = count_stmt.where(Anomaly.status == status)
        if start_time:
            stmt = stmt.where(Anomaly.detected_at >= start_time)
            count_stmt = count_stmt.where(Anomaly.detected_at >= start_time)
        if end_time:
            stmt = stmt.where(Anomaly.detected_at <= end_time)
            count_stmt = count_stmt.where(Anomaly.detected_at <= end_time)

        stmt = stmt.order_by(desc(Anomaly.detected_at)).offset(skip).limit(limit)

        total_res = await self.session.execute(count_stmt)
        total = total_res.scalar() or 0

        res = await self.session.execute(stmt)
        return res.scalars().all(), total
