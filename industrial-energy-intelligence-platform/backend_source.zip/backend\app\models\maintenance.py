"""
IEIP Backend — Maintenance Recommendation ORM Model

Represents automated, condition-based maintenance recommendations generated
from technical degradation patterns (e.g. chronic phase unbalance, low PF penalties,
bearing friction signatures), linking telemetry anomalies with physical engineering actions.
"""

from __future__ import annotations

import enum
import uuid
from datetime import datetime
from typing import TYPE_CHECKING

from sqlalchemy import (
    DateTime,
    Enum as SAEnum,
    Float,
    ForeignKey,
    Index,
    String,
    Text,
)
from sqlalchemy.dialects.postgresql import UUID
from sqlalchemy.orm import Mapped, mapped_column, relationship

from app.core.database import Base
from app.models.mixins import TimestampMixin, UUIDMixin

if TYPE_CHECKING:
    from app.models.anomaly import Anomaly
    from app.models.equipment import Equipment
    from app.models.user import User


class RecommendationPriority(str, enum.Enum):
    """Urgency of recommended engineering action."""

    LOW = "LOW"
    MEDIUM = "MEDIUM"
    HIGH = "HIGH"
    IMMEDIATE = "IMMEDIATE"


class RecommendationStatus(str, enum.Enum):
    """Lifecycle status of a maintenance recommendation."""

    PENDING = "PENDING"
    IN_PROGRESS = "IN_PROGRESS"
    IMPLEMENTED = "IMPLEMENTED"
    DISMISSED = "DISMISSED"


class MaintenanceRecommendation(UUIDMixin, TimestampMixin, Base):
    """Technical maintenance action proposed by intelligence rules."""

    __tablename__ = "maintenance_recommendations"

    equipment_id: Mapped[uuid.UUID] = mapped_column(
        UUID(as_uuid=True),
        ForeignKey("equipment.id", ondelete="CASCADE"),
        nullable=False,
        index=True,
    )
    anomaly_id: Mapped[uuid.UUID | None] = mapped_column(
        UUID(as_uuid=True),
        ForeignKey("anomalies.id", ondelete="SET NULL"),
        nullable=True,
        index=True,
    )

    title: Mapped[str] = mapped_column(
        String(200),
        nullable=False,
        comment="e.g. Inspect Motor L2 Contactor Contacts & Stator Windings",
    )
    technical_rationale: Mapped[str] = mapped_column(
        Text,
        nullable=False,
        comment="Physical and electrical explanation of the detected failure mode",
    )
    suggested_actions: Mapped[str] = mapped_column(
        Text,
        nullable=False,
        comment="Step-by-step guidance for electrical / mechanical technicians",
    )
    priority: Mapped[RecommendationPriority] = mapped_column(
        SAEnum(RecommendationPriority, name="rec_priority_enum"),
        nullable=False,
        default=RecommendationPriority.MEDIUM,
    )
    status: Mapped[RecommendationStatus] = mapped_column(
        SAEnum(RecommendationStatus, name="rec_status_enum"),
        nullable=False,
        default=RecommendationStatus.PENDING,
        index=True,
    )

    # ── Financial / Energy Impact Estimates ────────────────────────────────────
    estimated_monthly_kwh_waste: Mapped[float | None] = mapped_column(
        Float,
        nullable=True,
        comment="Estimated wasted energy in kWh per month if unresolved",
    )
    estimated_monthly_cost_usd: Mapped[float | None] = mapped_column(
        Float,
        nullable=True,
        comment="Estimated financial loss per month at industrial tariff",
    )

    # ── Implementation Audit ───────────────────────────────────────────────────
    implemented_at: Mapped[datetime | None] = mapped_column(
        DateTime(timezone=True),
        nullable=True,
    )
    implemented_by_id: Mapped[uuid.UUID | None] = mapped_column(
        UUID(as_uuid=True),
        ForeignKey("users.id", ondelete="SET NULL"),
        nullable=True,
    )

    # ── Relationships ──────────────────────────────────────────────────────────
    equipment: Mapped["Equipment"] = relationship("Equipment")
    anomaly: Mapped["Anomaly | None"] = relationship("Anomaly")
    implemented_by: Mapped["User | None"] = relationship(
        "User", foreign_keys=[implemented_by_id]
    )

    __table_args__ = (
        Index("idx_rec_equip_status", "equipment_id", "status"),
    )

    def __repr__(self) -> str:
        return f"<MaintenanceRecommendation '{self.title}' [{self.status.value}]>"
