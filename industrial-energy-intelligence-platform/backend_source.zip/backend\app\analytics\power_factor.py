"""
IEIP Analytics — Power Factor & Reactive Penalty Analyzer

Detects poor power factor and calculates reactive compensation requirements (kVAR)
to avoid utility tariff surcharges and line losses.
"""

from __future__ import annotations

import math
from typing import Any
from app.analytics.threshold import AnomalyCandidate
from app.models.anomaly import AnomalySeverity, AnomalyType


class PowerFactorDetector:
    """Detects low power factor and computes optimal capacitor bank sizing."""

    def __init__(self, target_pf: float = 0.95, penalty_threshold: float = 0.85) -> None:
        self.target_pf = target_pf
        self.penalty_threshold = penalty_threshold

    def evaluate(self, telemetry: dict[str, Any], equipment_specs: dict[str, Any]) -> list[AnomalyCandidate]:
        candidates: list[AnomalyCandidate] = []

        pf = telemetry.get("power_factor")
        active_kw = telemetry.get("active_power_kw") or 0.0

        # Only evaluate while equipment is drawing meaningful load (> 5% of rated power or > 3 kW)
        if pf is None or active_kw < 3.0:
            return candidates

        if pf < self.penalty_threshold:
            # Sizing required shunt capacitor bank:
            # Q_c = P * (tan(phi_1) - tan(phi_2))
            phi_actual = math.acos(max(0.1, min(1.0, pf)))
            phi_target = math.acos(self.target_pf)
            q_compensation_kvar = max(0.0, active_kw * (math.tan(phi_actual) - math.tan(phi_target)))

            sev = AnomalySeverity.HIGH if pf < 0.72 else AnomalySeverity.MEDIUM
            dev = ((self.penalty_threshold - pf) / self.penalty_threshold) * 100.0

            candidates.append(
                AnomalyCandidate(
                    anomaly_type=AnomalyType.LOW_POWER_FACTOR,
                    severity=sev,
                    algorithm="POWER_FACTOR_PENALTY_EVAL",
                    metric_name="power_factor",
                    observed_value=round(pf, 3),
                    expected_value=self.target_pf,
                    threshold_value=self.penalty_threshold,
                    deviation_pct=round(-dev, 1),
                    confidence_score=0.97,
                    description=(
                        f"Factor de potencia deficiente ({pf:.2f} < {self.penalty_threshold}). "
                        f"Se requiere compensación reactiva de aproximadamente {q_compensation_kvar:.1f} kVAR "
                        f"para elevar el FP al objetivo ({self.target_pf})."
                    ),
                    context={
                        "active_power_kw": active_kw,
                        "reactive_power_kvar": telemetry.get("reactive_power_kvar"),
                        "apparent_power_kva": telemetry.get("apparent_power_kva"),
                        "recommended_compensation_kvar": round(q_compensation_kvar, 1),
                    },
                )
            )

        return candidates
