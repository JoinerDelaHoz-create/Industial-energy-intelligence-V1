"""
IEIP Repositories — Operational Event Repository
"""

from __future__ import annotations

import uuid
from datetime import datetime
from typing import Sequence

from sqlalchemy import desc, func, select
from sqlalchemy.ext.asyncio import AsyncSession

from app.models.event import EventCategory, OperationalEvent
from app.repositories.base import BaseRepository


class EventRepository(BaseRepository[OperationalEvent]):
    """Historian event log repository."""

    def __init__(self, session: AsyncSession) -> None:
        super().__init__(OperationalEvent, session)

    async def list_filtered(
        self,
        equipment_id: uuid.UUID | None = None,
        category: EventCategory | None = None,
        source: str | None = None,
        start_time: datetime | None = None,
        end_time: datetime | None = None,
        skip: int = 0,
        limit: int = 50,
    ) -> tuple[Sequence[OperationalEvent], int]:
        stmt = select(OperationalEvent)
        count_stmt = select(func.count()).select_from(OperationalEvent)

        if equipment_id:
            stmt = stmt.where(OperationalEvent.equipment_id == equipment_id)
            count_stmt = count_stmt.where(OperationalEvent.equipment_id == equipment_id)
        if category:
            stmt = stmt.where(OperationalEvent.category == category)
            count_stmt = count_stmt.where(OperationalEvent.category == category)
        if source:
            stmt = stmt.where(OperationalEvent.source == source)
            count_stmt = count_stmt.where(OperationalEvent.source == source)
        if start_time:
            stmt = stmt.where(OperationalEvent.event_time >= start_time)
            count_stmt = count_stmt.where(OperationalEvent.event_time >= start_time)
        if end_time:
            stmt = stmt.where(OperationalEvent.event_time <= end_time)
            count_stmt = count_stmt.where(OperationalEvent.event_time <= end_time)

        stmt = stmt.order_by(desc(OperationalEvent.event_time)).offset(skip).limit(limit)

        total_res = await self.session.execute(count_stmt)
        total = total_res.scalar() or 0

        res = await self.session.execute(stmt)
        return res.scalars().all(), total
