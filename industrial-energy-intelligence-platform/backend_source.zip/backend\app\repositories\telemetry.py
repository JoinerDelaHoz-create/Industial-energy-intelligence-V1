"""
IEIP Repositories — Telemetry & Time-Series Repository

Interfaces with TimescaleDB hypertable for time-series readings, time-bucket aggregates,
and real-time instrument snapshots.
"""

from __future__ import annotations

import uuid
from datetime import datetime
from typing import Sequence

from sqlalchemy import desc, func, select, text
from sqlalchemy.ext.asyncio import AsyncSession

from app.models.telemetry import TelemetryReading
from app.schemas.telemetry import AggregationBucket, RealTimeSnapshot


class TelemetryRepository:
    """Specialized repository for hypertable telemetry queries."""

    def __init__(self, session: AsyncSession) -> None:
        self.session = session

    async def get_latest_by_equipment(self, equipment_id: uuid.UUID) -> TelemetryReading | None:
        """Fetch the most recent reading frame for an asset."""
        stmt = (
            select(TelemetryReading)
            .where(TelemetryReading.equipment_id == equipment_id)
            .order_by(desc(TelemetryReading.time))
            .limit(1)
        )
        res = await self.session.execute(stmt)
        return res.scalar_one_or_none()

    async def get_time_series(
        self,
        equipment_id: uuid.UUID,
        start_time: datetime,
        end_time: datetime,
        limit: int = 1000,
    ) -> Sequence[TelemetryReading]:
        """Fetch raw readings within a time window."""
        stmt = (
            select(TelemetryReading)
            .where(
                TelemetryReading.equipment_id == equipment_id,
                TelemetryReading.time >= start_time,
                TelemetryReading.time <= end_time,
            )
            .order_by(TelemetryReading.time.asc())
            .limit(limit)
        )
        res = await self.session.execute(stmt)
        return res.scalars().all()

    async def get_aggregated_buckets(
        self,
        equipment_id: uuid.UUID,
        bucket_interval: str = "5 minutes",
        start_time: datetime | None = None,
        end_time: datetime | None = None,
    ) -> list[dict]:
        """TimescaleDB time_bucket query for analytical charts."""
        # TimescaleDB time_bucket SQL
        query_sql = f"""
            SELECT
                time_bucket(INTERVAL '{bucket_interval}', time) AS bucket,
                AVG(active_power_kw) AS avg_power_kw,
                MAX(active_power_kw) AS max_power_kw,
                MIN(active_power_kw) AS min_power_kw,
                AVG(power_factor) AS avg_power_factor,
                AVG(current_avg) AS avg_current,
                MAX(current_avg) AS max_current,
                AVG(temperature_c) AS avg_temperature,
                MAX(vibration_rms_mms) AS max_vibration,
                MAX(current_unbalance_pct) AS unbalance_max_pct
            FROM telemetry_readings
            WHERE equipment_id = :equipment_id
              AND (:start_time IS NULL OR time >= :start_time)
              AND (:end_time IS NULL OR time <= :end_time)
            GROUP BY bucket
            ORDER BY bucket ASC;
        """
        try:
            res = await self.session.execute(
                text(query_sql),
                {
                    "equipment_id": str(equipment_id),
                    "start_time": start_time,
                    "end_time": end_time,
                },
            )
            rows = res.mappings().all()
            return [dict(r) for r in rows]
        except Exception:
            # Fallback for standard PostgreSQL / SQLite without TimescaleDB extension
            fallback_sql = """
                SELECT
                    time AS bucket,
                    active_power_kw AS avg_power_kw,
                    active_power_kw AS max_power_kw,
                    active_power_kw AS min_power_kw,
                    power_factor AS avg_power_factor,
                    current_avg AS avg_current,
                    current_avg AS max_current,
                    temperature_c AS avg_temperature,
                    vibration_rms_mms AS max_vibration,
                    current_unbalance_pct AS unbalance_max_pct
                FROM telemetry_readings
                WHERE equipment_id = :equipment_id
                ORDER BY time DESC
                LIMIT 50;
            """
            res = await self.session.execute(text(fallback_sql), {"equipment_id": str(equipment_id)})
            return [dict(r) for r in res.mappings().all()]
