"""
IEIP Acquisition — Simulator Data Source

Bridges the internal InductionMotorTwin physics simulation runner to the
standardized BaseDataSource interface.
"""

from __future__ import annotations

import asyncio
from typing import AsyncGenerator

from app.acquisition.base import BaseDataSource, RawTelemetryPayload
from app.simulation.runner import SimulationRunner


class SimulatorDataSource(BaseDataSource):
    """Acquisition source reading from the digital twin simulation engine."""

    def __init__(self, source_name: str = "DigitalTwinSimulator") -> None:
        super().__init__(source_name=source_name)
        self.runner = SimulationRunner.get_instance()
        self._queue: asyncio.Queue[RawTelemetryPayload] = asyncio.Queue(maxsize=1000)

    async def connect(self) -> None:
        """Subscribe to the runner and ensure the background simulation is started."""
        self.runner.subscribe(self._on_sim_sample)
        if not self.runner.is_running:
            await self.runner.start()
        self._is_connected = True

    async def disconnect(self) -> None:
        """Unsubscribe from the runner."""
        self.runner.unsubscribe(self._on_sim_sample)
        self._is_connected = False

    async def _on_sim_sample(self, sample: dict) -> None:
        """Map simulation output dictionary to standard RawTelemetryPayload."""
        payload = RawTelemetryPayload(
            source_id="SIMULATOR",
            equipment_code=sample["asset_code"],
            measurement_point_code=f"MP-{sample['asset_code']}-MAIN",
            timestamp=sample["timestamp"],
            voltage_l1=sample.get("voltage_l1"),
            voltage_l2=sample.get("voltage_l2"),
            voltage_l3=sample.get("voltage_l3"),
            voltage_avg=sample.get("voltage_avg"),
            current_l1=sample.get("current_l1"),
            current_l2=sample.get("current_l2"),
            current_l3=sample.get("current_l3"),
            current_avg=sample.get("current_avg"),
            active_power_kw=sample.get("active_power_kw"),
            reactive_power_kvar=sample.get("reactive_power_kvar"),
            apparent_power_kva=sample.get("apparent_power_kva"),
            power_factor=sample.get("power_factor"),
            frequency_hz=sample.get("frequency_hz"),
            energy_kwh=sample.get("energy_kwh"),
            current_unbalance_pct=sample.get("current_unbalance_pct"),
            voltage_unbalance_pct=sample.get("voltage_unbalance_pct"),
            thd_current_pct=sample.get("thd_current_pct"),
            thd_voltage_pct=sample.get("thd_voltage_pct"),
            temperature_c=sample.get("temperature_c"),
            vibration_rms_mms=sample.get("vibration_rms_mms"),
            operating_state=sample.get("operating_state", "RUNNING"),
            load_pct=sample.get("load_pct"),
            is_simulated=True,
            quality_code=192,
        )
        if not self._queue.full():
            await self._queue.put(payload)

    async def stream(self) -> AsyncGenerator[RawTelemetryPayload, None]:
        """Asynchronously stream ingested payloads."""
        while self._is_connected:
            try:
                payload = await asyncio.wait_for(self._queue.get(), timeout=2.0)
                yield payload
                self._queue.task_done()
            except asyncio.TimeoutError:
                continue
