"""
IEIP Analytics — Statistical Rolling Window Z-Score Anomaly Detector

Maintains an online rolling window (Welford's algorithm / deque buffer) per equipment metric
to detect sudden statistical drift, transient spikes, or anomalous variance without static thresholds.
"""

from __future__ import annotations

import collections
import math
from typing import Any
from app.analytics.threshold import AnomalyCandidate
from app.models.anomaly import AnomalySeverity, AnomalyType


class RollingZScoreDetector:
    """Detects statistical outliers (|Z| > threshold) on dynamic signals."""

    def __init__(self, window_size: int = 60, z_threshold: float = 3.0) -> None:
        self.window_size = window_size
        self.z_threshold = z_threshold
        # Buffer keyed by (asset_code, metric_name) -> collections.deque
        self._buffers: dict[tuple[str, str], collections.deque[float]] = {}

    def evaluate(self, telemetry: dict[str, Any], equipment_specs: dict[str, Any]) -> list[AnomalyCandidate]:
        candidates: list[AnomalyCandidate] = []
        asset_code = equipment_specs.get("asset_code", "GENERIC")

        # Metrics to analyze dynamically
        tracked_metrics = ["active_power_kw", "temperature_c", "vibration_rms_mms"]

        for metric in tracked_metrics:
            val = telemetry.get(metric)
            if val is None or not isinstance(val, (int, float)):
                continue

            key = (asset_code, metric)
            if key not in self._buffers:
                self._buffers[key] = collections.deque(maxlen=self.window_size)

            buffer = self._buffers[key]

            # Require minimum warm-up samples to establish statistical confidence
            if len(buffer) >= 20:
                mean = sum(buffer) / len(buffer)
                variance = sum((x - mean) ** 2 for x in buffer) / (len(buffer) - 1)
                std_dev = math.sqrt(variance)

                # Avoid division by zero on flatlined signals
                if std_dev > 0.05:
                    z_score = (val - mean) / std_dev

                    if abs(z_score) >= self.z_threshold:
                        # Determine mapped anomaly type
                        anomaly_type = AnomalyType.OVERCURRENT
                        if metric == "temperature_c":
                            anomaly_type = AnomalyType.THERMAL_OVERLOAD
                        elif metric == "vibration_rms_mms":
                            anomaly_type = AnomalyType.EXCESSIVE_VIBRATION

                        sev = AnomalySeverity.HIGH if abs(z_score) >= 4.5 else AnomalySeverity.MEDIUM
                        confidence = min(0.99, round(0.70 + (abs(z_score) / 15.0), 2))

                        candidates.append(
                            AnomalyCandidate(
                                anomaly_type=anomaly_type,
                                severity=sev,
                                algorithm="STATISTICAL_ROLLING_ZSCORE",
                                metric_name=metric,
                                observed_value=round(val, 2),
                                expected_value=round(mean, 2),
                                threshold_value=round(mean + self.z_threshold * std_dev, 2),
                                deviation_pct=round(((val - mean) / mean * 100.0) if mean != 0 else 0.0, 1),
                                confidence_score=confidence,
                                description=(
                                    f"Desviación estadística anómala en {metric} (Z={z_score:.2f}σ). "
                                    f"Valor observado {val:.2f} vs media histórica móvil {mean:.2f} (σ={std_dev:.2f})."
                                ),
                                context={"z_score": round(z_score, 2), "sample_mean": round(mean, 2), "sample_std": round(std_dev, 2)},
                            )
                        )

            # Update rolling window buffer
            buffer.append(float(val))

        return candidates
