"""
IEIP Alerts — Deduplication Engine & Alarm Flood Suppression

Implements industrial alarm management best practices (ISA 18.2):
Suppresses repeating alarms within a sliding cooldown window, grouping occurrences
and tracking repetition counts rather than overwhelming operators with duplicate notifications.
"""

from __future__ import annotations

import time
import uuid
from dataclasses import dataclass
from typing import Optional


@dataclass
class ActiveAlertRecord:
    alert_id: uuid.UUID
    first_seen: float
    last_seen: float
    occurrence_count: int


class AlertDeduplicator:
    """Cooldown-based alert deduplication cache."""

    def __init__(self, cooldown_seconds: float = 60.0) -> None:
        self.cooldown_seconds = cooldown_seconds
        # dedup_key -> ActiveAlertRecord
        self._cache: dict[str, ActiveAlertRecord] = {}

    def get_dedup_key(self, equipment_id: uuid.UUID | str, anomaly_type: str) -> str:
        """Create a deterministic unique key for the equipment and failure mode."""
        return f"{equipment_id}:{anomaly_type}"

    def should_suppress(self, dedup_key: str) -> tuple[bool, Optional[ActiveAlertRecord]]:
        """Check if an alert should be suppressed or merged into an existing active alert."""
        now = time.monotonic()
        if dedup_key in self._cache:
            record = self._cache[dedup_key]
            if (now - record.last_seen) < self.cooldown_seconds:
                # Still within suppression/cooldown window -> merge and suppress new DB insert
                record.last_seen = now
                record.occurrence_count += 1
                return True, record
            else:
                # Window expired -> evict stale entry
                del self._cache[dedup_key]

        return False, None

    def register_alert(self, dedup_key: str, alert_id: uuid.UUID) -> None:
        """Store newly created alert in deduplication window."""
        now = time.monotonic()
        self._cache[dedup_key] = ActiveAlertRecord(
            alert_id=alert_id,
            first_seen=now,
            last_seen=now,
            occurrence_count=1,
        )

    def clear_key(self, dedup_key: str) -> None:
        """Evict key when alert is explicitly resolved by operator."""
        if dedup_key in self._cache:
            del self._cache[dedup_key]
