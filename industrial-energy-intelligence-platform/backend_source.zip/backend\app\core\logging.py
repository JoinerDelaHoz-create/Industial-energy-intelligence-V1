"""
IEIP Backend — Structured Logging

Uses Python's standard logging module with structlog-style output.
In development: human-readable colored output.
In production: JSON structured output (machine-parseable).

SECURITY: Never log passwords, tokens, or secrets.
"""

from __future__ import annotations

import logging
import sys
from typing import Any

from app.config import settings


class _StructuredFormatter(logging.Formatter):
    """Simple structured log formatter.

    Development: '[LEVEL] module | message | key=value ...'
    Production:  JSON line per record
    """

    def format(self, record: logging.LogRecord) -> str:
        level = record.levelname
        name = record.name.split(".")[-1]  # Short module name
        message = record.getMessage()

        # Collect extra structured fields
        extras: dict[str, Any] = {}
        for key, value in record.__dict__.items():
            if key not in {
                "name", "msg", "args", "levelname", "levelno", "pathname",
                "filename", "module", "exc_info", "exc_text", "stack_info",
                "lineno", "funcName", "created", "msecs", "relativeCreated",
                "thread", "threadName", "processName", "process", "message",
                "taskName",
            }:
                extras[key] = value

        extra_str = " | ".join(f"{k}={v}" for k, v in extras.items()) if extras else ""
        context = f" | {extra_str}" if extra_str else ""

        if settings.is_production:
            import json
            import time
            return json.dumps({
                "timestamp": time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime()),
                "level": level,
                "module": name,
                "message": message,
                **extras,
            })
        else:
            return f"[{level:<8}] {name:<20} | {message}{context}"


def setup_logging() -> None:
    """Configure root logging for the application.

    Called once during application startup.
    """
    root = logging.getLogger()
    root.setLevel(settings.log_level)

    handler = logging.StreamHandler(sys.stdout)
    handler.setFormatter(_StructuredFormatter())

    root.handlers.clear()
    root.addHandler(handler)

    # Silence noisy third-party loggers
    logging.getLogger("uvicorn.access").setLevel(logging.WARNING)
    logging.getLogger("sqlalchemy.engine").setLevel(
        logging.INFO if settings.is_development else logging.WARNING
    )


def get_logger(name: str) -> logging.Logger:
    """Return a logger for the given module name.

    Usage:
        from app.core.logging import get_logger
        logger = get_logger(__name__)
        logger.info("Message", extra={"key": "value"})
    """
    return logging.getLogger(name)


class _LogAdapter(logging.LoggerAdapter):
    """Logger adapter that supports keyword arguments as structured fields.

    Usage:
        logger.info("Message", equipment_id="MTR-305", value=78.4)
    """

    def process(
        self, msg: str, kwargs: dict[str, Any]
    ) -> tuple[str, dict[str, Any]]:
        extra = kwargs.pop("extra", {})
        # Pull keyword arguments into 'extra' dict for structured output
        for k in list(kwargs.keys()):
            if k not in {"exc_info", "stack_info", "stacklevel"}:
                extra[k] = kwargs.pop(k)
        kwargs["extra"] = extra
        return msg, kwargs


def get_structured_logger(name: str) -> _LogAdapter:
    """Return a structured logger that accepts keyword arguments.

    Usage:
        logger = get_structured_logger(__name__)
        logger.info("Anomaly detected", equipment_id="MTR-305", severity="CRITICAL")
    """
    return _LogAdapter(logging.getLogger(name), {})
