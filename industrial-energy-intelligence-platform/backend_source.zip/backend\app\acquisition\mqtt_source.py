"""
IEIP Acquisition — MQTT Telemetry Data Source

Connects to Mosquitto/EMQX MQTT broker, subscribes to plant hierarchy topics:
  {topic_prefix}/+/telemetry (e.g. ieip/planta-caribe/MTR-305/telemetry)
translating JSON payloads into standardized RawTelemetryPayload instances.
"""

from __future__ import annotations

import asyncio
import json
from datetime import datetime, timezone
from typing import AsyncGenerator

from app.acquisition.base import BaseDataSource, RawTelemetryPayload
from app.config import get_settings
from app.core.logging import get_logger

logger = get_logger("ieip.acquisition.mqtt")
settings = get_settings()


class MQTTDataSource(BaseDataSource):
    """Acquisition source reading from Mosquitto MQTT broker."""

    def __init__(self, source_name: str = "MosquittoMQTT") -> None:
        super().__init__(source_name=source_name)
        self.host = settings.MQTT_BROKER_HOST
        self.port = settings.MQTT_BROKER_PORT
        self.client_id = settings.MQTT_CLIENT_ID
        self.topic_sub = f"{settings.MQTT_TOPIC_PREFIX}/#"
        self._queue: asyncio.Queue[RawTelemetryPayload] = asyncio.Queue(maxsize=2000)
        self._client = None
        self._listen_task: asyncio.Task | None = None

    async def connect(self) -> None:
        """Establish connection to MQTT broker."""
        try:
            import aiomqtt

            self._client = aiomqtt.Client(
                hostname=self.host,
                port=self.port,
                identifier=self.client_id,
                username=settings.MQTT_USERNAME or None,
                password=settings.MQTT_PASSWORD or None,
            )
            self._is_connected = True
            self._listen_task = asyncio.create_task(self._listen_loop())
            logger.info(f"MQTT source configured for {self.host}:{self.port}, topic: {self.topic_sub}")
        except ImportError:
            logger.warning("aiomqtt library not installed; MQTT source will run in mock/standby mode")
        except Exception as err:
            logger.error(f"Failed to connect to MQTT broker {self.host}:{self.port} - {err}")
            self._is_connected = False

    async def disconnect(self) -> None:
        """Disconnect and clean up tasks."""
        self._is_connected = False
        if self._listen_task:
            self._listen_task.cancel()
        logger.info("MQTT source disconnected")

    async def _listen_loop(self) -> None:
        """Background subscription loop reading from MQTT topics."""
        import aiomqtt

        while self._is_connected:
            try:
                async with self._client:
                    await self._client.subscribe(self.topic_sub)
                    logger.info(f"Subscribed to MQTT topic: {self.topic_sub}")
                    async for message in self._client.messages:
                        try:
                            topic_str = str(message.topic)
                            payload_raw = message.payload.decode("utf-8")
                            data = json.loads(payload_raw)

                            # Parse equipment code from topic e.g. ieip/planta-caribe/MTR-305/telemetry
                            parts = topic_str.split("/")
                            equip_code = parts[2] if len(parts) >= 3 else data.get("asset_code", "UNKNOWN")

                            parsed = RawTelemetryPayload(
                                source_id=f"MQTT:{self.host}",
                                equipment_code=equip_code,
                                measurement_point_code=data.get("point_code", f"MP-{equip_code}-MAIN"),
                                timestamp=datetime.now(timezone.utc),
                                voltage_l1=data.get("voltage_l1"),
                                voltage_l2=data.get("voltage_l2"),
                                voltage_l3=data.get("voltage_l3"),
                                voltage_avg=data.get("voltage_avg"),
                                current_l1=data.get("current_l1"),
                                current_l2=data.get("current_l2"),
                                current_l3=data.get("current_l3"),
                                current_avg=data.get("current_avg"),
                                active_power_kw=data.get("active_power_kw"),
                                reactive_power_kvar=data.get("reactive_power_kvar"),
                                apparent_power_kva=data.get("apparent_power_kva"),
                                power_factor=data.get("power_factor"),
                                frequency_hz=data.get("frequency_hz"),
                                energy_kwh=data.get("energy_kwh"),
                                current_unbalance_pct=data.get("current_unbalance_pct"),
                                voltage_unbalance_pct=data.get("voltage_unbalance_pct"),
                                thd_current_pct=data.get("thd_current_pct"),
                                thd_voltage_pct=data.get("thd_voltage_pct"),
                                temperature_c=data.get("temperature_c"),
                                vibration_rms_mms=data.get("vibration_rms_mms"),
                                operating_state=data.get("operating_state", "RUNNING"),
                                load_pct=data.get("load_pct"),
                                is_simulated=False,
                                quality_code=192,
                            )
                            if not self._queue.full():
                                await self._queue.put(parsed)
                        except Exception as parse_err:
                            logger.error(f"Failed to parse MQTT message on {message.topic}: {parse_err}")
            except Exception as conn_err:
                logger.warning(f"MQTT connection lost ({conn_err}). Retrying in 5s...")
                await asyncio.sleep(5.0)

    async def stream(self) -> AsyncGenerator[RawTelemetryPayload, None]:
        """Yield telemetry packets from MQTT broker queue."""
        while self._is_connected:
            try:
                payload = await asyncio.wait_for(self._queue.get(), timeout=2.0)
                yield payload
                self._queue.task_done()
            except asyncio.TimeoutError:
                continue
