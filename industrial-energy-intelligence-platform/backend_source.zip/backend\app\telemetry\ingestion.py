"""
IEIP Telemetry — Ingestion Service & Pipeline Orchestrator

Consumes RawTelemetryPayload frames, persists time-series readings to TimescaleDB,
executes the analytical intelligence pipeline, deduplicates alarms, and generates
condition-based maintenance recommendations.
"""

from __future__ import annotations

import uuid
from datetime import datetime, timezone
from typing import Any

from sqlalchemy import select, update
from sqlalchemy.ext.asyncio import AsyncSession

from app.acquisition.base import RawTelemetryPayload
from app.alerts.deduplicator import AlertDeduplicator
from app.analytics.pipeline import AnalyticsPipeline
from app.analytics.threshold import AnomalyCandidate
from app.core.database import async_session_factory
from app.core.logging import get_logger
from app.models.alert import Alert, AlertStatus
from app.models.anomaly import Anomaly, AnomalyStatus, AnomalyType
from app.models.equipment import Equipment, OperatingStatus
from app.models.maintenance import (
    MaintenanceRecommendation,
    RecommendationPriority,
    RecommendationStatus,
)
from app.models.measurement_point import MeasurementPoint
from app.models.telemetry import TelemetryReading

logger = get_logger("ieip.telemetry.ingestion")


class IngestionPipelineService:
    """Singleton service for real-time telemetry processing."""

    _instance: IngestionPipelineService | None = None

    def __init__(self) -> None:
        self.analytics = AnalyticsPipeline()
        self.deduplicator = AlertDeduplicator(cooldown_seconds=60.0)
        # Cache for asset_code -> (equipment_id, dict_specs)
        self._equipment_cache: dict[str, tuple[uuid.UUID, dict[str, Any]]] = {}
        # Cache for point_code -> point_id
        self._point_cache: dict[str, uuid.UUID] = {}

    @classmethod
    def get_instance(cls) -> IngestionPipelineService:
        if cls._instance is None:
            cls._instance = cls()
        return cls._instance

    async def ingest_payload(self, payload: RawTelemetryPayload) -> TelemetryReading | None:
        """Process a single incoming telemetry frame end-to-end."""
        async with async_session_factory() as session:
            try:
                # 1. Resolve equipment and measurement point
                equip_info = await self._resolve_equipment(session, payload.equipment_code)
                if not equip_info:
                    logger.debug(f"Equipment code '{payload.equipment_code}' not found in registry; skipping reading")
                    return None

                equipment_id, equip_specs = equip_info
                point_id = await self._resolve_point(session, payload.measurement_point_code, equipment_id)

                # 2. Construct TelemetryReading model
                reading = TelemetryReading(
                    time=payload.timestamp or datetime.now(timezone.utc),
                    measurement_point_id=point_id,
                    equipment_id=equipment_id,
                    voltage_l1=payload.voltage_l1,
                    voltage_l2=payload.voltage_l2,
                    voltage_l3=payload.voltage_l3,
                    voltage_avg=payload.voltage_avg,
                    current_l1=payload.current_l1,
                    current_l2=payload.current_l2,
                    current_l3=payload.current_l3,
                    current_avg=payload.current_avg,
                    active_power_kw=payload.active_power_kw,
                    reactive_power_kvar=payload.reactive_power_kvar,
                    apparent_power_kva=payload.apparent_power_kva,
                    power_factor=payload.power_factor,
                    frequency_hz=payload.frequency_hz,
                    energy_kwh=payload.energy_kwh,
                    current_unbalance_pct=payload.current_unbalance_pct,
                    voltage_unbalance_pct=payload.voltage_unbalance_pct,
                    thd_current_pct=payload.thd_current_pct,
                    thd_voltage_pct=payload.thd_voltage_pct,
                    temperature_c=payload.temperature_c,
                    vibration_rms_mms=payload.vibration_rms_mms,
                    operating_state=payload.operating_state,
                    load_pct=payload.load_pct,
                    is_simulated=payload.is_simulated,
                    quality_code=payload.quality_code,
                )
                session.add(reading)

                # 3. Run Analytics Pipeline
                telemetry_dict = {
                    "voltage_avg": payload.voltage_avg,
                    "voltage_l1": payload.voltage_l1,
                    "voltage_l2": payload.voltage_l2,
                    "voltage_l3": payload.voltage_l3,
                    "current_avg": payload.current_avg,
                    "current_l1": payload.current_l1,
                    "current_l2": payload.current_l2,
                    "current_l3": payload.current_l3,
                    "active_power_kw": payload.active_power_kw,
                    "reactive_power_kvar": payload.reactive_power_kvar,
                    "apparent_power_kva": payload.apparent_power_kva,
                    "power_factor": payload.power_factor,
                    "temperature_c": payload.temperature_c,
                    "vibration_rms_mms": payload.vibration_rms_mms,
                    "thd_current_pct": payload.thd_current_pct,
                    "thd_voltage_pct": payload.thd_voltage_pct,
                    "operating_state": payload.operating_state,
                    "timestamp": payload.timestamp,
                }
                candidates = self.analytics.process_frame(telemetry_dict, equip_specs)

                # 4. Process Anomaly Candidates & Alerts
                for candidate in candidates:
                    await self._handle_anomaly(
                        session=session,
                        candidate=candidate,
                        equipment_id=equipment_id,
                        point_id=point_id,
                        equip_specs=equip_specs,
                    )

                # 5. Commit batch transaction
                await session.commit()
                return reading
            except Exception as err:
                await session.rollback()
                logger.error(f"Error during telemetry ingestion: {err}")
                return None

    async def _resolve_equipment(
        self, session: AsyncSession, asset_code: str
    ) -> tuple[uuid.UUID, dict[str, Any]] | None:
        """Lookup equipment ID and engineering specs with in-memory caching."""
        if asset_code in self._equipment_cache:
            return self._equipment_cache[asset_code]

        stmt = select(Equipment).where(Equipment.asset_code == asset_code)
        result = await session.execute(stmt)
        equipment = result.scalar_one_or_none()

        if not equipment:
            return None

        specs = {
            "asset_code": equipment.asset_code,
            "rated_power_kw": equipment.rated_power_kw or 75.0,
            "rated_voltage": equipment.rated_voltage or 460.0,
            "rated_current": equipment.rated_current or 115.0,
            "nominal_power_factor": equipment.nominal_power_factor or 0.88,
        }
        self._equipment_cache[asset_code] = (equipment.id, specs)
        return self._equipment_cache[asset_code]

    async def _resolve_point(
        self, session: AsyncSession, point_code: str, equipment_id: uuid.UUID
    ) -> uuid.UUID:
        """Lookup or auto-register measurement point."""
        if point_code in self._point_cache:
            return self._point_cache[point_code]

        stmt = select(MeasurementPoint).where(MeasurementPoint.point_code == point_code)
        result = await session.execute(stmt)
        point = result.scalar_one_or_none()

        if not point:
            # Auto-create measurement point record
            point = MeasurementPoint(
                equipment_id=equipment_id,
                point_code=point_code,
                name=f"Channel {point_code}",
            )
            session.add(point)
            await session.flush()

        self._point_cache[point_code] = point.id
        return point.id

    async def _handle_anomaly(
        self,
        session: AsyncSession,
        candidate: AnomalyCandidate,
        equipment_id: uuid.UUID,
        point_id: uuid.UUID,
        equip_specs: dict[str, Any],
    ) -> None:
        """Persist anomaly, evaluate alert deduplication, and generate maintenance recommendation."""
        now = datetime.now(timezone.utc)

        # 1. Create Anomaly record
        anomaly = Anomaly(
            equipment_id=equipment_id,
            measurement_point_id=point_id,
            detected_at=now,
            anomaly_type=candidate.anomaly_type,
            severity=candidate.severity,
            status=AnomalyStatus.DETECTED,
            algorithm_used=candidate.algorithm,
            metric_name=candidate.metric_name,
            observed_value=candidate.observed_value,
            expected_value=candidate.expected_value,
            threshold_value=candidate.threshold_value,
            deviation_pct=candidate.deviation_pct,
            confidence_score=candidate.confidence_score,
            description=candidate.description,
            context_snapshot=candidate.context,
        )
        session.add(anomaly)
        await session.flush()

        # 2. Alert Deduplication check
        dedup_key = self.deduplicator.get_dedup_key(equipment_id, candidate.anomaly_type.value)
        suppress, active_record = self.deduplicator.should_suppress(dedup_key)

        if suppress and active_record:
            # Update occurrence count and last_triggered_at in existing open alert
            stmt = (
                update(Alert)
                .where(Alert.id == active_record.alert_id)
                .values(
                    occurrence_count=active_record.occurrence_count,
                    last_triggered_at=now,
                )
            )
            await session.execute(stmt)
        else:
            # Insert new Alert record
            alert = Alert(
                equipment_id=equipment_id,
                anomaly_id=anomaly.id,
                dedup_key=dedup_key,
                title=f"{candidate.anomaly_type.value}: {equip_specs['asset_code']}",
                message=candidate.description,
                severity=candidate.severity,
                status=AlertStatus.OPEN,
                occurrence_count=1,
                first_triggered_at=now,
                last_triggered_at=now,
            )
            session.add(alert)
            await session.flush()
            self.deduplicator.register_alert(dedup_key, alert.id)

        # 3. Condition-Based Maintenance Recommendation Generation
        await self._evaluate_maintenance_recommendation(
            session=session,
            equipment_id=equipment_id,
            anomaly_id=anomaly.id,
            candidate=candidate,
            equip_specs=equip_specs,
        )

    async def _evaluate_maintenance_recommendation(
        self,
        session: AsyncSession,
        equipment_id: uuid.UUID,
        anomaly_id: uuid.UUID,
        candidate: AnomalyCandidate,
        equip_specs: dict[str, Any],
    ) -> None:
        """Synthesize technical maintenance actions from engineering failure modes."""
        title = ""
        rationale = ""
        actions = ""
        priority = RecommendationPriority.MEDIUM
        kwh_waste = None
        cost_usd = None

        if candidate.anomaly_type == AnomalyType.PHASE_IMBALANCE:
            title = f"Inspección de Devanados y Conexiones en Bornes — {equip_specs['asset_code']}"
            rationale = (
                f"El desbalance de fases detectado ({candidate.observed_value}%) incrementa las pérdidas por "
                f"efecto Joule y las corrientes de secuencia negativa en el rotor, elevando la temperatura interna."
            )
            actions = (
                "1. Medir resistencia de aislamiento (Megger) en cada bobinado.\n"
                "2. Verificar par de apriete en la caja de bornes del motor.\n"
                "3. Inspeccionar contactor y relé térmico en el Centro de Control de Motores (CCM) buscando desgaste de contactos."
            )
            priority = RecommendationPriority.HIGH
            kwh_waste = round((equip_specs.get("rated_power_kw", 75.0) * 0.04) * 720, 1)  # ~4% extra thermal loss
            cost_usd = round(kwh_waste * 0.14, 2)

        elif candidate.anomaly_type == AnomalyType.LOW_POWER_FACTOR:
            title = f"Corrección de Compensación Reactiva — {equip_specs['asset_code']}"
            rationale = (
                f"El factor de potencia medido ({candidate.observed_value}) genera penalización tarifaria y sobrecarga reactiva "
                f"en los transformadores y alimentadores de planta."
            )
            actions = (
                "1. Evaluar dimensionamiento de banco de condensadores individual o automático en barraje.\n"
                "2. Comprobar si el motor está sobredimensionado para la carga mecánica real requerida.\n"
                "3. Instalar contactor de condensador aguas arriba del arrancador."
            )
            priority = RecommendationPriority.MEDIUM
            kwh_waste = 450.0
            cost_usd = round(kwh_waste * 0.14 + 85.0, 2)  # Include reactive tariff penalty

        elif candidate.anomaly_type == AnomalyType.EXCESSIVE_VIBRATION:
            title = f"Diagnóstico de Rodamientos y Alineación Láser — {equip_specs['asset_code']}"
            rationale = (
                f"Vibración RMS ({candidate.observed_value} mm/s) supera umbral ISO 10816-3. Sugiere desalineación "
                f"angular/paralela o desprendimiento superficial de pistas de rodamientos."
            )
            actions = (
                "1. Realizar análisis espectral FFT de vibraciones (identificar frecuencias de paso de elementos rodantes BPFO/BPFI).\n"
                "2. Verificar lubricación de cojinetes con grasa especificada por fabricante.\n"
                "3. Ejecutar alineación láser con el eje acoplado de la máquina conducida."
            )
            priority = RecommendationPriority.HIGH if candidate.observed_value < 7.0 else RecommendationPriority.IMMEDIATE

        if title:
            # Check if pending recommendation already exists for this equipment
            stmt = select(MaintenanceRecommendation).where(
                MaintenanceRecommendation.equipment_id == equipment_id,
                MaintenanceRecommendation.title == title,
                MaintenanceRecommendation.status == RecommendationStatus.PENDING,
            )
            res = await session.execute(stmt)
            existing = res.scalar_one_or_none()

            if not existing:
                rec = MaintenanceRecommendation(
                    equipment_id=equipment_id,
                    anomaly_id=anomaly_id,
                    title=title,
                    technical_rationale=rationale,
                    suggested_actions=actions,
                    priority=priority,
                    status=RecommendationStatus.PENDING,
                    estimated_monthly_kwh_waste=kwh_waste,
                    estimated_monthly_cost_usd=cost_usd,
                )
                session.add(rec)
