"""
IEIP Backend — Schemas Package
"""

from app.schemas.alert import (
    AlertAcknowledge,
    AlertCreate,
    AlertFilter,
    AlertResolve,
    AlertResponse,
)
from app.schemas.anomaly import (
    AnomalyCreate,
    AnomalyFilter,
    AnomalyResponse,
    AnomalyUpdate,
)
from app.schemas.common import APIResponse, PaginatedResponse, TimeRangeFilter
from app.schemas.equipment import (
    EquipmentCreate,
    EquipmentResponse,
    EquipmentSummary,
    EquipmentUpdate,
)
from app.schemas.event import (
    EventFilter,
    OperationalEventCreate,
    OperationalEventResponse,
)
from app.schemas.kpi import (
    EnergyConsumptionItem,
    EquipmentKPIs,
    PlantKPIs,
)
from app.schemas.maintenance import (
    MaintenanceRecommendationCreate,
    MaintenanceRecommendationResponse,
    MaintenanceRecommendationUpdate,
)
from app.schemas.measurement_point import (
    MeasurementPointCreate,
    MeasurementPointResponse,
    MeasurementPointUpdate,
)
from app.schemas.simulation import (
    SimulationScenarioRequest,
    SimulationStatusResponse,
)
from app.schemas.telemetry import (
    AggregationBucket,
    RealTimeSnapshot,
    TelemetryIngest,
    TelemetryResponse,
)
from app.schemas.user import (
    LoginRequest,
    Token,
    TokenPayload,
    UserCreate,
    UserResponse,
    UserUpdate,
)

__all__ = [
    "APIResponse",
    "PaginatedResponse",
    "TimeRangeFilter",
    "UserCreate",
    "UserUpdate",
    "UserResponse",
    "LoginRequest",
    "Token",
    "TokenPayload",
    "EquipmentCreate",
    "EquipmentUpdate",
    "EquipmentResponse",
    "EquipmentSummary",
    "MeasurementPointCreate",
    "MeasurementPointUpdate",
    "MeasurementPointResponse",
    "TelemetryIngest",
    "TelemetryResponse",
    "RealTimeSnapshot",
    "AggregationBucket",
    "AnomalyCreate",
    "AnomalyUpdate",
    "AnomalyResponse",
    "AnomalyFilter",
    "AlertCreate",
    "AlertAcknowledge",
    "AlertResolve",
    "AlertResponse",
    "AlertFilter",
    "OperationalEventCreate",
    "OperationalEventResponse",
    "EventFilter",
    "MaintenanceRecommendationCreate",
    "MaintenanceRecommendationUpdate",
    "MaintenanceRecommendationResponse",
    "PlantKPIs",
    "EquipmentKPIs",
    "EnergyConsumptionItem",
    "SimulationScenarioRequest",
    "SimulationStatusResponse",
]
