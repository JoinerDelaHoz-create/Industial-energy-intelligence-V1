"""
IEIP API v1 — Simulation Control Endpoints
"""

from __future__ import annotations

from fastapi import APIRouter, Depends
from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession

from app.core.exceptions import NotFoundError
from app.dependencies import get_db, get_optional_user
from app.models.equipment import Equipment
from app.models.user import User
from app.schemas.common import APIResponse
from app.schemas.simulation import (
    SimulationScenarioRequest,
    SimulationStatusResponse,
)
from app.simulation.runner import SimulationRunner

router = APIRouter(prefix="/simulation", tags=["Simulation Control"])


@router.get("/status", response_model=APIResponse[dict])
async def get_simulation_status():
    """Get active scenario, runtime counters, and scenario catalog."""
    runner = SimulationRunner.get_instance()
    status_data = runner.get_status()
    return APIResponse(data=status_data)


@router.post("/trigger", response_model=APIResponse[dict])
async def trigger_scenario(
    payload: SimulationScenarioRequest,
    db: AsyncSession = Depends(get_db),
    _user: User | None = Depends(get_optional_user),
):
    """Inject an industrial fault or operating condition into the digital twin."""
    runner = SimulationRunner.get_instance()

    asset_code = "MTR-305"
    if payload.equipment_id:
        stmt = select(Equipment.asset_code).where(Equipment.id == payload.equipment_id)
        res = await db.execute(stmt)
        code = res.scalar_one_or_none()
        if not code:
            raise NotFoundError("Equipment ID not found")
        asset_code = code

    success = runner.trigger_scenario(
        scenario_id=payload.scenario_id,
        asset_code=asset_code,
        duration_seconds=float(payload.duration_seconds),
        severity=payload.severity_multiplier,
    )
    if not success:
        raise ValueError(f"Scenario '{payload.scenario_id}' could not be triggered")

    return APIResponse(
        message=f"Scenario '{payload.scenario_id}' triggered on {asset_code}",
        data={
            "scenario_id": payload.scenario_id,
            "target_asset_code": asset_code,
            "duration_seconds": payload.duration_seconds,
            "severity_multiplier": payload.severity_multiplier,
        },
    )


@router.post("/reset", response_model=APIResponse[dict])
async def reset_simulation():
    """Revert digital twin fleet back to nominal baseline operation."""
    runner = SimulationRunner.get_instance()
    runner.reset_to_normal()
    return APIResponse(message="Equipment fleet restored to nominal baseline operation", data={})
