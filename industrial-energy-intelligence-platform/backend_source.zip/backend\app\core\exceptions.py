"""
IEIP Backend — Custom Exceptions and Error Handlers

Provides a consistent error response structure across all endpoints.

SECURITY: Stack traces are never returned to clients in production.
          Error messages are sanitised to avoid information disclosure.
"""

from __future__ import annotations

from fastapi import FastAPI, Request, status
from fastapi.responses import JSONResponse

from app.config import settings
from app.core.logging import get_logger

logger = get_logger(__name__)


# ── Domain Exceptions ──────────────────────────────────────────────────────────

class IEIPError(Exception):
    """Base exception for all IEIP domain errors."""

    def __init__(self, message: str, code: str = "IEIP_ERROR") -> None:
        self.message = message
        self.code = code
        super().__init__(message)


class NotFoundError(IEIPError):
    """Resource not found."""

    def __init__(self, resource: str, identifier: str | None = None) -> None:
        detail = f"{resource} not found"
        if identifier:
            detail += f": {identifier}"
        super().__init__(detail, code="NOT_FOUND")


class ConflictError(IEIPError):
    """Resource already exists or state conflict."""

    def __init__(self, message: str) -> None:
        super().__init__(message, code="CONFLICT")


class ValidationError(IEIPError):
    """Business logic validation failure."""

    def __init__(self, message: str) -> None:
        super().__init__(message, code="VALIDATION_ERROR")


class AuthenticationError(IEIPError):
    """Authentication failed — invalid credentials or token."""

    def __init__(self, message: str = "Authentication required") -> None:
        super().__init__(message, code="AUTHENTICATION_ERROR")


class AuthorizationError(IEIPError):
    """Authorisation failed — insufficient permissions."""

    def __init__(self, message: str = "Insufficient permissions") -> None:
        super().__init__(message, code="AUTHORIZATION_ERROR")


class AcquisitionError(IEIPError):
    """Data acquisition error (MQTT, Modbus, Simulator)."""

    def __init__(self, source: str, message: str) -> None:
        super().__init__(f"[{source}] {message}", code="ACQUISITION_ERROR")


# ── Error Response Builder ─────────────────────────────────────────────────────

def _error_response(
    status_code: int,
    code: str,
    message: str,
    request: Request | None = None,
) -> JSONResponse:
    """Build a standardised error JSON response."""
    body: dict[str, object] = {
        "error": {
            "code": code,
            "message": message,
            "status": status_code,
        }
    }
    return JSONResponse(status_code=status_code, content=body)


# ── Exception Handlers ─────────────────────────────────────────────────────────

def register_exception_handlers(app: FastAPI) -> None:
    """Register all custom exception handlers on the FastAPI application."""

    @app.exception_handler(NotFoundError)
    async def not_found_handler(request: Request, exc: NotFoundError) -> JSONResponse:
        return _error_response(status.HTTP_404_NOT_FOUND, exc.code, exc.message, request)

    @app.exception_handler(ConflictError)
    async def conflict_handler(request: Request, exc: ConflictError) -> JSONResponse:
        return _error_response(status.HTTP_409_CONFLICT, exc.code, exc.message, request)

    @app.exception_handler(ValidationError)
    async def validation_handler(request: Request, exc: ValidationError) -> JSONResponse:
        return _error_response(
            status.HTTP_422_UNPROCESSABLE_ENTITY, exc.code, exc.message, request
        )

    @app.exception_handler(AuthenticationError)
    async def auth_handler(request: Request, exc: AuthenticationError) -> JSONResponse:
        return _error_response(
            status.HTTP_401_UNAUTHORIZED, exc.code, exc.message, request
        )

    @app.exception_handler(AuthorizationError)
    async def authz_handler(request: Request, exc: AuthorizationError) -> JSONResponse:
        return _error_response(
            status.HTTP_403_FORBIDDEN, exc.code, exc.message, request
        )

    @app.exception_handler(IEIPError)
    async def ieip_error_handler(request: Request, exc: IEIPError) -> JSONResponse:
        logger.error("Unhandled domain error", code=exc.code, message=exc.message)
        return _error_response(
            status.HTTP_500_INTERNAL_SERVER_ERROR, exc.code, exc.message, request
        )

    @app.exception_handler(Exception)
    async def unhandled_exception_handler(
        request: Request, exc: Exception
    ) -> JSONResponse:
        logger.error(
            "Unhandled exception",
            path=str(request.url),
            method=request.method,
            error=str(exc),
            exc_info=True,
        )
        # SECURITY: Never expose raw exception details to clients in production
        if settings.is_development:
            message = str(exc)
        else:
            message = "An internal server error occurred. Please contact support."

        return _error_response(
            status.HTTP_500_INTERNAL_SERVER_ERROR,
            "INTERNAL_SERVER_ERROR",
            message,
            request,
        )
